import React, { useState } from 'react';
import { ThemeProvider } from './contexts/ThemeContext';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ChatProvider, useChat } from './contexts/ChatContext';
import { CallProvider, useCall } from './contexts/CallContext';

import { Sidebar } from './components/navigation/Sidebar';
import { MobileNav } from './components/navigation/MobileNav';
import { ChatList } from './components/chat/ChatList';
import { ChatWindow } from './components/chat/ChatWindow';
import { EmptyState } from './components/common/EmptyState';
import { ContactsView } from './components/contacts/ContactsView';
import { AddContactModal } from './components/contacts/AddContactModal';
import { ContactRequestsModal } from './components/contacts/ContactRequestsModal';
import { CreateGroupModal } from './components/groups/CreateGroupModal';
import { CreateChannelModal } from './components/channels/CreateChannelModal';
import { StatusView } from './components/status/StatusView';
import { CreateStatusModal } from './components/status/CreateStatusModal';
import { StatusStoryViewer } from './components/status/StatusStoryViewer';
import { CallHistoryView } from './components/calls/CallHistoryView';
import { CallOverlay } from './components/calls/CallOverlay';
import { SettingsView } from './components/settings/SettingsView';
import { AuthScreen } from './components/auth/AuthScreen';
import { NavigationTab, StatusStory, UserProfile } from './types';

const MainLayout: React.FC = () => {
  const { user, loading } = useAuth();
  const {
    conversations,
    activeConversationId,
    setActiveConversationId,
    createDirectChat,
    unreadNotificationsCount,
  } = useChat();

  const [activeTab, setActiveTab] = useState<NavigationTab>('chats');

  // Modals state
  const [showAddContact, setShowAddContact] = useState(false);
  const [showContactRequests, setShowContactRequests] = useState(false);
  const [showCreateGroup, setShowCreateGroup] = useState(false);
  const [showCreateChannel, setShowCreateChannel] = useState(false);
  const [showCreateStatus, setShowCreateStatus] = useState(false);
  const [viewingStory, setViewingStory] = useState<StatusStory | null>(null);

  if (loading) {
    return (
      <div className="min-h-screen w-full flex items-center justify-center bg-background text-foreground">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 rounded-full border-2 border-accent border-t-transparent animate-spin" />
          <span className="text-xs font-medium text-muted">Starting LIVO Messenger...</span>
        </div>
      </div>
    );
  }

  if (!user) {
    return <AuthScreen />;
  }

  const activeConversation = conversations.find((c) => c.id === activeConversationId);

  const handleStartChatWithUser = async (peer: UserProfile) => {
    const conv = await createDirectChat(peer.id);
    setActiveTab('chats');
    setActiveConversationId(conv.id);
  };

  return (
    <div className="flex h-screen w-screen bg-background text-foreground overflow-hidden">
      {/* Desktop Sidebar (Left Navigation) */}
      <Sidebar
        activeTab={activeTab}
        onSelectTab={(tab) => {
          setActiveTab(tab);
          if (tab !== 'chats') {
            setActiveConversationId(null);
          }
        }}
        unreadNotifications={unreadNotificationsCount}
      />

      {/* Main Content Area */}
      <main className="flex-1 flex overflow-hidden relative">
        {/* TAB 1: CHATS */}
        {activeTab === 'chats' && (
          <div className="flex-1 flex h-full w-full overflow-hidden">
            {/* Conversation List Pane */}
            <div
              className={`w-full md:w-80 lg:w-96 flex-shrink-0 h-full ${
                activeConversationId ? 'hidden md:flex flex-col' : 'flex flex-col'
              }`}
            >
              <ChatList
                onOpenNewChat={() => setShowAddContact(true)}
              />
            </div>

            {/* Conversation Chat Window */}
            <div
              className={`flex-1 h-full flex-col ${
                activeConversationId ? 'flex' : 'hidden md:flex'
              }`}
            >
              {activeConversation ? (
                <ChatWindow
                  conversation={activeConversation}
                  onBackMobile={() => setActiveConversationId(null)}
                />
              ) : (
                <EmptyState
                  onStartChat={() => setShowAddContact(true)}
                />
              )}
            </div>
          </div>
        )}

        {/* TAB 2: CONTACTS */}
        {activeTab === 'contacts' && (
          <ContactsView
            onOpenAddContact={() => setShowAddContact(true)}
            onOpenRequests={() => setShowContactRequests(true)}
            onStartChatWithUser={handleStartChatWithUser}
          />
        )}

        {/* TAB 3: STATUS / STORIES / GROUPS / CHANNELS */}
        {activeTab === 'status' && (
          <StatusView
            onOpenCreateStatus={() => setShowCreateStatus(true)}
            onOpenStoryViewer={(story) => setViewingStory(story)}
            onOpenCreateGroup={() => setShowCreateGroup(true)}
            onOpenCreateChannel={() => setShowCreateChannel(true)}
            onNavigateToChat={(convId) => {
              setActiveTab('chats');
              setActiveConversationId(convId);
            }}
          />
        )}

        {/* TAB 4: CALLS */}
        {activeTab === 'calls' && <CallHistoryView />}

        {/* TAB 5: SETTINGS (with full Notifications inbox & preferences inside) */}
        {activeTab === 'settings' && <SettingsView />}
      </main>

      {/* Mobile Bottom Navigation Bar - hidden when inside an active conversation to give full space to chat and composer */}
      {!(activeTab === 'chats' && activeConversationId) && (
        <MobileNav
          activeTab={activeTab}
          onSelectTab={(tab) => {
            setActiveTab(tab);
            if (tab !== 'chats') {
              setActiveConversationId(null);
            }
          }}
          unreadNotifications={unreadNotificationsCount}
        />
      )}

      {/* Global Active Call Overlay (WebRTC Voice/Video) */}
      <CallOverlay />

      {/* Modals */}
      {showAddContact && (
        <AddContactModal onClose={() => setShowAddContact(false)} />
      )}

      {showContactRequests && (
        <ContactRequestsModal onClose={() => setShowContactRequests(false)} />
      )}

      {showCreateGroup && (
        <CreateGroupModal onClose={() => setShowCreateGroup(false)} />
      )}

      {showCreateChannel && (
        <CreateChannelModal onClose={() => setShowCreateChannel(false)} />
      )}

      {showCreateStatus && (
        <CreateStatusModal onClose={() => setShowCreateStatus(false)} />
      )}

      {viewingStory && (
        <StatusStoryViewer
          status={viewingStory}
          onClose={() => setViewingStory(null)}
        />
      )}
    </div>
  );
};

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <ChatProvider>
          <CallProvider>
            <MainLayout />
          </CallProvider>
        </ChatProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}
