import React from 'react';
import { Sun, Moon, Sparkles, Check } from 'lucide-react';
import { useTheme } from '../../contexts/ThemeContext';
import { AccentColor, ACCENT_COLORS, ThemeMode } from '../../types';

export const AppearanceSettings: React.FC = () => {
  const {
    themeMode,
    setThemeMode,
    accentColor,
    setAccentColor,
  } = useTheme();

  const themes: {
    id: ThemeMode;
    label: string;
    icon: any;
    description: string;
    styleClass?: string;
  }[] = [
    {
      id: 'white',
      label: 'White',
      icon: Sun,
      description: 'Pure crisp white theme with high-contrast clean daylight interface.',
    },
    {
      id: 'black',
      label: 'Black',
      icon: Moon,
      description: 'Deep pitch-black AMOLED dark theme with sleek monochrome controls.',
    },
    {
      id: 'rainbow',
      label: 'Rainbow (All in One)',
      icon: Sparkles,
      description: 'Dynamic prismatic rainbow theme with animated gradients and vibrant glowing highlights.',
      styleClass: 'rainbow-theme-card',
    },
  ];

  const accentKeys = Object.keys(ACCENT_COLORS) as AccentColor[];

  return (
    <div className="flex flex-col gap-6 select-none max-w-xl">
      {/* 1. Appearance Theme Selection: White, Black, Rainbow */}
      <div className="flex flex-col gap-3">
        <div>
          <h3 className="font-display font-semibold text-sm text-foreground flex items-center gap-2">
            <span>Theme Selection</span>
            <span className="text-[11px] font-normal px-2 py-0.5 rounded-full bg-input text-muted">
              3 Available
            </span>
          </h3>
          <p className="text-xs text-muted mt-0.5">
            Choose between White, Black, or the Rainbow all-in-one vibrant theme.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {themes.map((theme) => {
            const isSelected = themeMode === theme.id;
            const Icon = theme.icon;

            return (
              <button
                key={theme.id}
                onClick={() => setThemeMode(theme.id)}
                style={{
                  borderColor: isSelected ? 'var(--accent)' : 'var(--border)',
                  boxShadow: isSelected ? '0 0 20px -2px var(--accent-glow)' : 'none',
                }}
                className={`relative p-4 rounded-2xl border text-left transition-all duration-200 flex flex-col justify-between h-32 ${
                  isSelected
                    ? 'bg-card ring-2 ring-accent scale-102 shadow-lg'
                    : 'bg-card/60 hover:bg-card hover:border-border/80'
                }`}
              >
                <div className="flex items-center justify-between w-full">
                  <div
                    className={`p-2.5 rounded-xl ${
                      theme.id === 'rainbow'
                        ? 'bg-gradient-to-tr from-pink-500 via-purple-500 to-cyan-400 text-white shadow-md'
                        : isSelected
                        ? 'bg-accent text-accent-contrast'
                        : 'bg-input text-muted'
                    }`}
                  >
                    <Icon size={18} />
                  </div>

                  {/* Active Check mark */}
                  {isSelected && (
                    <div className="w-5 h-5 rounded-full bg-accent text-accent-contrast flex items-center justify-center shadow-sm">
                      <Check size={12} strokeWidth={3} />
                    </div>
                  )}
                </div>

                <div>
                  <h4 className="font-display font-semibold text-sm text-foreground flex items-center gap-1.5">
                    {theme.label}
                    {theme.id === 'rainbow' && (
                      <span className="w-2 h-2 rounded-full bg-gradient-to-r from-red-400 via-green-400 to-blue-400 animate-pulse" />
                    )}
                  </h4>
                  <span className="text-[10px] text-muted line-clamp-2 mt-0.5 leading-tight">
                    {theme.description}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. Global Website Color Theme */}
      {themeMode !== 'rainbow' && (
        <div className="flex flex-col gap-4 pt-5 border-t border-border">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-display font-semibold text-sm text-foreground flex items-center gap-2">
                <span>Color Theme (Active All Over Website)</span>
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: 'var(--accent)' }} />
              </h3>
              <p className="text-xs text-muted mt-0.5">
                Pick your favorite color. It activates globally across all buttons, highlights, tabs, badges, and chats!
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {accentKeys.map((key) => {
              const def = ACCENT_COLORS[key];
              const isSelected = accentColor === key;

              return (
                <button
                  key={key}
                  onClick={() => setAccentColor(key)}
                  className={`flex items-center gap-3 p-3 rounded-2xl border transition-all text-left ${
                    isSelected
                      ? 'bg-card border-accent ring-2 ring-accent shadow-md scale-102'
                      : 'bg-card/40 border-border hover:bg-card/80 hover:border-border/90'
                  }`}
                >
                  <span
                    className="w-7 h-7 rounded-xl flex-shrink-0 flex items-center justify-center shadow-sm border border-white/25 transition-transform"
                    style={{ backgroundColor: def.hex }}
                  >
                    {isSelected && <Check size={14} className="text-white" strokeWidth={3} />}
                  </span>
                  <div className="min-w-0 flex-1">
                    <span className="text-xs font-semibold text-foreground block truncate">
                      {def.name}
                    </span>
                    <span className="text-[10px] font-mono text-muted block">
                      {def.hex}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Live Preview of Active Color */}
          <div className="mt-2 p-4 rounded-2xl bg-card border border-border/80 flex flex-col gap-3">
            <span className="text-[11px] font-semibold text-muted uppercase tracking-wider">
              Live Color Theme Preview
            </span>
            <div className="flex flex-wrap items-center gap-3">
              <button className="px-4 py-2 bg-accent text-white rounded-xl text-xs font-semibold shadow-md shadow-accent/25 flex items-center gap-2">
                <Sparkles size={14} />
                <span>Primary Button</span>
              </button>
              <span className="px-3 py-1 rounded-full text-xs font-semibold bg-accent-soft text-accent border border-accent/30">
                Active Badge
              </span>
              <div className="px-3 py-1.5 rounded-xl bg-accent text-white text-xs font-medium max-w-xs shadow-xs">
                Sent message bubble preview
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
