import React, { useState } from 'react';
import { Database, X, Check, Copy, AlertCircle, RefreshCw, Key, ExternalLink } from 'lucide-react';
import { isSupabaseConfigured, setCustomSupabaseConfig, getSupabaseUrl, getSupabaseAnonKey } from '../../lib/supabase/config';

interface SupabaseConfigModalProps {
  onClose: () => void;
}

export const SupabaseConfigModal: React.FC<SupabaseConfigModalProps> = ({ onClose }) => {
  const [url, setUrl] = useState(getSupabaseUrl() || '');
  const [anonKey, setAnonKey] = useState(getSupabaseAnonKey() || '');
  const [copied, setCopied] = useState(false);
  const [status, setStatus] = useState<'idle' | 'testing' | 'success' | 'error'>('idle');
  const [message, setMessage] = useState('');

  const isConfigured = isSupabaseConfigured();

  const handleSave = () => {
    if (!url.trim() || !anonKey.trim()) {
      setStatus('error');
      setMessage('Both Project URL and Anon Key are required.');
      return;
    }

    setStatus('testing');
    setTimeout(() => {
      setCustomSupabaseConfig(url.trim(), anonKey.trim());
      setStatus('success');
      setMessage('Configuration saved! Reloading application with real Supabase connection...');
      setTimeout(() => {
        window.location.reload();
      }, 1200);
    }, 800);
  };

  const handleResetSandbox = () => {
    setCustomSupabaseConfig('', '');
    window.location.reload();
  };

  const copySqlSchemaSnippet = () => {
    const schemaSql = `-- Run this in Supabase SQL Editor:
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID REFERENCES auth.users ON DELETE CASCADE PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  display_name TEXT NOT NULL,
  avatar_url TEXT,
  bio TEXT,
  phone_number TEXT,
  last_seen TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  online_status TEXT DEFAULT 'offline' NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);
-- Enable Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.profiles, public.messages, public.conversations;
`;
    navigator.clipboard.writeText(schemaSql);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4 animate-in fade-in duration-200 select-none">
      <div className="bg-card w-full max-w-lg rounded-3xl border border-border p-6 shadow-2xl flex flex-col gap-4 max-h-[85vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5 font-display font-semibold text-lg text-foreground">
            <div className="p-2 rounded-xl bg-accent-soft text-accent">
              <Database size={18} />
            </div>
            <span>Supabase Cloud Sync</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-muted hover:text-foreground rounded-xl hover:bg-input transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Current status banner */}
        <div
          className={`p-3.5 rounded-2xl border flex items-center justify-between gap-3 text-xs ${
            isConfigured
              ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-500'
              : 'bg-accent-soft border-accent/20 text-accent'
          }`}
        >
          <div className="flex items-center gap-2">
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                isConfigured ? 'bg-emerald-500' : 'bg-accent'
              } animate-pulse`}
            />
            <span className="font-semibold">
              {isConfigured ? 'Connected to Supabase Project' : 'Supabase Not Connected'}
            </span>
          </div>

          {isConfigured && (
            <button
              onClick={handleResetSandbox}
              className="text-[11px] underline hover:opacity-80"
            >
              Disconnect
            </button>
          )}
        </div>

        <p className="text-xs text-muted leading-relaxed">
          Connect your Supabase project to authenticate users, synchronize real-time messages,
          voice calls, contacts, and status stories in real-time across devices.
        </p>

        {/* Fields */}
        <div className="flex flex-col gap-3">
          <div className="flex flex-col gap-1">
            <label className="text-xs font-semibold text-foreground">Project URL:</label>
            <input
              type="text"
              placeholder="https://xyzcompany.supabase.co"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              className="w-full px-3.5 py-2 bg-input text-foreground text-xs rounded-xl border border-border focus:outline-none focus:border-accent font-mono"
            />
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-xs font-semibold text-foreground">Anon / Public API Key:</label>
            <input
              type="password"
              placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
              value={anonKey}
              onChange={(e) => setAnonKey(e.target.value)}
              className="w-full px-3.5 py-2 bg-input text-foreground text-xs rounded-xl border border-border focus:outline-none focus:border-accent font-mono"
            />
          </div>
        </div>

        {/* Feedback message */}
        {message && (
          <div
            className={`p-3 rounded-xl border text-xs flex items-center gap-2 ${
              status === 'error'
                ? 'bg-rose-500/10 border-rose-500/20 text-rose-500'
                : 'bg-emerald-500/10 border-emerald-500/20 text-emerald-500'
            }`}
          >
            {status === 'error' ? <AlertCircle size={15} /> : <Check size={15} />}
            <span>{message}</span>
          </div>
        )}

        {/* Copy SQL Schema button */}
        <div className="p-3.5 bg-input/40 rounded-2xl border border-border flex items-center justify-between gap-2">
          <div className="text-xs">
            <span className="font-semibold text-foreground block">Database Schema SQL</span>
            <span className="text-muted text-[11px]">Copy table structure & RLS policies</span>
          </div>
          <button
            onClick={copySqlSchemaSnippet}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-input hover:bg-border/60 text-xs font-medium text-foreground rounded-xl transition-colors"
          >
            {copied ? <Check size={13} className="text-emerald-500" /> : <Copy size={13} />}
            <span>{copied ? 'Copied' : 'Copy SQL'}</span>
          </button>
        </div>

        {/* Actions */}
        <div className="flex items-center justify-end gap-2 mt-2 pt-2 border-t border-border">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-muted hover:text-foreground hover:bg-input transition-colors"
          >
            Close
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={status === 'testing'}
            className="flex items-center gap-2 px-5 py-2 bg-accent text-white rounded-xl text-xs font-semibold hover:opacity-95 shadow-md shadow-accent/25 transition-all"
          >
            {status === 'testing' ? (
              <>
                <RefreshCw size={13} className="animate-spin" />
                <span>Connecting...</span>
              </>
            ) : (
              <span>Save & Connect</span>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
