import React, { useState, useRef } from 'react';
import {
  User,
  Palette,
  Shield,
  MessageSquare,
  Bell,
  LogOut,
  Check,
  Save,
  Trash2,
  Camera,
  Loader2,
  Phone,
  UserPlus,
  CheckCheck,
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useTheme } from '../../contexts/ThemeContext';
import { useChat } from '../../contexts/ChatContext';
import { Avatar } from '../common/Avatar';
import { AppearanceSettings } from './AppearanceSettings';
import { uploadAvatar } from '../../services/storageService';

export const SettingsView: React.FC = () => {
  const { user, updateProfile, signOut } = useAuth();
  const {
    notifications,
    unreadNotificationsCount,
    markNotificationAsRead,
    markAllNotificationsAsRead,
    deleteNotification,
  } = useChat();
  const [activeTab, setActiveTab] = useState<
    'account' | 'appearance' | 'privacy' | 'chats' | 'notifications'
  >('account');

  const [displayName, setDisplayName] = useState(user?.display_name || '');
  const [username, setUsername] = useState(user?.username || '');
  const [bio, setBio] = useState(user?.bio || '');
  const [phone, setPhone] = useState(user?.phone_number || '');
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Privacy states
  const [readReceipts, setReadReceipts] = useState(true);
  const [onlineVisibility, setOnlineVisibility] = useState<'everyone' | 'contacts' | 'nobody'>(
    'everyone'
  );
  const [lastSeenVisibility, setLastSeenVisibility] = useState<'everyone' | 'contacts' | 'nobody'>(
    'everyone'
  );

  // Chat settings
  const [enterToSend, setEnterToSend] = useState(true);
  const [soundEffects, setSoundEffects] = useState(true);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const avatarInputRef = useRef<HTMLInputElement | null>(null);

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user?.id) return;

    setUploadingAvatar(true);
    try {
      const avatarUrl = await uploadAvatar(file);
      await updateProfile({ avatar_url: avatarUrl });
    } catch (err) {
      console.error('Failed to upload avatar:', err);
    } finally {
      setUploadingAvatar(false);
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateProfile({
      display_name: displayName.trim(),
      username: username.trim().startsWith('@') ? username.trim() : `@${username.trim()}`,
      bio: bio.trim(),
      phone_number: phone.trim(),
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  const navItems = [
    { id: 'account', label: 'Account', icon: User },
    { id: 'appearance', label: 'Appearance', icon: Palette },
    { id: 'privacy', label: 'Privacy & Security', icon: Shield },
    { id: 'chats', label: 'Chat Settings', icon: MessageSquare },
    { id: 'notifications', label: 'Notifications', icon: Bell },
  ] as const;

  return (
    <div className="flex-1 flex flex-col h-full bg-sidebar/40 overflow-hidden select-none">
      {/* Header */}
      <div className="p-5 border-b border-border bg-card/60 backdrop-blur-md flex items-center justify-between">
        <div>
          <h2 className="font-display font-bold text-2xl text-foreground tracking-tight">
            Settings
          </h2>
          <p className="text-xs text-muted mt-0.5">
            Manage your account, privacy, theme, and chat preferences
          </p>
        </div>
      </div>

      {/* Main Settings Container: Two column layout on Desktop */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden max-w-6xl mx-auto w-full p-4 sm:p-6 gap-6">
        {/* Settings Navigation Sidebar */}
        <div className="w-full md:w-56 flex md:flex-col gap-1.5 overflow-x-auto md:overflow-visible pb-2 md:pb-0 flex-shrink-0">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-card text-accent shadow-xs border border-border/80'
                    : 'text-muted hover:text-foreground hover:bg-card/50'
                }`}
              >
                <Icon size={16} />
                <span>{item.label}</span>
                {item.id === 'notifications' && unreadNotificationsCount > 0 && (
                  <span className="ml-auto px-1.5 py-0.2 text-[10px] font-bold bg-accent text-white rounded-full">
                    {unreadNotificationsCount}
                  </span>
                )}
              </button>
            );
          })}

          <div className="hidden md:block h-px bg-border my-2" />

          {/* Sign Out */}
          <button
            onClick={signOut}
            className="hidden md:flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold text-rose-500 hover:bg-rose-500/10 transition-colors"
          >
            <LogOut size={16} />
            <span>Sign Out</span>
          </button>
        </div>

        {/* Content Pane */}
        <div className="flex-1 bg-card rounded-2xl md:rounded-3xl border border-border p-4 sm:p-6 overflow-y-auto shadow-xs pb-24 md:pb-6">
          {/* 1. Account Tab */}
          {activeTab === 'account' && (
            <form onSubmit={handleSaveProfile} className="flex flex-col gap-6 max-w-xl">
              <div className="flex items-center gap-4">
                <input
                  ref={avatarInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleAvatarChange}
                  className="hidden"
                />
                <div className="relative group">
                  <Avatar
                    src={user?.avatar_url}
                    name={user?.display_name || 'User'}
                    size="xl"
                  />
                  <button
                    type="button"
                    onClick={() => avatarInputRef.current?.click()}
                    disabled={uploadingAvatar}
                    className="absolute inset-0 rounded-full bg-black/50 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                    title="Change Avatar"
                  >
                    {uploadingAvatar ? (
                      <Loader2 size={20} className="animate-spin" />
                    ) : (
                      <Camera size={20} />
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => avatarInputRef.current?.click()}
                    className="absolute -bottom-1 -right-1 p-1.5 rounded-full bg-accent text-white shadow-sm hover:scale-105 transition-transform"
                    title="Change Avatar"
                  >
                    {uploadingAvatar ? (
                      <Loader2 size={12} className="animate-spin" />
                    ) : (
                      <Camera size={12} />
                    )}
                  </button>
                </div>
                <div>
                  <h3 className="font-display font-semibold text-base text-foreground">
                    {user?.display_name}
                  </h3>
                  <p className="text-xs font-mono text-accent">{user?.username}</p>
                  <p className="text-[11px] text-muted mt-1">{user?.email}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-foreground">Display Name</label>
                  <input
                    type="text"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    className="px-3.5 py-2 bg-input text-foreground text-xs rounded-xl border border-border focus:outline-none focus:border-accent"
                    required
                  />
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-foreground">LIVO Username</label>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="px-3.5 py-2 bg-input text-foreground text-xs rounded-xl border border-border focus:outline-none focus:border-accent font-mono"
                    required
                  />
                </div>
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-foreground">Bio / Status</label>
                <textarea
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  rows={2}
                  className="px-3.5 py-2 bg-input text-foreground text-xs rounded-xl border border-border focus:outline-none focus:border-accent resize-none"
                  placeholder="Hey there! I am using LIVO Messenger."
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-foreground">Phone Number</label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+92 300 1234567"
                  className="px-3.5 py-2 bg-input text-foreground text-xs rounded-xl border border-border focus:outline-none focus:border-accent font-mono"
                />
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-border">
                {savedSuccess ? (
                  <span className="flex items-center gap-1.5 text-xs text-emerald-500 font-semibold">
                    <Check size={15} />
                    <span>Profile saved successfully!</span>
                  </span>
                ) : (
                  <span />
                )}

                <button
                  type="submit"
                  className="flex items-center gap-2 px-5 py-2 bg-accent text-white rounded-xl text-xs font-semibold hover:opacity-95 shadow-md shadow-accent/25 transition-all"
                >
                  <Save size={14} />
                  <span>Save Changes</span>
                </button>
              </div>
            </form>
          )}

          {/* 2. Appearance Tab */}
          {activeTab === 'appearance' && <AppearanceSettings />}

          {/* 3. Privacy & Security */}
          {activeTab === 'privacy' && (
            <div className="flex flex-col gap-6 max-w-xl">
              <div>
                <h3 className="font-display font-semibold text-sm text-foreground">
                  Privacy Settings
                </h3>
                <p className="text-xs text-muted mt-0.5">
                  Control who can see your activity and status on LIVO.
                </p>
              </div>

              {/* Read Receipts */}
              <div className="flex items-center justify-between p-3.5 rounded-2xl bg-input/40 border border-border">
                <div>
                  <span className="font-semibold text-xs text-foreground block">
                    Read Receipts
                  </span>
                  <span className="text-[11px] text-muted">
                    If turned off, you won't send or receive read checkmarks.
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={readReceipts}
                  onChange={(e) => setReadReceipts(e.target.checked)}
                  className="w-4 h-4 accent-accent rounded cursor-pointer"
                />
              </div>

              {/* Online Status */}
              <div className="flex flex-col gap-2">
                <label className="text-xs font-semibold text-foreground">
                  Who can see when I'm online:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['everyone', 'contacts', 'nobody'] as const).map((opt) => (
                    <button
                      key={opt}
                      onClick={() => setOnlineVisibility(opt)}
                      className={`py-2 px-3 rounded-xl border text-xs font-medium capitalize transition-all ${
                        onlineVisibility === opt
                          ? 'bg-accent text-white border-accent'
                          : 'bg-input text-foreground border-border'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>

              {/* Last Seen */}
              <div className="flex flex-col gap-2">
                <label className="text-xs font-semibold text-foreground">
                  Who can see my last seen:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['everyone', 'contacts', 'nobody'] as const).map((opt) => (
                    <button
                      key={opt}
                      onClick={() => setLastSeenVisibility(opt)}
                      className={`py-2 px-3 rounded-xl border text-xs font-medium capitalize transition-all ${
                        lastSeenVisibility === opt
                          ? 'bg-accent text-white border-accent'
                          : 'bg-input text-foreground border-border'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* 4. Chat Settings */}
          {activeTab === 'chats' && (
            <div className="flex flex-col gap-6 max-w-xl">
              <div>
                <h3 className="font-display font-semibold text-sm text-foreground">
                  Chat Preferences
                </h3>
                <p className="text-xs text-muted mt-0.5">
                  Customize your messaging workflow.
                </p>
              </div>

              <div className="flex items-center justify-between p-3.5 rounded-2xl bg-input/40 border border-border">
                <div>
                  <span className="font-semibold text-xs text-foreground block">
                    Enter key sends message
                  </span>
                  <span className="text-[11px] text-muted">
                    Pressing Enter will send immediately instead of inserting newline.
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={enterToSend}
                  onChange={(e) => setEnterToSend(e.target.checked)}
                  className="w-4 h-4 accent-accent rounded cursor-pointer"
                />
              </div>

              <div className="flex items-center justify-between p-3.5 rounded-2xl bg-input/40 border border-border">
                <div>
                  <span className="font-semibold text-xs text-foreground block">
                    Message Sound Effects
                  </span>
                  <span className="text-[11px] text-muted">
                    Play gentle audible cues when sending or receiving.
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={soundEffects}
                  onChange={(e) => setSoundEffects(e.target.checked)}
                  className="w-4 h-4 accent-accent rounded cursor-pointer"
                />
              </div>
            </div>
          )}

          {/* 5. Notifications Tab */}
          {activeTab === 'notifications' && (
            <div className="flex flex-col gap-6 max-w-2xl">
              <div>
                <h3 className="font-display font-semibold text-base text-foreground">
                  Notifications & Alerts
                </h3>
                <p className="text-xs text-muted mt-0.5">
                  Manage your notification preferences and view all direct interaction alerts.
                </p>
              </div>

              {/* Notification Preferences */}
              <div className="flex flex-col gap-2.5">
                <span className="text-xs font-semibold text-muted uppercase tracking-wider px-1">
                  Alert Preferences
                </span>

                <div className="p-4 rounded-2xl bg-input/30 border border-border flex items-center justify-between">
                  <div>
                    <span className="font-semibold text-xs text-foreground block">
                      Direct Message Notifications
                    </span>
                    <span className="text-[11px] text-muted">
                      Show notification alerts for incoming direct and group messages.
                    </span>
                  </div>
                  <input type="checkbox" defaultChecked className="w-4 h-4 accent-accent rounded" />
                </div>

                <div className="p-4 rounded-2xl bg-input/30 border border-border flex items-center justify-between">
                  <div>
                    <span className="font-semibold text-xs text-foreground block">
                      Incoming Call Ring
                    </span>
                    <span className="text-[11px] text-muted">
                      Play ringing alert for incoming WebRTC audio and video calls.
                    </span>
                  </div>
                  <input type="checkbox" defaultChecked className="w-4 h-4 accent-accent rounded" />
                </div>
              </div>

              {/* Real Notifications Inbox / History */}
              <div className="flex flex-col gap-3 pt-2">
                <div className="flex items-center justify-between px-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-muted uppercase tracking-wider">
                      Recent Activity ({notifications.length})
                    </span>
                    {unreadNotificationsCount > 0 && (
                      <span className="px-1.5 py-0.2 text-[10px] font-bold bg-accent text-white rounded-full">
                        {unreadNotificationsCount} unread
                      </span>
                    )}
                  </div>

                  {unreadNotificationsCount > 0 && (
                    <button
                      onClick={() => markAllNotificationsAsRead()}
                      className="text-xs font-semibold text-accent hover:underline flex items-center gap-1"
                    >
                      <CheckCheck size={14} />
                      <span>Mark all read</span>
                    </button>
                  )}
                </div>

                {notifications.length === 0 ? (
                  <div className="p-8 rounded-2xl bg-card border border-dashed border-border text-center flex flex-col items-center justify-center gap-2">
                    <div className="w-10 h-10 rounded-2xl bg-accent-soft text-accent flex items-center justify-center">
                      <Bell size={20} />
                    </div>
                    <p className="text-xs font-semibold text-foreground">No Notifications Yet</p>
                    <p className="text-xs text-muted">
                      You are completely caught up. Incoming messages, calls, and contact updates will appear here.
                    </p>
                  </div>
                ) : (
                  <div className="flex flex-col gap-2">
                    {notifications.map((n) => {
                      const isUnread = !n.read;
                      return (
                        <div
                          key={n.id}
                          onClick={() => {
                            if (isUnread) markNotificationAsRead(n.id);
                          }}
                          className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between gap-3 cursor-pointer ${
                            isUnread
                              ? 'bg-card border-accent/40 shadow-xs'
                              : 'bg-card/60 border-border/70 opacity-80'
                          }`}
                        >
                          <div className="flex items-center gap-3 min-w-0 flex-1">
                            <div className="p-2 rounded-xl bg-input text-accent flex-shrink-0">
                              {n.type === 'message' ? (
                                <MessageSquare size={16} />
                              ) : n.type === 'call' ? (
                                <Phone size={16} />
                              ) : n.type === 'contact_request' ? (
                                <UserPlus size={16} />
                              ) : (
                                <Bell size={16} />
                              )}
                            </div>

                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-2">
                                <h4 className="text-xs font-semibold text-foreground truncate">
                                  {n.title}
                                </h4>
                                {isUnread && (
                                  <span className="w-2 h-2 rounded-full bg-accent flex-shrink-0" />
                                )}
                              </div>
                              <p className="text-xs text-muted truncate mt-0.5">{n.body}</p>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 flex-shrink-0">
                            <span className="text-[10px] text-muted font-mono">
                              {new Date(n.created_at).toLocaleTimeString([], {
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                            </span>

                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                deleteNotification(n.id);
                              }}
                              className="p-1.5 text-muted hover:text-rose-500 rounded-lg hover:bg-rose-500/10 transition-colors"
                              title="Delete notification"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
