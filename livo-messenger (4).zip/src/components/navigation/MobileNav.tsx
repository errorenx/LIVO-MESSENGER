import React from 'react';
import { MessageSquare, Users, CircleDot, Phone, Settings, Bell } from 'lucide-react';
import { MainTab } from './Sidebar';
import { useChat } from '../../contexts/ChatContext';

interface MobileNavProps {
  currentTab?: MainTab;
  activeTab?: MainTab;
  onSelectTab: (tab: MainTab) => void;
  unreadNotifications?: number;
}

export const MobileNav: React.FC<MobileNavProps> = ({ currentTab, activeTab, onSelectTab }) => {
  const selectedTab = currentTab || activeTab || 'chats';
  const { contactRequests, statuses } = useChat();

  const unreadStatusesCount = statuses.filter((s) => !s.has_viewed).length;
  const pendingRequestsCount = contactRequests.length;

  const items = [
    { id: 'chats' as MainTab, label: 'Chats', icon: MessageSquare, badge: 0 },
    { id: 'contacts' as MainTab, label: 'Contacts', icon: Users, badge: pendingRequestsCount },
    { id: 'status' as MainTab, label: 'Status', icon: CircleDot, badge: unreadStatusesCount, isDot: true },
    { id: 'calls' as MainTab, label: 'Calls', icon: Phone, badge: 0 },
    { id: 'settings' as MainTab, label: 'Settings', icon: Settings, badge: 0 },
  ];

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 h-16 bg-sidebar/95 backdrop-blur-lg border-t border-border flex items-center justify-around px-2 z-30 select-none">
      {items.map((item) => {
        const isActive = selectedTab === item.id;
        const Icon = item.icon;

        return (
          <button
            key={item.id}
            onClick={() => onSelectTab(item.id)}
            className={`relative flex flex-col items-center justify-center py-1 px-3 rounded-xl transition-all ${
              isActive ? 'text-accent' : 'text-muted hover:text-foreground'
            }`}
          >
            <Icon size={20} className={isActive ? 'scale-110' : ''} />
            <span className={`text-[10px] mt-1 font-medium ${isActive ? 'font-semibold' : ''}`}>
              {item.label}
            </span>

            {/* Badge indicator */}
            {item.badge > 0 && !item.isDot && (
              <span className="absolute top-1 right-2 px-1 py-0.2 min-w-3.5 text-[9px] font-bold text-white bg-rose-500 rounded-full flex items-center justify-center">
                {item.badge}
              </span>
            )}

            {item.badge > 0 && item.isDot && !isActive && (
              <span className="absolute top-1.5 right-3.5 w-2 h-2 bg-accent rounded-full animate-pulse" />
            )}
          </button>
        );
      })}
    </nav>
  );
};
