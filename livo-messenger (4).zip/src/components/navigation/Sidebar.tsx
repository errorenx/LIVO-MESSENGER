import React from 'react';
import {
  MessageSquare,
  Users,
  Phone,
  CircleDot,
  Bell,
  Settings,
  Sun,
  Moon,
  Sparkles,
} from 'lucide-react';
import { Logo } from '../common/Logo';
import { Avatar } from '../common/Avatar';
import { useAuth } from '../../contexts/AuthContext';
import { useChat } from '../../contexts/ChatContext';
import { useTheme } from '../../contexts/ThemeContext';

export type MainTab = 'chats' | 'contacts' | 'status' | 'calls' | 'settings';

interface SidebarProps {
  currentTab?: MainTab;
  activeTab?: MainTab;
  onSelectTab: (tab: MainTab) => void;
  onOpenProfile?: () => void;
  unreadNotifications?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  activeTab,
  onSelectTab,
  onOpenProfile,
}) => {
  const selectedTab = currentTab || activeTab || 'chats';
  const { user } = useAuth();
  const { contactRequests, statuses } = useChat();

  const unreadStatusesCount = statuses.filter((s) => !s.has_viewed).length;
  const pendingRequestsCount = contactRequests.length;

  const { themeMode, setThemeMode } = useTheme();

  const handleToggleTheme = () => {
    if (themeMode === 'black') setThemeMode('white');
    else if (themeMode === 'white') setThemeMode('rainbow');
    else setThemeMode('black');
  };

  const navItems = [
    {
      id: 'chats' as MainTab,
      label: 'Chats',
      icon: MessageSquare,
      badge: 0,
    },
    {
      id: 'contacts' as MainTab,
      label: 'Contacts',
      icon: Users,
      badge: pendingRequestsCount,
    },
    {
      id: 'status' as MainTab,
      label: 'Status',
      icon: CircleDot,
      badge: unreadStatusesCount,
      isDot: true,
    },
    {
      id: 'calls' as MainTab,
      label: 'Calls',
      icon: Phone,
      badge: 0,
    },
    {
      id: 'settings' as MainTab,
      label: 'Settings',
      icon: Settings,
      badge: 0,
    },
  ];

  return (
    <aside className="hidden md:flex flex-col items-center justify-between w-20 py-5 bg-sidebar border-r border-border select-none z-30">
      {/* Brand Top */}
      <div className="flex flex-col items-center gap-6">
        <button
          onClick={() => onSelectTab('chats')}
          className="focus:outline-none focus-visible:ring-2 ring-accent rounded-xl"
          title="LIVO — Connect. Talk. Share."
        >
          <Logo size="md" showText={false} />
        </button>

        {/* Nav Tabs */}
        <nav className="flex flex-col items-center gap-2">
          {navItems.map((item) => {
            const isActive = selectedTab === item.id;
            const Icon = item.icon;

            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id)}
                className={`relative w-12 h-12 rounded-2xl flex items-center justify-center transition-all duration-200 group ${
                  isActive
                    ? 'bg-accent text-white shadow-lg shadow-accent/30 scale-105'
                    : 'text-muted hover:text-foreground hover:bg-input'
                }`}
                title={item.label}
              >
                <Icon size={21} className="transition-transform group-hover:scale-110" />

                {/* Badge indicator */}
                {item.badge > 0 && !item.isDot && (
                  <span className="absolute -top-1 -right-1 px-1.5 py-0.5 min-w-4 text-[10px] font-bold text-white bg-rose-500 rounded-full flex items-center justify-center shadow-sm">
                    {item.badge}
                  </span>
                )}

                {item.badge > 0 && item.isDot && !isActive && (
                  <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-accent rounded-full ring-2 ring-sidebar animate-pulse" />
                )}

                {/* Left Active Indicator Bar */}
                {isActive && (
                  <span className="absolute -left-3 w-1.5 h-6 bg-accent rounded-r-full" />
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Bottom Actions & Profile */}
      <div className="flex flex-col items-center gap-3">
        {/* Quick Theme Switcher */}
        <button
          onClick={handleToggleTheme}
          className="w-10 h-10 rounded-xl flex items-center justify-center text-muted hover:text-foreground hover:bg-input border border-border/60 transition-all shadow-xs"
          title={`Current theme: ${themeMode.toUpperCase()} (Click to toggle White/Black/Rainbow)`}
        >
          {themeMode === 'white' ? (
            <Sun size={18} className="text-amber-500 animate-in fade-in" />
          ) : themeMode === 'rainbow' ? (
            <Sparkles size={18} className="text-pink-500 animate-in fade-in" />
          ) : (
            <Moon size={18} className="text-blue-400 animate-in fade-in" />
          )}
        </button>

        {/* User profile avatar */}
        {user && (
          <button
            onClick={onOpenProfile}
            className="relative group p-0.5 rounded-full hover:ring-2 ring-accent transition-all"
            title={`${user.display_name} (${user.username})`}
          >
            <Avatar
              src={user.avatar_url}
              name={user.display_name}
              size="md"
              status={user.online_status}
              showStatus={true}
            />
          </button>
        )}
      </div>
    </aside>
  );
};
