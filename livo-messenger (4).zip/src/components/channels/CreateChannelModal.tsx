import React, { useState } from 'react';
import { X, Radio, Hash, Info, Check } from 'lucide-react';
import { useChat } from '../../contexts/ChatContext';

interface CreateChannelModalProps {
  onClose: () => void;
}

export const CreateChannelModal: React.FC<CreateChannelModalProps> = ({ onClose }) => {
  const { createChannel } = useChat();
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    setErrorMsg(null);
    setIsSubmitting(true);
    try {
      await createChannel(name.trim(), description.trim());
      setIsSubmitting(false);
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to create channel');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-in fade-in duration-200 select-none">
      <div className="bg-card w-full max-w-md rounded-3xl border border-border p-6 shadow-2xl flex flex-col gap-4 max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5 font-display font-semibold text-lg text-foreground">
            <div className="p-2 rounded-xl bg-accent-soft text-accent">
              <Radio size={18} />
            </div>
            <span>Create New Channel</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-muted hover:text-foreground rounded-xl hover:bg-input transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        <p className="text-xs text-muted leading-relaxed">
          Channels are one-to-many broadcast streams. As the creator, you can broadcast announcements, updates, and media to all subscribers.
        </p>

        {errorMsg && (
          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-500 text-xs">
            {errorMsg}
          </div>
        )}

        <form onSubmit={handleCreate} className="flex flex-col gap-4">
          <div className="flex flex-col gap-2.5">
            <div>
              <label className="text-xs font-semibold text-foreground mb-1 block">
                Channel Name *
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-2.5 text-muted">
                  <Hash size={16} />
                </span>
                <input
                  type="text"
                  placeholder="e.g. tech-announcements"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full pl-9 pr-4 py-2.5 bg-input text-foreground text-sm rounded-xl border border-border focus:outline-none focus:border-accent"
                  autoFocus
                  required
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-foreground mb-1 block">
                Description & Purpose
              </label>
              <textarea
                rows={3}
                placeholder="What is this channel about? (optional)"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full px-4 py-2 bg-input text-foreground text-xs rounded-xl border border-border focus:outline-none focus:border-accent resize-none"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 mt-2 pt-2 border-t border-border">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-muted hover:text-foreground hover:bg-input transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!name.trim() || isSubmitting}
              className="px-5 py-2 bg-accent text-white rounded-xl text-xs font-semibold hover:opacity-95 shadow-md shadow-accent/25 transition-all disabled:opacity-50 flex items-center gap-1.5"
            >
              <Check size={14} />
              <span>{isSubmitting ? 'Creating...' : 'Create Channel'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
