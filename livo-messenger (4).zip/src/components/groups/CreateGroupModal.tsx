import React, { useState } from 'react';
import { X, Users, Check, Image as ImageIcon } from 'lucide-react';
import { useChat } from '../../contexts/ChatContext';
import { Avatar } from '../common/Avatar';

interface CreateGroupModalProps {
  onClose: () => void;
}

export const CreateGroupModal: React.FC<CreateGroupModalProps> = ({ onClose }) => {
  const { contacts, createGroupChat } = useChat();
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [selectedUserIds, setSelectedUserIds] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const toggleSelect = (id: string) => {
    setSelectedUserIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    setErrorMsg(null);
    setIsSubmitting(true);
    try {
      await createGroupChat(name.trim(), description.trim(), selectedUserIds);
      setIsSubmitting(false);
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to create group');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-in fade-in duration-200 select-none">
      <div className="bg-card w-full max-w-md rounded-3xl border border-border p-6 shadow-2xl flex flex-col gap-4 max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5 font-display font-semibold text-lg text-foreground">
            <div className="p-2 rounded-xl bg-accent-soft text-accent">
              <Users size={18} />
            </div>
            <span>Create New Group</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-muted hover:text-foreground rounded-xl hover:bg-input transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {errorMsg && (
          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-500 text-xs">
            {errorMsg}
          </div>
        )}

        <form onSubmit={handleCreate} className="flex flex-col gap-4 overflow-hidden">
          {/* Name & Desc */}
          <div className="flex flex-col gap-2.5">
            <input
              type="text"
              placeholder="Group Name *"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-2.5 bg-input text-foreground text-sm rounded-xl border border-border focus:outline-none focus:border-accent"
              autoFocus
              required
            />
            <input
              type="text"
              placeholder="Group Description (optional)"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-4 py-2 bg-input text-foreground text-xs rounded-xl border border-border focus:outline-none focus:border-accent"
            />
          </div>

          {/* Members Checklist */}
          <div className="flex flex-col gap-1.5 min-h-0">
            <label className="text-xs font-semibold text-muted">
              Add Members ({selectedUserIds.length} selected):
            </label>
            <div className="max-h-52 overflow-y-auto divide-y divide-border/40 border border-border/60 rounded-xl p-1 bg-input/20">
              {contacts.length === 0 ? (
                <div className="p-4 text-center text-xs text-muted">
                  No contacts available to add.
                </div>
              ) : (
                contacts.map(({ contact_profile }) => {
                  const isSelected = selectedUserIds.includes(contact_profile.id);

                  return (
                    <div
                      key={contact_profile.id}
                      onClick={() => toggleSelect(contact_profile.id)}
                      className="flex items-center justify-between p-2 rounded-lg hover:bg-input cursor-pointer transition-colors"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <Avatar
                          src={contact_profile.avatar_url}
                          name={contact_profile.display_name}
                          size="sm"
                        />
                        <div className="min-w-0">
                          <span className="font-semibold text-xs text-foreground block truncate">
                            {contact_profile.display_name}
                          </span>
                          <span className="text-[11px] font-mono text-muted block truncate">
                            {contact_profile.username}
                          </span>
                        </div>
                      </div>

                      <div
                        className={`w-5 h-5 rounded-md border flex items-center justify-center transition-colors ${
                          isSelected
                            ? 'bg-accent border-accent text-white'
                            : 'border-border bg-card'
                        }`}
                      >
                        {isSelected && <Check size={13} />}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-2 mt-2 pt-2 border-t border-border">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-muted hover:text-foreground hover:bg-input transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!name.trim() || isSubmitting}
              className="px-5 py-2 bg-accent text-white rounded-xl text-xs font-semibold hover:opacity-95 shadow-md shadow-accent/25 transition-all disabled:opacity-50"
            >
              {isSubmitting ? 'Creating...' : 'Create Group'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
