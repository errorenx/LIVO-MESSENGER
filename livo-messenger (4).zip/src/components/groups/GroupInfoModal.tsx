import React from 'react';
import { X, Users, Crown, Shield, LogOut, Trash2 } from 'lucide-react';
import { Conversation } from '../../types';
import { useAuth } from '../../contexts/AuthContext';
import { useChat } from '../../contexts/ChatContext';
import { Avatar } from '../common/Avatar';

interface GroupInfoModalProps {
  conversation: Conversation;
  onClose: () => void;
}

export const GroupInfoModal: React.FC<GroupInfoModalProps> = ({ conversation, onClose }) => {
  const { user } = useAuth();
  const { leaveGroup } = useChat();

  const isGroup = conversation.type === 'group';
  const isAdmin = conversation.members.some(
    (m) => m.user_id === user?.id && m.role === 'admin'
  );

  const handleLeave = () => {
    if (confirm('Are you sure you want to leave this group?')) {
      leaveGroup(conversation.id);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-in fade-in duration-200 select-none">
      <div className="bg-card w-full max-w-md rounded-3xl border border-border p-6 shadow-2xl flex flex-col gap-4 max-h-[85vh]">
        {/* Top */}
        <div className="flex items-center justify-between">
          <h3 className="font-display font-semibold text-foreground text-base">
            {isGroup ? 'Group Overview' : 'Contact Overview'}
          </h3>
          <button
            onClick={onClose}
            className="p-1.5 text-muted hover:text-foreground rounded-xl hover:bg-input transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Avatar & Title */}
        <div className="flex flex-col items-center text-center gap-2 py-2">
          <Avatar
            src={conversation.avatar_url}
            name={conversation.name || 'Chat'}
            size="xl"
          />
          <h2 className="font-display font-bold text-xl text-foreground mt-1">
            {conversation.name}
          </h2>
          {conversation.description && (
            <p className="text-xs text-muted max-w-xs leading-relaxed">
              {conversation.description}
            </p>
          )}
        </div>

        {/* Member List */}
        {isGroup && (
          <div className="flex flex-col gap-2 min-h-0 flex-1">
            <span className="text-xs font-semibold text-muted px-1">
              Participants ({conversation.members.length})
            </span>
            <div className="overflow-y-auto divide-y divide-border/40 border border-border/60 rounded-2xl p-1 bg-input/20 max-h-56">
              {conversation.members.map((member) => (
                <div
                  key={member.id}
                  className="flex items-center justify-between p-2.5 rounded-xl hover:bg-input/60 transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <Avatar
                      src={member.profile?.avatar_url}
                      name={member.profile?.display_name || 'Member'}
                      size="sm"
                    />
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="font-semibold text-xs text-foreground truncate">
                          {member.profile?.display_name || 'User'}
                        </span>
                        {member.user_id === user?.id && (
                          <span className="text-[10px] text-muted font-medium">(You)</span>
                        )}
                      </div>
                      <span className="text-[11px] font-mono text-muted block truncate">
                        {member.profile?.username || `@usr_${member.user_id.slice(0, 5)}`}
                      </span>
                    </div>
                  </div>

                  {member.role === 'admin' && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-semibold bg-accent-soft text-accent rounded-full border border-accent/30">
                      <Crown size={10} />
                      <span>Admin</span>
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Actions */}
        {isGroup && (
          <div className="pt-2 border-t border-border flex flex-col gap-1.5">
            <button
              onClick={handleLeave}
              className="w-full flex items-center justify-center gap-2 p-2.5 rounded-xl text-xs font-semibold text-rose-500 hover:bg-rose-500/10 transition-colors"
            >
              <LogOut size={16} />
              <span>Exit Group</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
