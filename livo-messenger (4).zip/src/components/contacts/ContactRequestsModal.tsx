import React from 'react';
import { X, Check, Clock } from 'lucide-react';
import { useChat } from '../../contexts/ChatContext';
import { Avatar } from '../common/Avatar';

interface ContactRequestsModalProps {
  onClose: () => void;
}

export const ContactRequestsModal: React.FC<ContactRequestsModalProps> = ({ onClose }) => {
  const { contactRequests, acceptContactRequest, rejectContactRequest } = useChat();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-card w-full max-w-lg rounded-3xl border border-border p-6 shadow-2xl flex flex-col gap-4 select-none max-h-[80vh]">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 font-display font-semibold text-lg text-foreground">
            <Clock size={18} className="text-accent" />
            <span>Pending Contact Requests</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-muted hover:text-foreground rounded-xl hover:bg-input transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto divide-y divide-border/40 min-h-[160px]">
          {contactRequests.length === 0 ? (
            <div className="py-12 text-center text-muted text-xs">
              No pending contact requests at this time.
            </div>
          ) : (
            contactRequests.map((req) => (
              <div key={req.id} className="py-3 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3 min-w-0">
                  <Avatar
                    src={req.sender_profile.avatar_url}
                    name={req.sender_profile.display_name}
                    size="md"
                  />
                  <div className="min-w-0">
                    <h4 className="font-semibold text-sm text-foreground truncate">
                      {req.sender_profile.display_name}
                    </h4>
                    <p className="text-xs font-mono text-accent">
                      {req.sender_profile.username}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => acceptContactRequest(req.id)}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-accent text-white text-xs font-semibold rounded-xl hover:opacity-90 shadow-sm transition-all active:scale-95"
                  >
                    <Check size={14} />
                    <span>Accept</span>
                  </button>
                  <button
                    onClick={() => rejectContactRequest(req.id)}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-input text-muted hover:text-foreground text-xs font-semibold rounded-xl hover:bg-border/60 transition-colors"
                  >
                    <X size={14} />
                    <span>Decline</span>
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
