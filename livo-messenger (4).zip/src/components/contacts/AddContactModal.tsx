import React, { useState, useEffect } from 'react';
import { X, Search, UserPlus, AlertCircle, CheckCircle2, Loader2, Check } from 'lucide-react';
import { useChat } from '../../contexts/ChatContext';
import { useAuth } from '../../contexts/AuthContext';
import { searchUsers } from '../../services/profileService';
import { UserProfile } from '../../types';
import { Avatar } from '../common/Avatar';

interface AddContactModalProps {
  onClose: () => void;
}

export const AddContactModal: React.FC<AddContactModalProps> = ({ onClose }) => {
  const { sendContactRequest, contacts, contactRequests } = useChat();
  const { user } = useAuth();

  const [query, setQuery] = useState('');
  const [searchResults, setSearchResults] = useState<UserProfile[]>([]);
  const [searching, setSearching] = useState(false);
  const [sentMap, setSentMap] = useState<Record<string, boolean>>({});
  const [errorMessage, setErrorMessage] = useState('');

  // Real-time search debounce
  useEffect(() => {
    if (!query.trim() || !user?.id) {
      setSearchResults([]);
      setSearching(false);
      return;
    }

    setSearching(true);
    setErrorMessage('');

    const timer = setTimeout(async () => {
      try {
        const results = await searchUsers(query.trim(), user.id);
        setSearchResults(results);
      } catch (err) {
        console.warn('Notice searching users:', err);
      } finally {
        setSearching(false);
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [query, user?.id]);

  const handleSendToUser = async (targetUser: UserProfile) => {
    setErrorMessage('');
    const res = await sendContactRequest(targetUser.id);
    if (res.success) {
      setSentMap((prev) => ({ ...prev, [targetUser.id]: true }));
    } else {
      setErrorMessage(res.error || 'Failed to send contact request.');
    }
  };

  const isAlreadyContact = (userId: string) =>
    contacts.some((c) => c.contact_user_id === userId);

  const hasPendingRequest = (userId: string) =>
    contactRequests.some((r) => r.sender_id === userId || r.receiver_id === userId) ||
    Boolean(sentMap[userId]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-card w-full max-w-md rounded-3xl border border-border p-6 shadow-2xl flex flex-col gap-5 select-none max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5 font-display font-semibold text-lg text-foreground">
            <div className="p-2 rounded-xl bg-accent/15 text-accent">
              <UserPlus size={18} />
            </div>
            <span>Add LIVO Contact</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-muted hover:text-foreground rounded-xl hover:bg-input transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        <p className="text-xs text-muted leading-relaxed">
          Search for registered LIVO members by display name or unique @username to send a real contact request.
        </p>

        {/* Search Input */}
        <div className="relative">
          <Search size={17} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" />
          <input
            type="text"
            placeholder="Type name or @username..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full pl-10 pr-10 py-2.5 bg-input text-foreground text-sm rounded-xl border border-border focus:outline-none focus:border-accent font-mono transition-all"
            autoFocus
          />
          {searching && (
            <Loader2 size={16} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-accent animate-spin" />
          )}
        </div>

        {/* Error Feedback */}
        {errorMessage && (
          <div className="flex items-center gap-2 p-3 bg-rose-500/10 border border-rose-500/20 text-rose-500 rounded-xl text-xs">
            <AlertCircle size={16} className="flex-shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Search Results List */}
        <div className="flex-1 overflow-y-auto flex flex-col gap-2.5 max-h-64 pr-1">
          {query.trim().length > 0 && !searching && searchResults.length === 0 && (
            <div className="py-8 text-center text-muted text-xs">
              No registered LIVO users found matching "{query}".
            </div>
          )}

          {searchResults.map((target) => {
            const alreadyFriend = isAlreadyContact(target.id);
            const pending = hasPendingRequest(target.id);

            return (
              <div
                key={target.id}
                className="flex items-center justify-between p-3 rounded-2xl bg-secondary/40 border border-border/60 hover:border-accent/40 transition-all gap-3"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <Avatar
                    src={target.avatar_url}
                    name={target.display_name}
                    size="md"
                    status={target.online_status}
                    showStatus={true}
                  />
                  <div className="min-w-0">
                    <h4 className="font-semibold text-xs text-foreground truncate">
                      {target.display_name}
                    </h4>
                    <p className="text-[11px] font-mono text-accent truncate">
                      {target.username}
                    </p>
                  </div>
                </div>

                <div>
                  {alreadyFriend ? (
                    <span className="px-3 py-1.5 rounded-xl bg-emerald-500/15 text-emerald-500 text-[11px] font-semibold flex items-center gap-1">
                      <Check size={13} />
                      <span>Contact</span>
                    </span>
                  ) : pending ? (
                    <span className="px-3 py-1.5 rounded-xl bg-input text-muted text-[11px] font-semibold flex items-center gap-1">
                      <CheckCircle2 size={13} className="text-accent" />
                      <span>Requested</span>
                    </span>
                  ) : (
                    <button
                      onClick={() => handleSendToUser(target)}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-accent text-white text-[11px] font-semibold rounded-xl hover:opacity-95 shadow-xs transition-all active:scale-95"
                    >
                      <UserPlus size={13} />
                      <span>Add</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end pt-2 border-t border-border">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-muted hover:text-foreground hover:bg-input transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
