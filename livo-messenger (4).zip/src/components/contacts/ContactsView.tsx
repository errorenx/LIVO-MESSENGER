import React, { useState } from 'react';
import {
  Users,
  UserPlus,
  Plus,
  MessageSquare,
  Phone,
  Video,
  UserMinus,
  Ban,
  Search,
  Clock,
  Check,
  X,
  ShieldCheck,
} from 'lucide-react';
import { useChat } from '../../contexts/ChatContext';
import { useCall } from '../../contexts/CallContext';
import { Avatar } from '../common/Avatar';
import { UserProfile } from '../../types';

interface ContactsViewProps {
  onOpenAddContact: () => void;
  onOpenRequests: () => void;
  onStartChatWithUser: (user: UserProfile) => void;
}

export const ContactsView: React.FC<ContactsViewProps> = ({
  onOpenAddContact,
  onOpenRequests,
  onStartChatWithUser,
}) => {
  const {
    contacts,
    contactRequests,
    removeContact,
    blockUser,
    blockedUsers,
    unblockUser,
    acceptContactRequest,
    rejectContactRequest,
  } = useChat();

  const { startCall } = useCall();
  const [tab, setTab] = useState<'contacts' | 'requests' | 'blocked'>('contacts');
  const [query, setQuery] = useState('');

  const filteredContacts = contacts.filter(
    (c) =>
      c.contact_profile.display_name.toLowerCase().includes(query.toLowerCase()) ||
      c.contact_profile.username.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="flex-1 flex flex-col h-full bg-sidebar/40 overflow-hidden select-none">
      {/* Top Header */}
      <div className="p-5 border-b border-border flex flex-col gap-4 bg-card/60 backdrop-blur-md">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="font-display font-bold text-2xl text-foreground tracking-tight">
              Contacts
            </h2>
            <p className="text-xs text-muted mt-0.5">
              Connect directly with verified LIVO users
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onOpenRequests}
              className="relative p-2 text-muted hover:text-foreground rounded-xl hover:bg-input transition-colors border border-border"
              title="Contact Requests"
            >
              <Clock size={18} />
              {contactRequests.length > 0 && (
                <span className="absolute -top-1 -right-1 px-1.5 py-0.2 min-w-4 text-[9px] font-bold text-white bg-accent rounded-full flex items-center justify-center">
                  {contactRequests.length}
                </span>
              )}
            </button>
            <button
              onClick={onOpenAddContact}
              className="flex items-center gap-2 px-4 py-2 bg-accent text-white rounded-xl text-xs font-semibold hover:opacity-95 shadow-md shadow-accent/25 transition-all active:scale-95"
            >
              <UserPlus size={16} />
              <span>Add Contact</span>
            </button>
          </div>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center gap-2 border-b border-border/40 pb-2 text-xs font-semibold">
          <button
            onClick={() => setTab('contacts')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              tab === 'contacts' ? 'bg-accent text-white shadow-xs' : 'text-muted hover:text-foreground'
            }`}
          >
            All Contacts ({contacts.length})
          </button>
          <button
            onClick={() => setTab('requests')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              tab === 'requests' ? 'bg-accent text-white shadow-xs' : 'text-muted hover:text-foreground'
            }`}
          >
            Requests ({contactRequests.length})
          </button>
          <button
            onClick={() => setTab('blocked')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              tab === 'blocked' ? 'bg-accent text-white shadow-xs' : 'text-muted hover:text-foreground'
            }`}
          >
            Blocked ({blockedUsers.length})
          </button>
        </div>

        {/* Search */}
        {tab === 'contacts' && (
          <div className="relative">
            <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" />
            <input
              type="text"
              placeholder="Search by name or @username..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-input text-foreground text-xs rounded-xl border border-border focus:outline-none focus:border-accent"
            />
          </div>
        )}
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-5 pb-20 md:pb-6">
        {/* Contacts Tab */}
        {tab === 'contacts' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-w-6xl mx-auto">
            {filteredContacts.length === 0 ? (
              <div className="col-span-full py-12 text-center text-muted text-xs">
                No contacts found. Click "Add Contact" to connect with registered LIVO members.
              </div>
            ) : (
              filteredContacts.map(({ contact_profile }) => (
                <div
                  key={contact_profile.id}
                  className="bg-card p-4 rounded-2xl border border-border flex flex-col justify-between hover:border-accent/40 transition-all shadow-xs group"
                >
                  <div className="flex items-start gap-3">
                    <Avatar
                      src={contact_profile.avatar_url}
                      name={contact_profile.display_name}
                      size="lg"
                      status={contact_profile.online_status}
                      showStatus={true}
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="font-display font-semibold text-sm text-foreground truncate">
                        {contact_profile.display_name}
                      </h4>
                      <p className="text-xs font-mono text-accent truncate">
                        {contact_profile.username}
                      </p>
                      {contact_profile.bio && (
                        <p className="text-xs text-muted line-clamp-1 mt-1">
                          {contact_profile.bio}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Actions bar */}
                  <div className="flex items-center justify-between mt-4 pt-3 border-t border-border/40">
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => onStartChatWithUser(contact_profile)}
                        className="p-2 text-muted hover:text-accent hover:bg-input rounded-xl transition-colors"
                        title="Chat"
                      >
                        <MessageSquare size={16} />
                      </button>
                      <button
                        onClick={() => startCall(contact_profile, 'voice')}
                        className="p-2 text-muted hover:text-emerald-500 hover:bg-input rounded-xl transition-colors"
                        title="Voice Call"
                      >
                        <Phone size={16} />
                      </button>
                      <button
                        onClick={() => startCall(contact_profile, 'video')}
                        className="p-2 text-muted hover:text-blue-500 hover:bg-input rounded-xl transition-colors"
                        title="Video Call"
                      >
                        <Video size={16} />
                      </button>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => removeContact(contact_profile.id)}
                        className="p-2 text-muted hover:text-rose-500 hover:bg-rose-500/10 rounded-xl transition-colors"
                        title="Remove Contact"
                      >
                        <UserMinus size={15} />
                      </button>
                      <button
                        onClick={() => blockUser(contact_profile.id)}
                        className="p-2 text-muted hover:text-rose-500 hover:bg-rose-500/10 rounded-xl transition-colors"
                        title="Block User"
                      >
                        <Ban size={15} />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* Requests Tab */}
        {tab === 'requests' && (
          <div className="max-w-2xl mx-auto flex flex-col gap-3">
            {contactRequests.length === 0 ? (
              <div className="py-12 text-center text-muted text-xs">
                No pending contact requests.
              </div>
            ) : (
              contactRequests.map((req) => (
                <div
                  key={req.id}
                  className="bg-card p-4 rounded-2xl border border-border flex items-center justify-between gap-4"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <Avatar
                      src={req.sender_profile.avatar_url}
                      name={req.sender_profile.display_name}
                      size="md"
                    />
                    <div className="min-w-0">
                      <h4 className="font-semibold text-sm text-foreground truncate">
                        {req.sender_profile.display_name}
                      </h4>
                      <p className="text-xs font-mono text-accent">
                        {req.sender_profile.username}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => acceptContactRequest(req.id)}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-accent text-white text-xs font-semibold rounded-xl hover:opacity-90 shadow-sm"
                    >
                      <Check size={14} />
                      <span>Accept</span>
                    </button>
                    <button
                      onClick={() => rejectContactRequest(req.id)}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-input text-muted hover:text-foreground text-xs font-semibold rounded-xl hover:bg-border/60"
                    >
                      <X size={14} />
                      <span>Decline</span>
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* Blocked Users Tab */}
        {tab === 'blocked' && (
          <div className="max-w-2xl mx-auto flex flex-col gap-3">
            {blockedUsers.length === 0 ? (
              <div className="py-12 text-center text-muted text-xs">
                You haven't blocked any users.
              </div>
            ) : (
              blockedUsers.map((blk) => (
                <div
                  key={blk.id}
                  className="bg-card p-4 rounded-2xl border border-border flex items-center justify-between gap-4"
                >
                  <div className="flex items-center gap-3">
                    <Avatar
                      src={blk.blocked_profile.avatar_url}
                      name={blk.blocked_profile.display_name}
                      size="md"
                    />
                    <div>
                      <h4 className="font-semibold text-sm text-foreground">
                        {blk.blocked_profile.display_name}
                      </h4>
                      <p className="text-xs font-mono text-muted">
                        {blk.blocked_profile.username}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => unblockUser(blk.blocked_user_id)}
                    className="px-3.5 py-1.5 border border-border hover:bg-input text-xs font-semibold text-foreground rounded-xl transition-colors"
                  >
                    Unblock
                  </button>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
};
