import React, { useState, useRef } from 'react';
import { X, Upload, Send, FileText, Image as ImageIcon, Video as VideoIcon, Loader2 } from 'lucide-react';
import { uploadFile, StorageBucket } from '../../services/storageService';

interface MediaUploadModalProps {
  type: 'image' | 'video' | 'document';
  onClose: () => void;
  onSendMedia: (url: string, caption: string, meta: any) => void;
}

export const MediaUploadModal: React.FC<MediaUploadModalProps> = ({
  type,
  onClose,
  onSendMedia,
}) => {
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string>('');
  const [caption, setCaption] = useState<string>('');
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (selected) {
      setFile(selected);
      const url = URL.createObjectURL(selected);
      setPreviewUrl(url);
    }
  };

  const handleSend = async () => {
    if (!file) return;

    setIsUploading(true);
    setProgress(15);

    try {
      const bucket: StorageBucket =
        type === 'document' ? 'documents' : 'chat-media';

      const result = await uploadFile(file, bucket, type, (pct) => setProgress(pct));

      onSendMedia(result.url, caption.trim(), {
        name: result.name,
        size: result.size,
        mime: result.mime,
      });

      onClose();
    } catch (err) {
      console.error('Failed to upload file:', err);
      // Fallback: send preview data URL
      onSendMedia(previewUrl, caption.trim(), {
        name: file.name,
        size: file.size,
        mime: file.type,
      });
      onClose();
    } finally {
      setIsUploading(false);
    }
  };

  const typeDetails = {
    image: {
      title: 'Send Image',
      accept: 'image/*',
      icon: ImageIcon,
      placeholder: 'Add a photo caption...',
    },
    video: {
      title: 'Send Video',
      accept: 'video/*',
      icon: VideoIcon,
      placeholder: 'Add a video caption...',
    },
    document: {
      title: 'Send Document',
      accept: '.pdf,.doc,.docx,.txt,.zip',
      icon: FileText,
      placeholder: 'Add a message with this file...',
    },
  }[type];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-card w-full max-w-md rounded-3xl border border-border p-6 shadow-2xl flex flex-col gap-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 font-display font-semibold text-foreground">
            <typeDetails.icon size={18} className="text-accent" />
            <span>{typeDetails.title}</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-muted hover:text-foreground rounded-xl hover:bg-input transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Dropzone / Preview */}
        <input
          ref={fileInputRef}
          type="file"
          accept={typeDetails.accept}
          onChange={handleFileChange}
          className="hidden"
        />

        {previewUrl ? (
          <div className="relative rounded-2xl overflow-hidden bg-input/40 border border-border flex items-center justify-center max-h-64">
            {type === 'image' && (
              <img src={previewUrl} alt="Preview" className="max-h-64 w-full object-contain" />
            )}
            {type === 'video' && (
              <video src={previewUrl} controls className="max-h-64 w-full" />
            )}
            {type === 'document' && (
              <div className="p-8 flex flex-col items-center gap-2 text-center">
                <FileText size={40} className="text-accent" />
                <span className="font-semibold text-sm text-foreground">{file?.name}</span>
                <span className="text-xs text-muted">
                  {file?.size ? `${(file.size / 1024).toFixed(1)} KB` : ''}
                </span>
              </div>
            )}
            <button
              onClick={() => {
                setFile(null);
                setPreviewUrl('');
              }}
              className="absolute top-2 right-2 p-1.5 bg-black/60 hover:bg-black/80 text-white rounded-full transition-colors"
              title="Change File"
            >
              <X size={15} />
            </button>
          </div>
        ) : (
          <div
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-border/80 hover:border-accent rounded-2xl p-8 flex flex-col items-center justify-center gap-3 cursor-pointer hover:bg-input/50 transition-all text-center"
          >
            <div className="p-3.5 rounded-2xl bg-accent/15 text-accent">
              <Upload size={24} />
            </div>
            <div>
              <p className="text-sm font-semibold text-foreground">
                Click to browse or drop file
              </p>
              <p className="text-xs text-muted mt-0.5">Supports {typeDetails.accept}</p>
            </div>
          </div>
        )}

        {/* Caption */}
        <input
          type="text"
          placeholder={typeDetails.placeholder}
          value={caption}
          onChange={(e) => setCaption(e.target.value)}
          className="w-full px-4 py-2.5 bg-input text-foreground text-sm rounded-xl border border-border focus:outline-none focus:border-accent"
        />

        {/* Action buttons */}
        <div className="flex items-center justify-end gap-2 mt-1">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-muted hover:text-foreground hover:bg-input transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSend}
            disabled={!previewUrl || isUploading}
            className="flex items-center gap-2 px-5 py-2 bg-accent text-white rounded-xl text-xs font-semibold hover:opacity-95 shadow-md shadow-accent/25 transition-all disabled:opacity-50"
          >
            {isUploading ? <Loader2 size={14} className="animate-spin" /> : <Send size={14} />}
            <span>{isUploading ? `Uploading ${progress}%` : 'Send'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
