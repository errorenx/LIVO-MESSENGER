import React, { useState } from 'react';
import { Search, X, Calendar } from 'lucide-react';
import { Message } from '../../types';

interface MessageSearchModalProps {
  messages: Message[];
  onClose: () => void;
  onSelectMessage: (id: string) => void;
}

export const MessageSearchModal: React.FC<MessageSearchModalProps> = ({
  messages,
  onClose,
  onSelectMessage,
}) => {
  const [query, setQuery] = useState('');

  const filtered = query.trim()
    ? messages.filter((m) => m.content?.toLowerCase().includes(query.toLowerCase()))
    : [];

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleString(undefined, {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-card w-full max-w-lg rounded-3xl border border-border p-6 shadow-2xl flex flex-col gap-4 max-h-[80vh]">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 font-display font-semibold text-foreground">
            <Search size={18} className="text-accent" />
            <span>Search Messages</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-muted hover:text-foreground rounded-xl hover:bg-input transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Input */}
        <div className="relative">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" />
          <input
            type="text"
            placeholder="Type word or phrase..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2.5 bg-input text-foreground text-sm rounded-xl border border-border focus:outline-none focus:border-accent"
            autoFocus
          />
        </div>

        {/* Results */}
        <div className="flex-1 overflow-y-auto divide-y divide-border/40 min-h-[200px]">
          {query.trim() === '' ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-8 text-muted text-xs">
              Enter a search query to search through this conversation.
            </div>
          ) : filtered.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-8 text-muted text-xs">
              No matching messages found for "{query}".
            </div>
          ) : (
            filtered.map((msg) => (
              <div
                key={msg.id}
                onClick={() => {
                  onSelectMessage(msg.id);
                  onClose();
                }}
                className="p-3 hover:bg-input/60 rounded-xl cursor-pointer transition-colors"
              >
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="font-semibold text-accent">
                    {msg.sender_profile?.display_name || 'User'}
                  </span>
                  <span className="text-[10px] text-muted font-mono flex items-center gap-1">
                    <Calendar size={10} />
                    {formatDate(msg.created_at)}
                  </span>
                </div>
                <p className="text-xs text-foreground line-clamp-2">{msg.content}</p>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
