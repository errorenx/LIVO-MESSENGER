import React, { useState, useRef } from 'react';
import {
  Send,
  Paperclip,
  Smile,
  Mic,
  X,
  Image as ImageIcon,
  Video as VideoIcon,
  FileText,
} from 'lucide-react';
import { Message } from '../../types';
import { VoiceRecorder } from '../common/VoiceRecorder';

interface MessageComposerProps {
  replyingTo: Message | null;
  onCancelReply: () => void;
  onSendMessage: (content: string) => void;
  onSendVoice: (audioUrl: string, duration: number) => void;
  onOpenAttachmentModal: (type: 'image' | 'video' | 'document') => void;
  onTyping: () => void;
}

export const MessageComposer: React.FC<MessageComposerProps> = ({
  replyingTo,
  onCancelReply,
  onSendMessage,
  onSendVoice,
  onOpenAttachmentModal,
  onTyping,
}) => {
  const [content, setContent] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showAttachMenu, setShowAttachMenu] = useState(false);
  const inputRef = useRef<HTMLInputElement | null>(null);

  const handleSend = () => {
    if (content.trim()) {
      onSendMessage(content.trim());
      setContent('');
      if (inputRef.current) inputRef.current.focus();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setContent(e.target.value);
    onTyping();
  };

  const emojiList = ['😀', '😂', '😍', '🔥', '👍', '🎉', '✨', '🚀', '💯', '❤️', '🙌', '😎', '💡', '⚡', '🌙'];

  if (isRecording) {
    return (
      <div className="p-3 bg-card border-t border-border">
        <VoiceRecorder
          onSendVoice={(url, dur) => {
            onSendVoice(url, dur);
            setIsRecording(false);
          }}
          onCancel={() => setIsRecording(false)}
        />
      </div>
    );
  }

  return (
    <div className="bg-card border-t border-border select-none relative">
      {/* Quote Reply Banner */}
      {replyingTo && (
        <div className="px-4 py-2 bg-input/70 border-b border-border/50 flex items-center justify-between animate-in slide-in-from-bottom-2">
          <div className="flex flex-col text-xs min-w-0">
            <span className="font-semibold text-accent truncate">
              Replying to {replyingTo.sender_profile?.display_name || 'User'}
            </span>
            <span className="text-muted truncate mt-0.5">
              {replyingTo.content || '[Media attachment]'}
            </span>
          </div>
          <button
            onClick={onCancelReply}
            className="p-1 text-muted hover:text-foreground rounded-lg hover:bg-card transition-colors ml-2"
          >
            <X size={15} />
          </button>
        </div>
      )}

      {/* Emoji Picker Popup */}
      {showEmojiPicker && (
        <div className="absolute bottom-16 left-4 p-2.5 glass-dropdown rounded-2xl shadow-xl border border-border z-30 max-w-xs animate-in fade-in zoom-in-95">
          <div className="grid grid-cols-5 gap-1.5 text-xl">
            {emojiList.map((emoji) => (
              <button
                key={emoji}
                type="button"
                onClick={() => {
                  setContent((prev) => prev + emoji);
                  setShowEmojiPicker(false);
                  inputRef.current?.focus();
                }}
                className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-input transition-transform hover:scale-110"
              >
                {emoji}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Attachment Menu Popup */}
      {showAttachMenu && (
        <div className="absolute bottom-16 left-12 p-2 glass-dropdown rounded-2xl shadow-xl border border-border z-30 flex flex-col gap-1 w-44 animate-in fade-in zoom-in-95">
          <button
            type="button"
            onClick={() => {
              onOpenAttachmentModal('image');
              setShowAttachMenu(false);
            }}
            className="flex items-center gap-2.5 px-3 py-2 text-xs text-foreground hover:bg-input rounded-xl transition-colors"
          >
            <ImageIcon size={16} className="text-accent" />
            <span>Image</span>
          </button>
          <button
            type="button"
            onClick={() => {
              onOpenAttachmentModal('video');
              setShowAttachMenu(false);
            }}
            className="flex items-center gap-2.5 px-3 py-2 text-xs text-foreground hover:bg-input rounded-xl transition-colors"
          >
            <VideoIcon size={16} className="text-emerald-500" />
            <span>Video</span>
          </button>
          <button
            type="button"
            onClick={() => {
              onOpenAttachmentModal('document');
              setShowAttachMenu(false);
            }}
            className="flex items-center gap-2.5 px-3 py-2 text-xs text-foreground hover:bg-input rounded-xl transition-colors"
          >
            <FileText size={16} className="text-blue-500" />
            <span>Document</span>
          </button>
        </div>
      )}

      {/* Composer Input Bar */}
      <div className="flex items-center gap-2 p-3">
        {/* Emoji Button */}
        <button
          type="button"
          onClick={() => {
            setShowEmojiPicker((prev) => !prev);
            setShowAttachMenu(false);
          }}
          className="p-2 text-muted hover:text-foreground rounded-xl hover:bg-input transition-colors flex-shrink-0"
          title="Insert Emoji"
        >
          <Smile size={19} />
        </button>

        {/* Attachment Button */}
        <button
          type="button"
          onClick={() => {
            setShowAttachMenu((prev) => !prev);
            setShowEmojiPicker(false);
          }}
          className="p-2 text-muted hover:text-foreground rounded-xl hover:bg-input transition-colors flex-shrink-0"
          title="Attach media or document"
        >
          <Paperclip size={19} />
        </button>

        {/* Text Input */}
        <div className="flex-1 relative">
          <input
            ref={inputRef}
            type="text"
            placeholder="Type a message..."
            value={content}
            onChange={handleInputChange}
            onKeyDown={handleKeyDown}
            className="w-full px-4 py-2.5 bg-input text-foreground text-sm rounded-2xl border border-border/80 focus:outline-none focus:border-accent transition-all placeholder:text-muted"
          />
        </div>

        {/* Send OR Microphone */}
        {content.trim() ? (
          <button
            type="button"
            onClick={handleSend}
            className="p-2.5 bg-accent text-white rounded-2xl hover:opacity-95 shadow-md shadow-accent/25 transition-transform active:scale-95 flex-shrink-0"
            title="Send Message"
          >
            <Send size={18} />
          </button>
        ) : (
          <button
            type="button"
            onClick={() => setIsRecording(true)}
            className="p-2.5 text-muted hover:text-accent hover:bg-input rounded-2xl transition-colors flex-shrink-0"
            title="Record Voice Message"
          >
            <Mic size={20} />
          </button>
        )}
      </div>
    </div>
  );
};
