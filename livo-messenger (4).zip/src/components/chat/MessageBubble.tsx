import React, { useState } from 'react';
import {
  Check,
  CheckCheck,
  Clock,
  Reply,
  Smile,
  Copy,
  Edit2,
  Trash2,
  Pin,
  Star,
  FileText,
  Download,
  MoreHorizontal,
} from 'lucide-react';
import { Message, MessageDeliveryStatus } from '../../types';
import { useAuth } from '../../contexts/AuthContext';
import { AudioPlayer } from '../common/AudioPlayer';

interface MessageBubbleProps {
  message: Message;
  isSender: boolean;
  onReply: (message: Message) => void;
  onReact: (messageId: string, emoji: string) => void;
  onEdit: (messageId: string, newContent: string) => void;
  onDelete: (messageId: string) => void;
  onPin: (messageId: string) => void;
  onStar: (messageId: string) => void;
  onImageClick?: (url: string) => void;
}

export const MessageBubble: React.FC<MessageBubbleProps> = ({
  message,
  isSender,
  onReply,
  onReact,
  onEdit,
  onDelete,
  onPin,
  onStar,
  onImageClick,
}) => {
  const { user } = useAuth();
  const [showActions, setShowActions] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editContent, setEditContent] = useState(message.content);

  const quickEmojis = ['❤️', '👍', '😂', '😮', '😢', '🔥'];

  const formatTime = (dateStr: string) => {
    const d = new Date(dateStr);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const renderStatus = (status: MessageDeliveryStatus) => {
    if (!isSender) return null;
    if (status === 'sending') return <Clock size={12} className="opacity-70" />;
    if (status === 'sent') return <Check size={13} className="opacity-80" />;
    if (status === 'delivered') return <CheckCheck size={13} className="opacity-80" />;
    if (status === 'seen') return <CheckCheck size={13} className="text-white" />;
    return null;
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    setShowActions(false);
  };

  const handleSaveEdit = () => {
    if (editContent.trim()) {
      onEdit(message.id, editContent.trim());
      setIsEditing(false);
    }
  };

  const reactions = message.reactions || {};
  const hasReactions = Object.keys(reactions).length > 0;

  return (
    <div
      onMouseEnter={() => setShowActions(true)}
      onMouseLeave={() => {
        setShowActions(false);
        setShowEmojiPicker(false);
      }}
      className={`relative group flex flex-col mb-3.5 px-4 ${
        isSender ? 'items-end' : 'items-start'
      }`}
    >
      {/* Sender label in group */}
      {!isSender && message.sender_profile && (
        <span className="text-[11px] font-semibold text-accent mb-1 px-1 select-none">
          {message.sender_profile.display_name}
        </span>
      )}

      <div className={`relative flex items-end gap-1.5 max-w-[85%] sm:max-w-[70%]`}>
        {/* Hover Action Menu (Desktop / Mobile click) */}
        {showActions && (
          <div
            className={`absolute -top-9 ${
              isSender ? 'right-0' : 'left-0'
            } flex items-center gap-0.5 p-1 glass-dropdown rounded-xl shadow-lg border border-border/80 z-20 select-none animate-in fade-in zoom-in-95`}
          >
            {/* Quick React trigger */}
            <button
              onClick={() => setShowEmojiPicker((prev) => !prev)}
              className="p-1.5 text-muted hover:text-foreground hover:bg-input rounded-lg transition-colors"
              title="Add Reaction"
            >
              <Smile size={14} />
            </button>

            {/* Reply */}
            <button
              onClick={() => onReply(message)}
              className="p-1.5 text-muted hover:text-foreground hover:bg-input rounded-lg transition-colors"
              title="Reply"
            >
              <Reply size={14} />
            </button>

            {/* Copy */}
            <button
              onClick={handleCopy}
              className="p-1.5 text-muted hover:text-foreground hover:bg-input rounded-lg transition-colors"
              title="Copy text"
            >
              <Copy size={14} />
            </button>

            {/* Star */}
            <button
              onClick={() => onStar(message.id)}
              className={`p-1.5 hover:bg-input rounded-lg transition-colors ${
                message.is_starred ? 'text-amber-400' : 'text-muted hover:text-foreground'
              }`}
              title="Star message"
            >
              <Star size={14} className={message.is_starred ? 'fill-current' : ''} />
            </button>

            {/* Pin */}
            <button
              onClick={() => onPin(message.id)}
              className={`p-1.5 hover:bg-input rounded-lg transition-colors ${
                message.is_pinned ? 'text-accent' : 'text-muted hover:text-foreground'
              }`}
              title="Pin message"
            >
              <Pin size={14} className={message.is_pinned ? 'fill-current' : ''} />
            </button>

            {/* Edit (own only) */}
            {isSender && message.message_type === 'text' && (
              <button
                onClick={() => setIsEditing(true)}
                className="p-1.5 text-muted hover:text-foreground hover:bg-input rounded-lg transition-colors"
                title="Edit message"
              >
                <Edit2 size={14} />
              </button>
            )}

            {/* Delete (own only) */}
            {isSender && (
              <button
                onClick={() => onDelete(message.id)}
                className="p-1.5 text-rose-400 hover:text-rose-500 hover:bg-rose-500/10 rounded-lg transition-colors"
                title="Delete message"
              >
                <Trash2 size={14} />
              </button>
            )}
          </div>
        )}

        {/* Floating Quick Emoji Picker */}
        {showEmojiPicker && (
          <div
            className={`absolute -top-16 ${
              isSender ? 'right-0' : 'left-0'
            } flex items-center gap-1.5 p-1.5 glass-dropdown rounded-2xl shadow-xl border border-border z-30 animate-in fade-in zoom-in-95`}
          >
            {quickEmojis.map((emoji) => (
              <button
                key={emoji}
                onClick={() => {
                  onReact(message.id, emoji);
                  setShowEmojiPicker(false);
                }}
                className="w-8 h-8 flex items-center justify-center text-base hover:scale-125 transition-transform"
              >
                {emoji}
              </button>
            ))}
          </div>
        )}

        {/* Message Bubble Container */}
        <div
          className={`rounded-2xl px-3.5 py-2.5 shadow-sm text-sm relative transition-all ${
            isSender
              ? 'bg-accent text-white rounded-br-xs'
              : 'bg-bubble-received text-foreground rounded-bl-xs border border-border/40'
          }`}
        >
          {/* Quote Reply Header */}
          {message.reply_message && (
            <div
              className={`mb-2 p-2 rounded-xl text-xs border-l-3 ${
                isSender
                  ? 'bg-white/15 border-white/80 text-white'
                  : 'bg-card border-accent text-foreground/80'
              }`}
            >
              <div className="font-semibold text-[11px] opacity-90">
                {message.reply_message.sender_name}
              </div>
              <div className="truncate opacity-80 mt-0.5">
                {message.reply_message.content}
              </div>
            </div>
          )}

          {/* Media Renders */}
          {message.message_type === 'image' && message.media_url && (
            <div className="mb-2 rounded-xl overflow-hidden cursor-pointer">
              <img
                src={message.media_url}
                alt="Chat attachment"
                onClick={() => onImageClick && onImageClick(message.media_url!)}
                className="max-h-72 w-full object-cover rounded-xl hover:opacity-95 transition-opacity"
              />
            </div>
          )}

          {message.message_type === 'video' && message.media_url && (
            <div className="mb-2 rounded-xl overflow-hidden">
              <video
                src={message.media_url}
                controls
                className="max-h-72 w-full rounded-xl"
              />
            </div>
          )}

          {message.message_type === 'voice' && message.media_url && (
            <AudioPlayer
              src={message.media_url}
              duration={message.media_meta?.duration || 15}
              isSender={isSender}
            />
          )}

          {message.message_type === 'document' && (
            <div
              className={`flex items-center gap-3 p-2.5 rounded-xl mb-1.5 ${
                isSender ? 'bg-white/15' : 'bg-card border border-border/60'
              }`}
            >
              <div className="p-2 rounded-lg bg-accent/20 text-accent">
                <FileText size={20} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-medium text-xs truncate">
                  {message.media_meta?.name || 'Document.pdf'}
                </div>
                <div className="text-[10px] opacity-70">
                  {message.media_meta?.size
                    ? `${(message.media_meta.size / 1024).toFixed(1)} KB`
                    : 'Download File'}
                </div>
              </div>
              {message.media_url && (
                <a
                  href={message.media_url}
                  download
                  className="p-1.5 rounded-lg hover:bg-input transition-colors"
                >
                  <Download size={15} />
                </a>
              )}
            </div>
          )}

          {/* Text Content / Inline Editing */}
          {isEditing ? (
            <div className="flex flex-col gap-2 min-w-[200px]">
              <input
                type="text"
                value={editContent}
                onChange={(e) => setEditContent(e.target.value)}
                className="w-full px-2.5 py-1.5 text-xs text-foreground bg-card rounded-lg border border-border focus:outline-none"
                autoFocus
              />
              <div className="flex items-center justify-end gap-1.5 text-[11px]">
                <button
                  onClick={() => setIsEditing(false)}
                  className="px-2 py-0.5 rounded text-white/80 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveEdit}
                  className="px-2.5 py-0.5 rounded bg-white text-slate-900 font-semibold"
                >
                  Save
                </button>
              </div>
            </div>
          ) : (
            message.content && (
              <p className="whitespace-pre-wrap break-words leading-relaxed">
                {message.content}
              </p>
            )
          )}

          {/* Timestamp & Status Metadata */}
          <div
            className={`flex items-center justify-end gap-1 text-[10px] mt-1 select-none font-mono ${
              isSender ? 'text-white/80' : 'text-muted'
            }`}
          >
            {message.is_pinned && <Pin size={10} className="rotate-45" />}
            {message.is_starred && <Star size={10} className="fill-current text-amber-300" />}
            {message.edited_at && <span className="italic mr-0.5">edited</span>}
            <span>{formatTime(message.created_at)}</span>
            {renderStatus(message.status)}
          </div>
        </div>
      </div>

      {/* Reaction Badges */}
      {hasReactions && (
        <div
          className={`flex items-center gap-1 mt-1 -mb-1 px-1 z-10 ${
            isSender ? 'justify-end' : 'justify-start'
          }`}
        >
          {Object.entries(reactions).map(([emoji, userIds]) => {
            const count = Array.isArray(userIds) ? userIds.length : 1;
            return (
              <button
                key={emoji}
                onClick={() => onReact(message.id, emoji)}
                className="inline-flex items-center gap-1 px-2 py-0.5 bg-card/95 border border-border rounded-full text-xs shadow-xs hover:scale-105 transition-transform"
              >
                <span>{emoji}</span>
                <span className="text-[10px] font-semibold text-muted">{count}</span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
};
