import React, { useRef, useEffect } from 'react';
import { Pin, X } from 'lucide-react';
import { Message } from '../../types';
import { useAuth } from '../../contexts/AuthContext';
import { useChat } from '../../contexts/ChatContext';
import { MessageBubble } from './MessageBubble';

interface MessageListProps {
  messages: Message[];
  onReply: (msg: Message) => void;
  onImageClick?: (url: string) => void;
}

export const MessageList: React.FC<MessageListProps> = ({
  messages,
  onReply,
  onImageClick,
}) => {
  const { user } = useAuth();
  const { reactToMessage, editMessage, deleteMessage, togglePinMessage, toggleStarMessage } =
    useChat();
  const scrollBottomRef = useRef<HTMLDivElement | null>(null);

  // Auto scroll on new messages
  useEffect(() => {
    scrollBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length]);

  const pinnedMessage = messages.find((m) => m.is_pinned);

  // Group messages by date
  const formatDateHeader = (dateStr: string) => {
    const d = new Date(dateStr);
    const today = new Date();
    const yesterday = new Date();
    yesterday.setDate(today.getDate() - 1);

    if (d.toDateString() === today.toDateString()) return 'Today';
    if (d.toDateString() === yesterday.toDateString()) return 'Yesterday';
    return d.toLocaleDateString(undefined, {
      month: 'short',
      day: 'numeric',
      year: d.getFullYear() !== today.getFullYear() ? 'numeric' : undefined,
    });
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden relative">
      {/* Sticky Pinned Message Banner */}
      {pinnedMessage && (
        <div className="sticky top-0 z-20 px-4 py-2 bg-card/90 backdrop-blur-md border-b border-border/80 flex items-center justify-between text-xs animate-in slide-in-from-top-2">
          <div className="flex items-center gap-2 min-w-0">
            <Pin size={13} className="text-accent fill-accent flex-shrink-0" />
            <span className="font-semibold text-accent flex-shrink-0">Pinned Message:</span>
            <span className="text-foreground truncate">{pinnedMessage.content}</span>
          </div>
          <button
            onClick={() => togglePinMessage(pinnedMessage.id)}
            className="p-1 text-muted hover:text-foreground rounded-lg hover:bg-input transition-colors ml-2"
            title="Unpin"
          >
            <X size={14} />
          </button>
        </div>
      )}

      {/* Messages Scroll View */}
      <div className="flex-1 overflow-y-auto py-4">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-6 text-muted text-xs">
            <p className="font-display font-medium text-sm text-foreground mb-1">
              No messages yet
            </p>
            <p>Send a message or voice note to begin the conversation.</p>
          </div>
        ) : (
          messages.map((msg, index) => {
            const isSender = msg.sender_id === user?.id;

            // Date divider check
            const currentDate = formatDateHeader(msg.created_at);
            const prevDate = index > 0 ? formatDateHeader(messages[index - 1].created_at) : null;
            const showDateHeader = currentDate !== prevDate;

            return (
              <React.Fragment key={msg.id}>
                {showDateHeader && (
                  <div className="flex items-center justify-center my-4 select-none">
                    <span className="px-3 py-1 bg-input/80 text-muted rounded-full text-[11px] font-medium border border-border/50 shadow-xs">
                      {currentDate}
                    </span>
                  </div>
                )}

                <MessageBubble
                  message={msg}
                  isSender={isSender}
                  onReply={onReply}
                  onReact={reactToMessage}
                  onEdit={editMessage}
                  onDelete={deleteMessage}
                  onPin={togglePinMessage}
                  onStar={toggleStarMessage}
                  onImageClick={onImageClick}
                />
              </React.Fragment>
            );
          })
        )}
        <div ref={scrollBottomRef} />
      </div>
    </div>
  );
};
