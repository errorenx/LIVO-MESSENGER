import React, { useState } from 'react';
import { Search, Plus, Users, Pin, Check, CheckCheck, Clock, Bookmark } from 'lucide-react';
import { useChat } from '../../contexts/ChatContext';
import { Avatar } from '../common/Avatar';
import { Conversation, MessageDeliveryStatus } from '../../types';

interface ChatListProps {
  onOpenNewChat: () => void;
  onOpenNewGroup?: () => void;
}

export const ChatList: React.FC<ChatListProps> = ({ onOpenNewChat }) => {
  const { conversations, activeConversationId, setActiveConversationId } = useChat();
  const [filter, setFilter] = useState<'all' | 'direct' | 'group' | 'unread'>('all');
  const [query, setQuery] = useState('');

  const filtered = conversations.filter((c) => {
    // Search query filter
    const matchesQuery =
      c.name?.toLowerCase().includes(query.toLowerCase()) ||
      c.last_message?.content.toLowerCase().includes(query.toLowerCase());

    if (!matchesQuery) return false;

    if (filter === 'direct') return c.type === 'direct';
    if (filter === 'group') return c.type === 'group';
    if (filter === 'unread') return (c.unread_count || 0) > 0;
    return true;
  });

  // Sort self chat first, then pinned, then by updated_at
  const sorted = [...filtered].sort((a, b) => {
    const isASelf = a.id.startsWith('self_') || a.name?.includes('(YOU)');
    const isBSelf = b.id.startsWith('self_') || b.name?.includes('(YOU)');
    if (isASelf && !isBSelf) return -1;
    if (!isASelf && isBSelf) return 1;
    if (a.is_pinned && !b.is_pinned) return -1;
    if (!a.is_pinned && b.is_pinned) return 1;
    return new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime();
  });

  const formatTimestamp = (dateStr?: string) => {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    const now = new Date();
    const isToday = date.toDateString() === now.toDateString();

    if (isToday) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
    return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
  };

  const renderStatusIcon = (status?: MessageDeliveryStatus) => {
    if (!status) return null;
    if (status === 'sending') return <Clock size={12} className="text-muted" />;
    if (status === 'sent') return <Check size={13} className="text-muted" />;
    if (status === 'delivered') return <CheckCheck size={13} className="text-muted" />;
    if (status === 'seen') return <CheckCheck size={13} className="text-accent" />;
    return null;
  };

  return (
    <div className="flex flex-col h-full bg-sidebar/50 border-r border-border select-none">
      {/* Header & Search */}
      <div className="p-4 border-b border-border/70 flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <h2 className="font-display font-bold text-xl text-foreground tracking-tight">
            Messages
          </h2>
        </div>

        {/* Search Input */}
        <div className="relative">
          <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" />
          <input
            type="text"
            placeholder="Search chats or messages..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-input text-foreground text-xs rounded-xl border border-border/80 focus:outline-none focus:border-accent transition-all placeholder:text-muted"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs font-medium">
          {(['all', 'direct', 'unread'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1 rounded-lg capitalize whitespace-nowrap transition-all ${
                filter === f
                  ? 'bg-foreground text-background font-semibold shadow-sm'
                  : 'text-muted hover:text-foreground hover:bg-input'
              }`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* Conversation Cards List */}
      <div className="flex-1 overflow-y-auto divide-y divide-border/30 pb-20 md:pb-4">
        {sorted.length === 0 ? (
          <div className="p-8 text-center text-muted text-xs">
            No conversations found. Start a new chat!
          </div>
        ) : (
          sorted.map((conv) => {
            const isActive = conv.id === activeConversationId;
            const isGroup = conv.type === 'group';
            const isSelf = conv.id.startsWith('self_') || conv.name?.includes('(YOU)');
            const displayName = isSelf
              ? conv.name.replace(/\s*\(YOU\)/i, '').trim()
              : conv.name;

            return (
              <div
                key={conv.id}
                onClick={() => setActiveConversationId(conv.id)}
                className={`flex items-center gap-3 p-3.5 cursor-pointer transition-all ${
                  isActive
                    ? 'bg-card border-l-3 border-accent shadow-sm'
                    : 'hover:bg-card/60'
                }`}
              >
                {/* Avatar */}
                <div className="relative">
                  <Avatar
                    src={conv.avatar_url}
                    name={conv.name || 'Chat'}
                    size="md"
                    status={!isGroup ? 'online' : undefined}
                    showStatus={!isGroup && !isSelf}
                  />
                  {isSelf && (
                    <div className="absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full bg-accent text-white flex items-center justify-center shadow-xs">
                      <Bookmark size={10} className="fill-white" />
                    </div>
                  )}
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1 mb-1">
                    <div className="flex items-center gap-1.5 min-w-0 truncate">
                      <span className="font-display font-semibold text-sm text-foreground truncate">
                        {displayName}
                      </span>
                      {isSelf && (
                        <span className="inline-flex items-center px-1.5 py-0.5 text-[10px] font-black tracking-wide bg-accent text-white rounded-md shadow-xs flex-shrink-0">
                          (YOU)
                        </span>
                      )}
                    </div>
                    <span className="text-[11px] text-muted whitespace-nowrap font-mono flex-shrink-0">
                      {formatTimestamp(conv.last_message?.created_at || conv.updated_at)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1 text-xs text-muted truncate">
                      {conv.last_message && renderStatusIcon(conv.last_message.status)}
                      <span className="truncate">
                        {conv.last_message
                          ? conv.last_message.message_type === 'image'
                            ? '📷 Image'
                            : conv.last_message.message_type === 'voice'
                            ? '🎤 Voice message'
                            : conv.last_message.message_type === 'video'
                            ? '🎥 Video'
                            : conv.last_message.message_type === 'document'
                            ? '📄 Document'
                            : conv.last_message.content
                          : isSelf
                          ? 'Save notes, links & voice memos to yourself'
                          : 'No messages yet'}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      {conv.is_pinned && (
                        <Pin size={12} className="text-muted fill-muted rotate-45" />
                      )}
                      {(conv.unread_count || 0) > 0 && (
                        <span className="px-1.5 py-0.5 min-w-4 text-[10px] font-bold text-white bg-accent rounded-full flex items-center justify-center shadow-sm">
                          {conv.unread_count}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
