import React, { useState } from 'react';
import {
  Phone,
  Video,
  Search,
  MoreVertical,
  ArrowLeft,
  Users,
  Shield,
  Trash2,
  BellOff,
  UserX,
} from 'lucide-react';
import { Conversation, UserProfile } from '../../types';
import { Avatar } from '../common/Avatar';
import { useAuth } from '../../contexts/AuthContext';
import { useCall } from '../../contexts/CallContext';
import { useChat } from '../../contexts/ChatContext';

interface ChatHeaderProps {
  conversation: Conversation;
  onBackMobile?: () => void;
  onOpenSearch: () => void;
  onOpenInfo: () => void;
}

export const ChatHeader: React.FC<ChatHeaderProps> = ({
  conversation,
  onBackMobile,
  onOpenSearch,
  onOpenInfo,
}) => {
  const { user } = useAuth();
  const { startCall } = useCall();
  const { isPeerTyping, blockUser, contacts } = useChat();
  const [showMenu, setShowMenu] = useState(false);

  const isGroup = conversation.type === 'group';
  const isSelf = conversation.id.startsWith('self_') || conversation.name?.includes('(YOU)');
  const displayName = isSelf
    ? conversation.name.replace(/\s*\(YOU\)/i, '').trim()
    : conversation.name;

  // Get peer profile if direct (exclude self)
  const peerMember = conversation.members.find((m) => m.user_id !== user?.id);
  const peer = !isGroup && !isSelf
    ? peerMember?.profile || {
        id: peerMember?.user_id || 'peer',
        username: conversation.name ? `@${conversation.name.toLowerCase().replace(/\s+/g, '_')}` : '@peer',
        display_name: conversation.name || 'User',
        avatar_url: conversation.avatar_url || '',
        last_seen: new Date().toISOString(),
        online_status: 'online' as const,
        created_at: new Date().toISOString(),
      }
    : null;

  const handleVoiceCall = () => {
    if (peer) {
      startCall(peer, 'voice');
    }
  };

  const handleVideoCall = () => {
    if (peer) {
      startCall(peer, 'video');
    }
  };

  const handleBlock = () => {
    if (peer) {
      blockUser(peer);
      setShowMenu(false);
    }
  };

  return (
    <div className="h-16 px-4 bg-card/80 backdrop-blur-md border-b border-border flex items-center justify-between select-none z-10">
      {/* Left: Back & User Info */}
      <div className="flex items-center gap-3 min-w-0">
        {onBackMobile && (
          <button
            onClick={onBackMobile}
            className="md:hidden p-1.5 -ml-1 text-muted hover:text-foreground rounded-lg hover:bg-input transition-colors"
            title="Back to chats"
          >
            <ArrowLeft size={20} />
          </button>
        )}

        <div onClick={onOpenInfo} className="cursor-pointer flex items-center gap-3 min-w-0">
          <Avatar
            src={conversation.avatar_url}
            name={conversation.name || 'Chat'}
            size="md"
            status={!isGroup && !isSelf ? 'online' : undefined}
            showStatus={!isGroup && !isSelf}
          />

          <div className="flex flex-col min-w-0">
            <div className="flex items-center gap-1.5 truncate">
              <h3 className="font-display font-semibold text-sm text-foreground truncate hover:underline">
                {displayName}
              </h3>
              {isSelf && (
                <span className="inline-flex items-center px-1.5 py-0.5 text-[10px] font-black tracking-wide bg-accent text-white rounded-md shadow-xs flex-shrink-0">
                  (YOU)
                </span>
              )}
            </div>
            <span className="text-[11px] text-muted truncate">
              {isSelf ? (
                <span className="text-accent font-medium">Saved Messages • Personal Cloud</span>
              ) : isPeerTyping ? (
                <span className="text-accent font-medium flex items-center gap-1 animate-pulse">
                  <span>typing</span>
                  <span className="animate-bounce">...</span>
                </span>
              ) : isGroup ? (
                `${conversation.members.length} members`
              ) : (
                <span className="text-emerald-500 font-medium">Online</span>
              )}
            </span>
          </div>
        </div>
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-1 relative">
        {/* Voice Call */}
        {!isGroup && !isSelf && (
          <button
            onClick={handleVoiceCall}
            className="p-2 text-muted hover:text-foreground rounded-xl hover:bg-input transition-colors"
            title="Start Voice Call"
          >
            <Phone size={18} />
          </button>
        )}

        {/* Video Call */}
        {!isGroup && !isSelf && (
          <button
            onClick={handleVideoCall}
            className="p-2 text-muted hover:text-foreground rounded-xl hover:bg-input transition-colors"
            title="Start Video Call"
          >
            <Video size={18} />
          </button>
        )}

        {/* Search messages */}
        <button
          onClick={onOpenSearch}
          className="p-2 text-muted hover:text-foreground rounded-xl hover:bg-input transition-colors"
          title="Search in conversation"
        >
          <Search size={18} />
        </button>

        {/* More Menu */}
        <div className="relative">
          <button
            onClick={() => setShowMenu((prev) => !prev)}
            className="p-2 text-muted hover:text-foreground rounded-xl hover:bg-input transition-colors"
            title="Conversation Options"
          >
            <MoreVertical size={18} />
          </button>

          {showMenu && (
            <div
              className="absolute right-0 top-12 w-48 py-1.5 glass-dropdown rounded-2xl z-50 animate-in fade-in zoom-in-95"
              onMouseLeave={() => setShowMenu(false)}
            >
              <button
                onClick={() => {
                  onOpenInfo();
                  setShowMenu(false);
                }}
                className="w-full px-3.5 py-2 text-xs text-left text-foreground hover:bg-input flex items-center gap-2.5 transition-colors"
              >
                <Users size={14} className="text-muted" />
                <span>{isGroup ? 'Group Information' : 'Contact Info'}</span>
              </button>

              <button
                onClick={() => {
                  onOpenSearch();
                  setShowMenu(false);
                }}
                className="w-full px-3.5 py-2 text-xs text-left text-foreground hover:bg-input flex items-center gap-2.5 transition-colors"
              >
                <Search size={14} className="text-muted" />
                <span>Search Messages</span>
              </button>

              <button
                onClick={() => setShowMenu(false)}
                className="w-full px-3.5 py-2 text-xs text-left text-foreground hover:bg-input flex items-center gap-2.5 transition-colors"
              >
                <BellOff size={14} className="text-muted" />
                <span>Mute Notifications</span>
              </button>

              <div className="h-px bg-border my-1" />

              {!isGroup && peer && (
                <button
                  onClick={handleBlock}
                  className="w-full px-3.5 py-2 text-xs text-left text-rose-500 hover:bg-rose-500/10 flex items-center gap-2.5 transition-colors"
                >
                  <UserX size={14} />
                  <span>Block User</span>
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
