import React, { useState } from 'react';
import { Conversation, Message } from '../../types';
import { useChat } from '../../contexts/ChatContext';
import { ChatHeader } from './ChatHeader';
import { MessageList } from './MessageList';
import { MessageComposer } from './MessageComposer';
import { MediaUploadModal } from './MediaUploadModal';
import { MessageSearchModal } from './MessageSearchModal';
import { GroupInfoModal } from '../groups/GroupInfoModal';
import { ImageViewer } from '../common/ImageViewer';

interface ChatWindowProps {
  conversation: Conversation;
  onBackMobile?: () => void;
}

export const ChatWindow: React.FC<ChatWindowProps> = ({
  conversation,
  onBackMobile,
}) => {
  const {
    messagesMap,
    messages,
    activeMessages,
    activeConversationId,
    sendMessage,
    replyingTo: contextReplyingTo,
    setReplyingTo: setContextReplyingTo,
    sendTypingIndicator,
  } = useChat();

  const [localReplyingTo, setLocalReplyingTo] = useState<Message | null>(null);
  const replyingTo = contextReplyingTo !== undefined ? contextReplyingTo : localReplyingTo;
  const setReplyingTo = (msg: Message | null) => {
    setLocalReplyingTo(msg);
    if (setContextReplyingTo) setContextReplyingTo(msg);
  };

  const [activeMediaModal, setActiveMediaModal] = useState<
    'image' | 'video' | 'document' | null
  >(null);
  const [showSearchModal, setShowSearchModal] = useState(false);
  const [showInfoModal, setShowInfoModal] = useState(false);
  const [fullImageUrl, setFullImageUrl] = useState<string | null>(null);

  // Filter messages for current conversation safely
  const currentMessages =
    (messagesMap && messagesMap[conversation.id]) ||
    (messages && messages[conversation.id]) ||
    (activeConversationId === conversation.id ? activeMessages : []) ||
    [];

  const handleSendMessage = (text: string) => {
    sendMessage(text, 'text');
    setReplyingTo(null);
  };

  const handleSendVoice = (audioUrl: string, duration: number) => {
    sendMessage('', 'audio', audioUrl, { duration });
  };

  const handleSendMedia = (url: string, caption: string, meta: any) => {
    if (activeMediaModal) {
      sendMessage(caption, activeMediaModal, url, meta);
      setActiveMediaModal(null);
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-background relative overflow-hidden">
      {/* Top Header */}
      <ChatHeader
        conversation={conversation}
        onBackMobile={onBackMobile}
        onOpenSearch={() => setShowSearchModal(true)}
        onOpenInfo={() => setShowInfoModal(true)}
      />

      {/* Messages Feed */}
      <MessageList
        messages={currentMessages}
        onReply={(msg) => setReplyingTo(msg)}
        onImageClick={(url) => setFullImageUrl(url)}
      />

      {/* Message Composer Footer */}
      <MessageComposer
        replyingTo={replyingTo}
        onCancelReply={() => setReplyingTo(null)}
        onSendMessage={handleSendMessage}
        onSendVoice={handleSendVoice}
        onOpenAttachmentModal={(type) => setActiveMediaModal(type)}
        onTyping={() => sendTypingIndicator(true)}
      />

      {/* Media Upload Modal */}
      {activeMediaModal && (
        <MediaUploadModal
          type={activeMediaModal}
          onClose={() => setActiveMediaModal(null)}
          onSendMedia={handleSendMedia}
        />
      )}

      {/* Search in Conversation Modal */}
      {showSearchModal && (
        <MessageSearchModal
          messages={currentMessages}
          onClose={() => setShowSearchModal(false)}
          onSelectMessage={(msgId) => {
            // Scroll to message or highlight
          }}
        />
      )}

      {/* Group or Contact Info Modal */}
      {showInfoModal && (
        <GroupInfoModal
          conversation={conversation}
          onClose={() => setShowInfoModal(false)}
        />
      )}

      {/* Fullscreen Image Preview */}
      {fullImageUrl && (
        <ImageViewer src={fullImageUrl} onClose={() => setFullImageUrl(null)} />
      )}
    </div>
  );
};
