import React, { useState } from 'react';
import {
  CircleDot,
  Plus,
  Clock,
  Users,
  Radio,
  Search,
  MessageSquare,
  Info,
  ChevronRight,
  Shield,
  Sparkles,
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useChat } from '../../contexts/ChatContext';
import { Avatar } from '../common/Avatar';
import { StatusStory, Conversation } from '../../types';

interface StatusViewProps {
  onOpenCreateStatus: () => void;
  onOpenStoryViewer: (status: StatusStory) => void;
  onOpenCreateGroup?: () => void;
  onOpenCreateChannel?: () => void;
  onOpenGroupInfo?: (conversation: Conversation) => void;
  onNavigateToChat?: (conversationId: string) => void;
}

export const StatusView: React.FC<StatusViewProps> = ({
  onOpenCreateStatus,
  onOpenStoryViewer,
  onOpenCreateGroup,
  onOpenCreateChannel,
  onOpenGroupInfo,
  onNavigateToChat,
}) => {
  const { user } = useAuth();
  const { statuses, conversations, setActiveConversationId } = useChat();

  const [activeSection, setActiveSection] = useState<'status' | 'groups' | 'channels'>('status');
  const [searchQuery, setSearchQuery] = useState('');

  // Statuses data
  const myStatuses = statuses.filter((s) => s.user_id === user?.id);
  const otherStatuses = statuses.filter((s) => s.user_id !== user?.id);
  const recentStatuses = otherStatuses.filter((s) => !s.has_viewed);
  const viewedStatuses = otherStatuses.filter((s) => s.has_viewed);

  // Groups data (all groups that are not marked as channels)
  const allGroups = conversations.filter(
    (c) => c.type === 'group' && !c.description?.startsWith('[Channel]')
  );
  const filteredGroups = allGroups.filter((g) =>
    (g.name || '').toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Channels data (conversations with type 'channel' or description starting with [Channel])
  const allChannels = conversations.filter(
    (c) => c.type === 'channel' || (c.description?.startsWith('[Channel]') ?? false)
  );
  const filteredChannels = allChannels.filter((ch) =>
    (ch.name || '').toLowerCase().includes(searchQuery.toLowerCase())
  );

  const formatTimeAgo = (dateStr: string) => {
    const diffMs = Date.now() - new Date(dateStr).getTime();
    const diffHours = Math.floor(diffMs / 3600000);
    if (diffHours < 1) return 'Just now';
    return `${diffHours}h ago`;
  };

  const formatLastMessageTime = (dateStr?: string) => {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const handleOpenConversation = (conversationId: string) => {
    setActiveConversationId(conversationId);
    if (onNavigateToChat) {
      onNavigateToChat(conversationId);
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-sidebar/40 overflow-hidden select-none">
      {/* Top Main Header */}
      <div className="p-5 border-b border-border bg-card/60 backdrop-blur-md flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-display font-bold text-2xl text-foreground tracking-tight">
                {activeSection === 'status'
                  ? 'Status Updates'
                  : activeSection === 'groups'
                  ? 'Community Groups'
                  : 'Broadcast Channels'}
              </h2>
            </div>
            <p className="text-xs text-muted mt-0.5">
              {activeSection === 'status'
                ? 'Share moments and ephemeral 24h updates with your contacts'
                : activeSection === 'groups'
                ? 'Collaborate and chat in multi-user group spaces'
                : 'Subscribe to announcements and broadcast channels'}
            </p>
          </div>

          {/* Action button based on active section */}
          {activeSection === 'status' && (
            <button
              onClick={onOpenCreateStatus}
              className="flex items-center gap-2 px-4 py-2 bg-accent text-white rounded-xl text-xs font-semibold hover:opacity-95 shadow-md shadow-accent/25 transition-all active:scale-95"
            >
              <Plus size={16} />
              <span>New Status</span>
            </button>
          )}

          {activeSection === 'groups' && onOpenCreateGroup && (
            <button
              onClick={onOpenCreateGroup}
              className="flex items-center gap-2 px-4 py-2 bg-accent text-white rounded-xl text-xs font-semibold hover:opacity-95 shadow-md shadow-accent/25 transition-all active:scale-95"
            >
              <Plus size={16} />
              <span>New Group</span>
            </button>
          )}

          {activeSection === 'channels' && onOpenCreateChannel && (
            <button
              onClick={onOpenCreateChannel}
              className="flex items-center gap-2 px-4 py-2 bg-accent text-white rounded-xl text-xs font-semibold hover:opacity-95 shadow-md shadow-accent/25 transition-all active:scale-95"
            >
              <Plus size={16} />
              <span>New Channel</span>
            </button>
          )}
        </div>

        {/* Section Switcher Tabs: Status, Groups, Channels */}
        <div className="flex items-center gap-2 pt-1 border-t border-border/40">
          <button
            onClick={() => {
              setActiveSection('status');
              setSearchQuery('');
            }}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              activeSection === 'status'
                ? 'bg-accent text-white shadow-xs'
                : 'text-muted hover:text-foreground hover:bg-input'
            }`}
          >
            <CircleDot size={14} />
            <span>Status / Stories</span>
            {recentStatuses.length > 0 && (
              <span
                className={`px-1.5 py-0.2 min-w-4 text-[10px] font-bold rounded-full ${
                  activeSection === 'status'
                    ? 'bg-white text-accent'
                    : 'bg-accent text-white'
                }`}
              >
                {recentStatuses.length}
              </span>
            )}
          </button>

          <button
            onClick={() => {
              setActiveSection('groups');
              setSearchQuery('');
            }}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              activeSection === 'groups'
                ? 'bg-accent text-white shadow-xs'
                : 'text-muted hover:text-foreground hover:bg-input'
            }`}
          >
            <Users size={14} />
            <span>Groups</span>
            <span
              className={`px-1.5 py-0.2 min-w-4 text-[10px] font-bold rounded-full ${
                activeSection === 'groups'
                  ? 'bg-white text-accent'
                  : 'bg-input text-muted'
              }`}
            >
              {allGroups.length}
            </span>
          </button>

          <button
            onClick={() => {
              setActiveSection('channels');
              setSearchQuery('');
            }}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              activeSection === 'channels'
                ? 'bg-accent text-white shadow-xs'
                : 'text-muted hover:text-foreground hover:bg-input'
            }`}
          >
            <Radio size={14} />
            <span>Channels</span>
            <span
              className={`px-1.5 py-0.2 min-w-4 text-[10px] font-bold rounded-full ${
                activeSection === 'channels'
                  ? 'bg-white text-accent'
                  : 'bg-input text-muted'
              }`}
            >
              {allChannels.length}
            </span>
          </button>
        </div>
      </div>

      {/* Main Body */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-5 pb-20 md:pb-6 max-w-3xl mx-auto w-full flex flex-col gap-6">
        {/* ========================================================= */}
        {/* 1. STATUS & STORIES TAB CONTENT */}
        {/* ========================================================= */}
        {activeSection === 'status' && (
          <>
            {/* My Status Card */}
            <div className="bg-card p-4 rounded-2xl border border-border shadow-xs flex items-center justify-between">
              <div className="flex items-center gap-3.5">
                <div className="relative">
                  <Avatar
                    src={user?.avatar_url}
                    name={user?.display_name || 'My Status'}
                    size="lg"
                  />
                  <button
                    onClick={onOpenCreateStatus}
                    className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-accent text-white flex items-center justify-center border-2 border-card shadow-sm hover:scale-110 transition-transform"
                    title="Add New Status"
                  >
                    <Plus size={14} />
                  </button>
                </div>

                <div>
                  <h4 className="font-display font-semibold text-sm text-foreground">
                    My Status
                  </h4>
                  <p className="text-xs text-muted">
                    {myStatuses.length > 0
                      ? `${myStatuses.length} active story updates • Tap to add more`
                      : 'Tap plus to share a photo, video, or text story'}
                  </p>
                </div>
              </div>

              {myStatuses.length > 0 && (
                <button
                  onClick={() => onOpenStoryViewer(myStatuses[0])}
                  className="px-3.5 py-1.5 bg-input hover:bg-border/60 text-xs font-semibold text-foreground rounded-xl transition-colors"
                >
                  View Mine
                </button>
              )}
            </div>

            {/* Recent Updates */}
            <div className="flex flex-col gap-3">
              <span className="text-xs font-semibold text-muted uppercase tracking-wider px-1">
                Recent Updates ({recentStatuses.length})
              </span>

              {recentStatuses.length === 0 ? (
                <div className="p-6 bg-card/40 rounded-2xl border border-dashed border-border/70 text-center text-xs text-muted">
                  No recent status updates from contacts. Check back soon or create your own!
                </div>
              ) : (
                <div className="flex flex-col gap-2">
                  {recentStatuses.map((story) => (
                    <div
                      key={story.id}
                      onClick={() => onOpenStoryViewer(story)}
                      className="bg-card p-3.5 rounded-2xl border border-border flex items-center justify-between hover:border-accent/50 cursor-pointer transition-all shadow-xs group"
                    >
                      <div className="flex items-center gap-3.5">
                        <div className="p-0.5 rounded-full ring-2 ring-accent ring-offset-2 ring-offset-card transition-transform group-hover:scale-105">
                          <Avatar
                            src={story.author.avatar_url}
                            name={story.author.display_name}
                            size="md"
                          />
                        </div>

                        <div>
                          <h4 className="font-semibold text-sm text-foreground">
                            {story.author.display_name}
                          </h4>
                          <p className="text-xs text-muted flex items-center gap-1.5 mt-0.5">
                            <Clock size={11} />
                            <span>{formatTimeAgo(story.created_at)}</span>
                            <span>•</span>
                            <span className="font-mono text-accent">
                              {story.media_type.toUpperCase()}
                            </span>
                          </p>
                        </div>
                      </div>

                      <span className="text-xs text-accent font-semibold flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
                        <span>View</span>
                        <span>→</span>
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Viewed Updates */}
            {viewedStatuses.length > 0 && (
              <div className="flex flex-col gap-3">
                <span className="text-xs font-semibold text-muted uppercase tracking-wider px-1">
                  Viewed Updates ({viewedStatuses.length})
                </span>

                <div className="flex flex-col gap-2">
                  {viewedStatuses.map((story) => (
                    <div
                      key={story.id}
                      onClick={() => onOpenStoryViewer(story)}
                      className="bg-card/70 p-3 rounded-2xl border border-border/60 flex items-center justify-between hover:bg-card cursor-pointer transition-colors"
                    >
                      <div className="flex items-center gap-3.5">
                        <div className="p-0.5 rounded-full ring-1 ring-border">
                          <Avatar
                            src={story.author.avatar_url}
                            name={story.author.display_name}
                            size="md"
                          />
                        </div>

                        <div>
                          <h4 className="font-medium text-sm text-foreground">
                            {story.author.display_name}
                          </h4>
                          <p className="text-xs text-muted flex items-center gap-1 mt-0.5">
                            <Clock size={11} />
                            <span>{formatTimeAgo(story.created_at)}</span>
                          </p>
                        </div>
                      </div>

                      <span className="text-xs text-muted font-medium">Viewed</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}

        {/* ========================================================= */}
        {/* 2. GROUPS TAB CONTENT */}
        {/* ========================================================= */}
        {activeSection === 'groups' && (
          <div className="flex flex-col gap-4">
            {/* Search filter for Groups */}
            <div className="relative">
              <span className="absolute left-3.5 top-2.5 text-muted">
                <Search size={16} />
              </span>
              <input
                type="text"
                placeholder="Search groups..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-input text-foreground text-xs rounded-xl border border-border focus:outline-none focus:border-accent"
              />
            </div>

            {/* Groups list */}
            {filteredGroups.length === 0 ? (
              <div className="p-8 bg-card rounded-2xl border border-dashed border-border text-center flex flex-col items-center justify-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-accent-soft text-accent flex items-center justify-center">
                  <Users size={24} />
                </div>
                <div>
                  <h4 className="font-display font-semibold text-sm text-foreground">
                    {searchQuery ? 'No matching groups found' : 'No Groups Yet'}
                  </h4>
                  <p className="text-xs text-muted mt-1 max-w-sm">
                    {searchQuery
                      ? 'Try another search term or clear the filter.'
                      : 'Create a group to chat, share media, and stay connected with multiple contacts at once.'}
                  </p>
                </div>
                {onOpenCreateGroup && !searchQuery && (
                  <button
                    onClick={onOpenCreateGroup}
                    className="flex items-center gap-2 px-4 py-2 bg-accent text-white rounded-xl text-xs font-semibold hover:opacity-95 shadow-md shadow-accent/25 transition-all"
                  >
                    <Plus size={15} />
                    <span>Create Your First Group</span>
                  </button>
                )}
              </div>
            ) : (
              <div className="flex flex-col gap-2.5">
                {filteredGroups.map((group) => {
                  const memberCount = group.members?.length || 1;
                  const lastMessage = group.last_message;

                  return (
                    <div
                      key={group.id}
                      className="bg-card p-4 rounded-2xl border border-border flex items-center justify-between gap-3 hover:border-accent/40 transition-all shadow-xs"
                    >
                      <div
                        onClick={() => handleOpenConversation(group.id)}
                        className="flex items-center gap-3.5 min-w-0 flex-1 cursor-pointer"
                      >
                        <Avatar
                          src={group.avatar_url}
                          name={group.name || 'Group'}
                          size="md"
                        />

                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2">
                            <h4 className="font-semibold text-sm text-foreground truncate">
                              {group.name}
                            </h4>
                            <span className="px-2 py-0.2 text-[10px] font-semibold bg-input text-muted rounded-full border border-border">
                              {memberCount} {memberCount === 1 ? 'member' : 'members'}
                            </span>
                          </div>

                          {group.description && (
                            <p className="text-xs text-muted truncate mt-0.5">
                              {group.description}
                            </p>
                          )}

                          {lastMessage && (
                            <p className="text-[11px] text-muted/80 truncate mt-1 flex items-center gap-1.5">
                              <span className="font-medium text-foreground/80">
                                {lastMessage.sender_profile?.display_name || 'Member'}:
                              </span>
                              <span>{lastMessage.content}</span>
                              <span>•</span>
                              <span className="font-mono">
                                {formatLastMessageTime(lastMessage.created_at)}
                              </span>
                            </p>
                          )}
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center gap-1.5 flex-shrink-0">
                        {onOpenGroupInfo && (
                          <button
                            onClick={() => onOpenGroupInfo(group)}
                            className="p-2 text-muted hover:text-foreground rounded-xl hover:bg-input transition-colors"
                            title="Group Info"
                          >
                            <Info size={17} />
                          </button>
                        )}

                        <button
                          onClick={() => handleOpenConversation(group.id)}
                          className="flex items-center gap-1 px-3 py-1.5 bg-accent text-white rounded-xl text-xs font-semibold hover:opacity-95 shadow-sm transition-all"
                        >
                          <MessageSquare size={14} />
                          <span>Open Chat</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ========================================================= */}
        {/* 3. CHANNELS TAB CONTENT */}
        {/* ========================================================= */}
        {activeSection === 'channels' && (
          <div className="flex flex-col gap-4">
            {/* Search filter for Channels */}
            <div className="relative">
              <span className="absolute left-3.5 top-2.5 text-muted">
                <Search size={16} />
              </span>
              <input
                type="text"
                placeholder="Search channels..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-input text-foreground text-xs rounded-xl border border-border focus:outline-none focus:border-accent"
              />
            </div>

            {/* Channels list */}
            {filteredChannels.length === 0 ? (
              <div className="p-8 bg-card rounded-2xl border border-dashed border-border text-center flex flex-col items-center justify-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-accent-soft text-accent flex items-center justify-center">
                  <Radio size={24} />
                </div>
                <div>
                  <h4 className="font-display font-semibold text-sm text-foreground">
                    {searchQuery ? 'No matching channels found' : 'No Channels Yet'}
                  </h4>
                  <p className="text-xs text-muted mt-1 max-w-sm">
                    {searchQuery
                      ? 'Try searching with a different name or clear the filter.'
                      : 'Channels allow you to broadcast announcements, links, news, and updates to followers.'}
                  </p>
                </div>
                {onOpenCreateChannel && !searchQuery && (
                  <button
                    onClick={onOpenCreateChannel}
                    className="flex items-center gap-2 px-4 py-2 bg-accent text-white rounded-xl text-xs font-semibold hover:opacity-95 shadow-md shadow-accent/25 transition-all"
                  >
                    <Plus size={15} />
                    <span>Create Your First Channel</span>
                  </button>
                )}
              </div>
            ) : (
              <div className="flex flex-col gap-2.5">
                {filteredChannels.map((channel) => {
                  const rawDesc = channel.description || '';
                  const cleanDesc = rawDesc.replace(/^\[Channel\]\s*/, '');
                  const isCreator = channel.created_by === user?.id;

                  return (
                    <div
                      key={channel.id}
                      className="bg-card p-4 rounded-2xl border border-border flex items-center justify-between gap-3 hover:border-accent/40 transition-all shadow-xs"
                    >
                      <div
                        onClick={() => handleOpenConversation(channel.id)}
                        className="flex items-center gap-3.5 min-w-0 flex-1 cursor-pointer"
                      >
                        <div className="w-10 h-10 rounded-xl bg-accent/15 text-accent flex items-center justify-center flex-shrink-0 font-bold border border-accent/20">
                          <Radio size={18} />
                        </div>

                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2">
                            <h4 className="font-semibold text-sm text-foreground truncate">
                              {channel.name}
                            </h4>
                            <span className="px-2 py-0.2 text-[10px] font-semibold bg-accent-soft text-accent rounded-full border border-accent/20">
                              Broadcast
                            </span>
                            {isCreator && (
                              <span className="px-1.5 py-0.2 text-[9px] font-semibold bg-input text-muted rounded-full">
                                Admin
                              </span>
                            )}
                          </div>

                          {cleanDesc && (
                            <p className="text-xs text-muted truncate mt-0.5">
                              {cleanDesc}
                            </p>
                          )}
                        </div>
                      </div>

                      {/* Open channel button */}
                      <button
                        onClick={() => handleOpenConversation(channel.id)}
                        className="flex items-center gap-1 px-3 py-1.5 bg-accent text-white rounded-xl text-xs font-semibold hover:opacity-95 shadow-sm transition-all flex-shrink-0"
                      >
                        <Radio size={13} />
                        <span>Open Channel</span>
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
