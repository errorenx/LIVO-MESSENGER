import React, { useState, useEffect, useRef } from 'react';
import { X, ChevronLeft, ChevronRight, Eye, Clock } from 'lucide-react';
import { StatusStory } from '../../types';
import { Avatar } from '../common/Avatar';
import { useChat } from '../../contexts/ChatContext';

interface StatusStoryViewerProps {
  status: StatusStory;
  onClose: () => void;
  onNext?: () => void;
  onPrev?: () => void;
}

export const StatusStoryViewer: React.FC<StatusStoryViewerProps> = ({
  status,
  onClose,
  onNext,
  onPrev,
}) => {
  const { viewStatusStory } = useChat();
  const [progress, setProgress] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const duration = 6000; // 6 seconds per story

  useEffect(() => {
    viewStatusStory(status.id);
  }, [status.id]);

  useEffect(() => {
    setProgress(0);
    const interval = 50; // update every 50ms
    const step = (interval / duration) * 100;

    const timer = setInterval(() => {
      if (!isPaused) {
        setProgress((prev) => {
          if (prev >= 100) {
            clearInterval(timer);
            if (onNext) onNext();
            else onClose();
            return 100;
          }
          return prev + step;
        });
      }
    }, interval);

    return () => clearInterval(timer);
  }, [status.id, isPaused]);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 select-none animate-in fade-in duration-200"
      onMouseDown={() => setIsPaused(true)}
      onMouseUp={() => setIsPaused(false)}
      onTouchStart={() => setIsPaused(true)}
      onTouchEnd={() => setIsPaused(false)}
    >
      {/* Story Window Frame */}
      <div className="relative w-full max-w-md h-[90vh] max-h-[820px] rounded-3xl overflow-hidden shadow-2xl flex flex-col justify-between bg-slate-900 border border-white/10">
        {/* Top Progress bar */}
        <div className="absolute top-0 left-0 right-0 p-3 flex flex-col gap-3 z-30 bg-gradient-to-b from-black/80 via-black/40 to-transparent">
          <div className="w-full h-1 bg-white/30 rounded-full overflow-hidden">
            <div
              className="h-full bg-white transition-all duration-75"
              style={{ width: `${progress}%` }}
            />
          </div>

          {/* Author Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Avatar
                src={status.author.avatar_url}
                name={status.author.display_name}
                size="sm"
              />
              <div className="flex flex-col text-white">
                <span className="font-semibold text-xs drop-shadow-sm">
                  {status.author.display_name}
                </span>
                <span className="text-[10px] text-white/70 font-mono">
                  {status.author.username}
                </span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-full bg-white/10 hover:bg-white/25 text-white transition-colors"
            >
              <X size={16} />
            </button>
          </div>
        </div>

        {/* Story Center Content */}
        <div className="w-full h-full flex items-center justify-center relative overflow-hidden">
          {status.media_type === 'text' ? (
            <div
              className={`w-full h-full bg-gradient-to-br ${
                status.bg_gradient || 'from-violet-600 to-indigo-800'
              } p-8 flex items-center justify-center text-center`}
            >
              <p className="font-display font-bold text-2xl text-white drop-shadow-md leading-relaxed max-w-sm">
                {status.content}
              </p>
            </div>
          ) : (
            <div className="w-full h-full relative flex items-center justify-center bg-black">
              {status.media_url && (
                <img
                  src={status.media_url}
                  alt="Status"
                  className="w-full h-full object-cover"
                />
              )}
              {status.content && (
                <div className="absolute bottom-16 left-0 right-0 p-4 bg-gradient-to-t from-black/90 to-transparent text-center">
                  <p className="text-white text-sm font-medium drop-shadow-md">
                    {status.content}
                  </p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Bottom Viewers count */}
        <div className="absolute bottom-3 left-0 right-0 flex items-center justify-center z-30">
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-black/50 backdrop-blur-md text-white/90 text-xs font-medium border border-white/10">
            <Eye size={13} />
            <span>{status.views_count} views</span>
          </div>
        </div>

        {/* Tap zones for Next/Prev */}
        <div
          className="absolute inset-y-0 left-0 w-1/3 cursor-pointer z-10"
          onClick={(e) => {
            e.stopPropagation();
            if (onPrev) onPrev();
          }}
        />
        <div
          className="absolute inset-y-0 right-0 w-1/3 cursor-pointer z-10"
          onClick={(e) => {
            e.stopPropagation();
            if (onNext) onNext();
            else onClose();
          }}
        />
      </div>
    </div>
  );
};
