import React, { useState, useRef } from 'react';
import { X, Type, Image as ImageIcon, Sparkles, Send, Upload, Loader2 } from 'lucide-react';
import { useChat } from '../../contexts/ChatContext';
import { uploadStatusMedia } from '../../services/storageService';

interface CreateStatusModalProps {
  onClose: () => void;
}

export const CreateStatusModal: React.FC<CreateStatusModalProps> = ({ onClose }) => {
  const { createStatusStory } = useChat();
  const [tab, setTab] = useState<'text' | 'media'>('text');
  const [content, setContent] = useState('');
  const [mediaUrl, setMediaUrl] = useState('');
  const [selectedGradient, setSelectedGradient] = useState('from-violet-600 via-purple-600 to-indigo-800');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const gradients = [
    { name: 'Cosmic Violet', value: 'from-violet-600 via-purple-600 to-indigo-800' },
    { name: 'Neon Cyber', value: 'from-blue-600 via-indigo-600 to-cyan-500' },
    { name: 'Emerald Forest', value: 'from-emerald-600 via-teal-600 to-cyan-700' },
    { name: 'Sunset Glow', value: 'from-rose-500 via-pink-600 to-amber-500' },
    { name: 'Solar Flare', value: 'from-amber-500 via-orange-600 to-rose-600' },
    { name: 'Midnight Minimal', value: 'from-slate-900 via-indigo-950 to-slate-900' },
  ];

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const url = await uploadStatusMedia(file);
      setMediaUrl(url);
    } catch (err) {
      console.error('Failed to upload status image:', err);
      // Fallback
      setMediaUrl(URL.createObjectURL(file));
    } finally {
      setIsUploading(false);
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim() && !mediaUrl.trim()) return;

    setIsSubmitting(true);
    await createStatusStory(
      content.trim() || undefined,
      tab === 'text' ? 'text' : 'image',
      tab === 'media' ? mediaUrl.trim() : undefined,
      tab === 'text' ? selectedGradient : undefined
    );
    setIsSubmitting(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4 animate-in fade-in duration-200 select-none">
      <div className="bg-card w-full max-w-md rounded-3xl border border-border p-6 shadow-2xl flex flex-col gap-4 max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 font-display font-semibold text-lg text-foreground">
            <Sparkles size={18} className="text-accent" />
            <span>Create Status Story</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-muted hover:text-foreground rounded-xl hover:bg-input transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center gap-2 p-1 bg-input rounded-xl text-xs font-semibold">
          <button
            type="button"
            onClick={() => setTab('text')}
            className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg transition-all ${
              tab === 'text' ? 'bg-card text-foreground shadow-xs' : 'text-muted'
            }`}
          >
            <Type size={14} />
            <span>Text Status</span>
          </button>
          <button
            type="button"
            onClick={() => setTab('media')}
            className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg transition-all ${
              tab === 'media' ? 'bg-card text-foreground shadow-xs' : 'text-muted'
            }`}
          >
            <ImageIcon size={14} />
            <span>Photo / Media</span>
          </button>
        </div>

        <form onSubmit={handleCreate} className="flex flex-col gap-4">
          {tab === 'text' ? (
            <>
              {/* Text Preview Box */}
              <div
                className={`w-full h-56 rounded-2xl bg-gradient-to-br ${selectedGradient} p-6 flex items-center justify-center text-center shadow-inner relative overflow-hidden`}
              >
                <textarea
                  placeholder="Type your story update..."
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  className="w-full bg-transparent text-white font-display font-semibold text-lg sm:text-xl text-center placeholder:text-white/60 focus:outline-none resize-none"
                  rows={4}
                  maxLength={180}
                  autoFocus
                />
              </div>

              {/* Gradient Palette Select */}
              <div className="flex flex-col gap-1.5">
                <span className="text-xs font-semibold text-muted">Theme Background:</span>
                <div className="grid grid-cols-6 gap-2">
                  {gradients.map((g) => (
                    <button
                      key={g.name}
                      type="button"
                      onClick={() => setSelectedGradient(g.value)}
                      className={`h-8 rounded-xl bg-gradient-to-br ${g.value} transition-transform hover:scale-105 ${
                        selectedGradient === g.value
                          ? 'ring-2 ring-accent ring-offset-2 ring-offset-card scale-105'
                          : ''
                      }`}
                      title={g.name}
                    />
                  ))}
                </div>
              </div>
            </>
          ) : (
            <>
              {/* Media File Upload */}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,video/*"
                onChange={handleFileUpload}
                className="hidden"
              />

              {mediaUrl ? (
                <div className="relative h-52 rounded-2xl overflow-hidden bg-input/40 border border-border flex items-center justify-center">
                  <img src={mediaUrl} alt="Preview" className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => setMediaUrl('')}
                    className="absolute top-2 right-2 p-1.5 bg-black/60 hover:bg-black/80 text-white rounded-full transition-colors"
                  >
                    <X size={15} />
                  </button>
                </div>
              ) : (
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-border/80 hover:border-accent rounded-2xl p-8 flex flex-col items-center justify-center gap-3 cursor-pointer hover:bg-input/50 transition-all text-center"
                >
                  <div className="p-3.5 rounded-2xl bg-accent/15 text-accent">
                    {isUploading ? <Loader2 size={24} className="animate-spin" /> : <Upload size={24} />}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">
                      {isUploading ? 'Uploading media...' : 'Upload Image or Video'}
                    </p>
                    <p className="text-xs text-muted mt-0.5">Click to browse device</p>
                  </div>
                </div>
              )}

              <input
                type="text"
                placeholder="Add a caption to your story..."
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-input text-foreground text-xs rounded-xl border border-border focus:outline-none focus:border-accent mt-1"
              />
            </>
          )}

          {/* Actions */}
          <div className="flex items-center justify-end gap-2 mt-2 pt-2 border-t border-border">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-muted hover:text-foreground hover:bg-input transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={(!content.trim() && !mediaUrl.trim()) || isSubmitting || isUploading}
              className="flex items-center gap-2 px-5 py-2 bg-accent text-white rounded-xl text-xs font-semibold hover:opacity-95 shadow-md shadow-accent/25 transition-all disabled:opacity-50"
            >
              <Send size={14} />
              <span>{isSubmitting ? 'Publishing...' : 'Share Status'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
