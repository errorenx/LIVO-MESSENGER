import React from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  className?: string;
}

export const Logo: React.FC<LogoProps> = ({ size = 'md', showText = true, className = '' }) => {
  const sizeMap = {
    sm: { icon: 24, text: 'text-base' },
    md: { icon: 32, text: 'text-xl' },
    lg: { icon: 44, text: 'text-2xl' },
    xl: { icon: 56, text: 'text-3xl' },
  };

  const current = sizeMap[size];

  return (
    <div className={`flex items-center gap-2.5 select-none ${className}`}>
      {/* Original Futuristic LIVO Icon (Twin Geometric Nodes & Signal Wave) */}
      <div
        className="relative flex items-center justify-center rounded-xl p-1.5 transition-transform hover:scale-105"
        style={{
          width: current.icon + 10,
          height: current.icon + 10,
          background: 'linear-gradient(135deg, var(--accent) 0%, #1e1b4b 140%)',
          boxShadow: '0 8px 24px -4px var(--accent-glow)',
        }}
      >
        <svg
          width={current.icon}
          height={current.icon}
          viewBox="0 0 48 48"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="text-white drop-shadow-md"
        >
          {/* Signal Orbit rings */}
          <circle cx="24" cy="24" r="18" stroke="currentColor" strokeWidth="2.5" strokeOpacity="0.3" strokeDasharray="4 4" />
          <path
            d="M14 26C14 20.4772 18.4772 16 24 16C29.5228 16 34 20.4772 34 26"
            stroke="currentColor"
            strokeWidth="3.5"
            strokeLinecap="round"
          />
          {/* Pulsing Core Node */}
          <circle cx="24" cy="24" r="5" fill="currentColor" />
          {/* Dynamic Communication Nodes */}
          <circle cx="16" cy="32" r="3.5" fill="currentColor" />
          <circle cx="32" cy="32" r="3.5" fill="currentColor" />
          <path d="M16 32L24 24L32 32" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
        </svg>
      </div>

      {showText && (
        <div className="flex flex-col">
          <span className={`font-display font-extrabold tracking-wider ${current.text} text-foreground leading-none`}>
            LIVO
          </span>
          <span className="text-[10px] uppercase font-semibold tracking-widest text-muted mt-0.5">
            Connect
          </span>
        </div>
      )}
    </div>
  );
};
