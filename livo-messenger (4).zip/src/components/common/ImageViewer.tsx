import React from 'react';
import { X, Download, ZoomIn, ZoomOut } from 'lucide-react';

interface ImageViewerProps {
  src: string;
  alt?: string;
  onClose: () => void;
}

export const ImageViewer: React.FC<ImageViewerProps> = ({ src, alt = 'Media preview', onClose }) => {
  const [scale, setScale] = React.useState(1);

  const zoomIn = () => setScale((s) => Math.min(3, s + 0.25));
  const zoomOut = () => setScale((s) => Math.max(0.5, s - 0.25));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4 animate-in fade-in duration-200">
      {/* Top controls */}
      <div className="absolute top-4 right-4 flex items-center gap-2 z-10">
        <button
          onClick={zoomIn}
          className="p-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
          title="Zoom In"
        >
          <ZoomIn size={18} />
        </button>
        <button
          onClick={zoomOut}
          className="p-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
          title="Zoom Out"
        >
          <ZoomOut size={18} />
        </button>
        <a
          href={src}
          download="livo-image.jpg"
          target="_blank"
          rel="noreferrer"
          className="p-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
          title="Download Image"
        >
          <Download size={18} />
        </a>
        <button
          onClick={onClose}
          className="p-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
          title="Close Viewer"
        >
          <X size={18} />
        </button>
      </div>

      {/* Image Container */}
      <div className="max-w-4xl max-h-[85vh] overflow-hidden flex items-center justify-center">
        <img
          src={src}
          alt={alt}
          style={{ transform: `scale(${scale})` }}
          className="max-w-full max-h-[85vh] object-contain rounded-lg transition-transform duration-200 shadow-2xl select-none"
        />
      </div>
    </div>
  );
};
