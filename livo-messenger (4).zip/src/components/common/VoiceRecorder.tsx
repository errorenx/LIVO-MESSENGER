import React, { useState, useRef, useEffect } from 'react';
import { Square, Trash2, Send, Loader2 } from 'lucide-react';
import { uploadVoiceRecording } from '../../services/storageService';

interface VoiceRecorderProps {
  onSendVoice: (audioUrl: string, durationSec: number) => void;
  onCancel: () => void;
}

export const VoiceRecorder: React.FC<VoiceRecorderProps> = ({ onSendVoice, onCancel }) => {
  const [recordingTime, setRecordingTime] = useState<number>(0);
  const [isRecording, setIsRecording] = useState<boolean>(true);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [hasPermissionError, setHasPermissionError] = useState<boolean>(false);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<any>(null);

  useEffect(() => {
    let stream: MediaStream | null = null;

    const startRecording = async () => {
      try {
        if (!navigator.mediaDevices?.getUserMedia) {
          throw new Error('Microphone not supported');
        }

        stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const mediaRecorder = new MediaRecorder(stream);
        mediaRecorderRef.current = mediaRecorder;
        audioChunksRef.current = [];

        mediaRecorder.ondataavailable = (event) => {
          if (event.data.size > 0) {
            audioChunksRef.current.push(event.data);
          }
        };

        mediaRecorder.start();

        timerRef.current = setInterval(() => {
          setRecordingTime((prev) => prev + 1);
        }, 1000);
      } catch (err) {
        console.warn('Microphone permission not granted or unavailable:', err);
        setHasPermissionError(true);
        timerRef.current = setInterval(() => {
          setRecordingTime((prev) => prev + 1);
        }, 1000);
      }
    };

    startRecording();

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
        mediaRecorderRef.current.stop();
      }
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const handleStopAndSend = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    setIsRecording(false);
    setIsProcessing(true);

    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.onstop = async () => {
        try {
          const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
          const audioUrl = await uploadVoiceRecording(audioBlob);
          onSendVoice(audioUrl, Math.max(1, recordingTime));
        } catch (err) {
          console.error('Failed to upload voice memo:', err);
          const fallbackBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
          onSendVoice(URL.createObjectURL(fallbackBlob), Math.max(1, recordingTime));
        } finally {
          setIsProcessing(false);
        }
      };
      mediaRecorderRef.current.stop();
    } else {
      setIsProcessing(false);
      onCancel();
    }
  };

  const handleCancel = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop();
    }
    onCancel();
  };

  return (
    <div className="flex items-center gap-3 w-full px-3 py-2 bg-card rounded-2xl border border-border shadow-md animate-in fade-in zoom-in-95">
      {/* Recording indicator */}
      <div className="flex items-center gap-2">
        <span className="relative flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-3 w-3 bg-rose-500"></span>
        </span>
        <span className="text-xs font-mono font-semibold text-rose-500">
          {formatTime(recordingTime)}
        </span>
      </div>

      {/* Live Audio Waves */}
      <div className="flex-1 flex items-center justify-center gap-1 h-8">
        <span className="w-1 bg-accent rounded-full animate-wave-1"></span>
        <span className="w-1 bg-accent rounded-full animate-wave-2"></span>
        <span className="w-1 bg-accent rounded-full animate-wave-3"></span>
        <span className="w-1 bg-accent rounded-full animate-wave-4"></span>
        <span className="w-1 bg-accent rounded-full animate-wave-5"></span>
        <span className="w-1 bg-accent rounded-full animate-wave-2"></span>
        <span className="w-1 bg-accent rounded-full animate-wave-1"></span>
        {hasPermissionError && (
          <span className="text-[11px] text-rose-400 ml-2">
            Microphone access required
          </span>
        )}
      </div>

      {/* Cancel button */}
      <button
        type="button"
        onClick={handleCancel}
        disabled={isProcessing}
        className="p-2 text-muted hover:text-rose-500 rounded-full hover:bg-input transition-colors disabled:opacity-50"
        title="Cancel voice memo"
      >
        <Trash2 size={18} />
      </button>

      {/* Send button */}
      <button
        type="button"
        onClick={handleStopAndSend}
        disabled={isProcessing || hasPermissionError}
        className="p-2 bg-accent text-white rounded-full hover:opacity-90 transition-transform active:scale-95 shadow-md shadow-accent/20 disabled:opacity-50"
        title="Send voice memo"
      >
        {isProcessing ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
      </button>
    </div>
  );
};
