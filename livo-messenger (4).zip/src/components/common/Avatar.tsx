import React from 'react';

interface AvatarProps {
  src?: string;
  name: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  status?: 'online' | 'offline' | 'away';
  showStatus?: boolean;
  className?: string;
  onClick?: () => void;
}

export const Avatar: React.FC<AvatarProps> = ({
  src,
  name,
  size = 'md',
  status,
  showStatus = false,
  className = '',
  onClick,
}) => {
  const sizeMap = {
    xs: { box: 'w-6 h-6', text: 'text-[10px]', badge: 'w-2 h-2 -bottom-0.5 -right-0.5' },
    sm: { box: 'w-8 h-8', text: 'text-xs', badge: 'w-2.5 h-2.5 bottom-0 right-0' },
    md: { box: 'w-10 h-10', text: 'text-sm', badge: 'w-3 h-3 bottom-0 right-0' },
    lg: { box: 'w-13 h-13', text: 'text-base', badge: 'w-3.5 h-3.5 bottom-0.5 right-0.5' },
    xl: { box: 'w-20 h-20', text: 'text-2xl', badge: 'w-5 h-5 bottom-1 right-1' },
  };

  const current = sizeMap[size];

  // Get initials
  const initials = name
    .replace(/^@/, '')
    .split(' ')
    .map((n) => n[0])
    .filter(Boolean)
    .slice(0, 2)
    .join('')
    .toUpperCase() || 'L';

  const statusColors = {
    online: 'bg-emerald-500 ring-2 ring-card',
    offline: 'bg-slate-400 ring-2 ring-card',
    away: 'bg-amber-500 ring-2 ring-card',
  };

  return (
    <div
      onClick={onClick}
      className={`relative inline-flex flex-shrink-0 select-none ${onClick ? 'cursor-pointer' : ''} ${className}`}
    >
      <div
        className={`${current.box} rounded-full overflow-hidden flex items-center justify-center font-display font-semibold transition-transform hover:opacity-95`}
        style={{
          backgroundColor: 'var(--input)',
          border: '1px solid var(--border)',
        }}
      >
        {src ? (
          <img
            src={src}
            alt={name}
            className="w-full h-full object-cover"
            onError={(e) => {
              // Hide broken image so fallback initials show
              (e.target as HTMLElement).style.display = 'none';
            }}
          />
        ) : (
          <span className={`${current.text} text-foreground/80`}>{initials}</span>
        )}
      </div>

      {showStatus && status && (
        <span
          className={`absolute rounded-full ${current.badge} ${statusColors[status]}`}
          title={`Status: ${status}`}
        />
      )}
    </div>
  );
};
