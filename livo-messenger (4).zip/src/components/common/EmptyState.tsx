import React from 'react';
import { LucideIcon, MessageSquare, Users, UserPlus } from 'lucide-react';

interface EmptyStateProps {
  icon?: LucideIcon;
  title?: string;
  description?: string;
  actionText?: string;
  onAction?: () => void;
  onStartChat?: () => void;
  onCreateGroup?: () => void;
  className?: string;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  icon: Icon = MessageSquare,
  title = 'Select a conversation',
  description = 'Connect with your contacts or start a group to begin messaging, voice calls, and video chats on LIVO.',
  actionText,
  onAction,
  onStartChat,
  onCreateGroup,
  className = '',
}) => {
  return (
    <div
      className={`h-full flex flex-col items-center justify-center text-center p-8 max-w-md mx-auto select-none ${className}`}
    >
      <div className="relative mb-5">
        <div className="w-20 h-20 rounded-3xl bg-accent/15 text-accent flex items-center justify-center border border-accent/30 shadow-lg shadow-accent/10 transition-transform hover:scale-105">
          <Icon size={36} />
        </div>
        <span className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-emerald-500 border-2 border-background flex items-center justify-center text-white text-[10px] font-bold">
          ✓
        </span>
      </div>

      <h3 className="font-display font-bold text-xl text-foreground mb-1">
        {title}
      </h3>
      <p className="text-xs text-muted mb-6 leading-relaxed max-w-sm">
        {description}
      </p>

      {/* Action button for Chat Workspace */}
      {onStartChat && (
        <div className="flex flex-wrap items-center justify-center gap-3">
          <button
            onClick={onStartChat}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold text-white bg-accent hover:opacity-95 shadow-md shadow-accent/25 transition-all active:scale-95"
          >
            <UserPlus size={15} />
            <span>Start New Chat</span>
          </button>
        </div>
      )}

      {actionText && onAction && !onStartChat && !onCreateGroup && (
        <button
          onClick={onAction}
          className="px-5 py-2.5 rounded-xl text-xs font-semibold text-white bg-accent hover:opacity-95 shadow-md shadow-accent/25 transition-all active:scale-95"
        >
          {actionText}
        </button>
      )}

      <div className="mt-8 flex items-center gap-2 text-[11px] text-muted/70 font-mono">
        <span>End-to-End Realtime</span>
        <span>•</span>
        <span>WebRTC Calling</span>
        <span>•</span>
        <span>LIVO</span>
      </div>
    </div>
  );
};
