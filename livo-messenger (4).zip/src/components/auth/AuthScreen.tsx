import React, { useState } from 'react';
import {
  Lock,
  Mail,
  User,
  Eye,
  EyeOff,
  ArrowRight,
  AlertCircle,
  CheckCircle2,
  KeyRound,
  Sparkles,
  Sun,
  Moon,
  Laptop,
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useTheme } from '../../contexts/ThemeContext';
import { Logo } from '../common/Logo';

export const AuthScreen: React.FC = () => {
  const { signIn, signUp, resetPassword, loginWithGoogle } = useAuth();
  const { themeMode, setThemeMode, effectiveTheme } = useTheme();

  // Navigation tabs: 'login' or 'register'
  const [authTab, setAuthTab] = useState<'login' | 'register'>('login');
  const [isForgotPassword, setIsForgotPassword] = useState<boolean>(false);

  // Registration form fields (only Gmail/Email details and password)
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  // Login form fields
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Forgot password field
  const [resetEmail, setResetEmail] = useState('');

  // UI state
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const handleTabChange = (tab: 'login' | 'register') => {
    setAuthTab(tab);
    setIsForgotPassword(false);
    setError('');
    setSuccessMessage('');
  };

  // 1. Handle Login
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');

    const identifier = loginIdentifier.trim();
    if (!identifier) {
      setError('Please enter your email address (Gmail) or username.');
      return;
    }
    if (!loginPassword) {
      setError('Please enter your password.');
      return;
    }

    setLoading(true);
    try {
      const res = await signIn(identifier, loginPassword);
      if (res.error) {
        setError(res.error);
      } else {
        setSuccessMessage('Logged in successfully! Opening website...');
      }
    } catch (err: any) {
      setError(err?.message || 'Login failed. Please verify your credentials and try again.');
    } finally {
      setLoading(false);
    }
  };

  // 2. Handle Register (CREATE ACCOUNT)
  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');

    const trimmedName = fullName.trim();
    const trimmedEmail = email.trim().toLowerCase();

    // Validate full name
    if (!trimmedName) {
      setError('Please enter your full name.');
      return;
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!trimmedEmail || !emailRegex.test(trimmedEmail)) {
      setError('Please enter a valid email address (e.g. yourname@gmail.com).');
      return;
    }

    // Validate password
    if (password.length < 6) {
      setError('Password must contain at least 6 characters.');
      return;
    }

    setLoading(true);
    try {
      const res = await signUp(trimmedEmail, password, trimmedName);
      if (res.error) {
        setError(res.error);
      } else {
        setSuccessMessage('Account created successfully! Opening LIVO Messenger...');
      }
    } catch (err: any) {
      setError(err?.message || 'Registration failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // 3. Handle Password Reset
  const handleResetSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');

    const trimmedEmail = resetEmail.trim().toLowerCase();
    if (!trimmedEmail || !trimmedEmail.includes('@')) {
      setError('Please enter your registered email address.');
      return;
    }

    setLoading(true);
    try {
      const res = await resetPassword(trimmedEmail);
      if (res.error) {
        setError(res.error);
      } else {
        setSuccessMessage('Password reset instructions have been sent to your email inbox.');
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to send reset link.');
    } finally {
      setLoading(false);
    }
  };

  // Quick fill test account
  const handleFillDemo = () => {
    setLoginIdentifier('demo@livomessenger.com');
    setLoginPassword('Password123!');
  };

  return (
    <div className="min-h-[100dvh] w-full flex items-center justify-center p-3 sm:p-6 md:p-10 bg-background text-foreground relative overflow-x-hidden select-none">
      {/* Background ambient lighting accents */}
      <div className="absolute top-1/4 left-1/4 w-72 sm:w-96 h-72 sm:h-96 rounded-full bg-accent/15 blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-72 sm:w-96 h-72 sm:h-96 rounded-full bg-accent/10 blur-3xl pointer-events-none" />

      {/* Top right theme switcher: White, Black, Rainbow */}
      <div className="absolute top-4 right-4 z-20 flex items-center gap-1 bg-card/80 backdrop-blur-md p-1 rounded-2xl border border-border shadow-sm">
        <button
          onClick={() => setThemeMode('white')}
          title="White Theme"
          className={`flex items-center gap-1 px-2 py-1 rounded-xl text-xs font-medium transition-all ${
            themeMode === 'white'
              ? 'bg-accent text-accent-contrast shadow-xs font-semibold'
              : 'text-muted hover:text-foreground'
          }`}
        >
          <Sun size={13} />
          <span className="text-[11px]">White</span>
        </button>
        <button
          onClick={() => setThemeMode('black')}
          title="Black Theme"
          className={`flex items-center gap-1 px-2 py-1 rounded-xl text-xs font-medium transition-all ${
            themeMode === 'black'
              ? 'bg-accent text-accent-contrast shadow-xs font-semibold'
              : 'text-muted hover:text-foreground'
          }`}
        >
          <Moon size={13} />
          <span className="text-[11px]">Black</span>
        </button>
        <button
          onClick={() => setThemeMode('rainbow')}
          title="Rainbow Theme (All in One)"
          className={`flex items-center gap-1 px-2 py-1 rounded-xl text-xs font-medium transition-all ${
            themeMode === 'rainbow'
              ? 'bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-400 text-white shadow-xs font-semibold'
              : 'text-muted hover:text-foreground'
          }`}
        >
          <Sparkles size={13} />
          <span className="text-[11px]">Rainbow</span>
        </button>
      </div>

      {/* Main card container - Fully responsive across mobile, tablet, and laptop */}
      <div className="relative z-10 w-full max-w-md sm:max-w-lg bg-card/95 backdrop-blur-xl border border-border rounded-3xl p-5 sm:p-7 md:p-8 shadow-2xl flex flex-col gap-5 sm:gap-6 my-auto">
        
        {/* Branding Header */}
        <div className="flex flex-col items-center text-center gap-1.5">
          <Logo size="lg" />
          <h1 className="font-display font-bold text-2xl sm:text-3xl text-foreground tracking-tight mt-1">
            LIVO
          </h1>
          <p className="text-[11px] sm:text-xs font-semibold text-accent uppercase tracking-widest">
            Connect. Talk. Share.
          </p>
        </div>

        {/* Global Error Banner */}
        {error && (
          <div className="p-3 sm:p-3.5 bg-rose-500/10 border border-rose-500/30 rounded-2xl flex items-start gap-2.5 text-xs text-rose-500">
            <AlertCircle size={17} className="flex-shrink-0 mt-0.5" />
            <span className="leading-relaxed font-medium">{error}</span>
          </div>
        )}

        {/* Global Success Banner */}
        {successMessage && (
          <div className="p-3 sm:p-3.5 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl flex items-center gap-2.5 text-xs text-emerald-500">
            <CheckCircle2 size={17} className="flex-shrink-0" />
            <span className="font-medium">{successMessage}</span>
          </div>
        )}

        {/* ========================================================================= */}
        {/* FORGOT PASSWORD VIEW                                                      */}
        {/* ========================================================================= */}
        {isForgotPassword ? (
          <form onSubmit={handleResetSubmit} className="flex flex-col gap-4">
            <div className="text-center">
              <h3 className="font-display font-bold text-base sm:text-lg text-foreground">
                Reset Password
              </h3>
              <p className="text-xs text-muted mt-1">
                Enter your registered email address to receive password reset instructions.
              </p>
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-foreground">Email Address</label>
              <div className="relative">
                <Mail size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" />
                <input
                  type="email"
                  required
                  placeholder="name@gmail.com"
                  value={resetEmail}
                  onChange={(e) => setResetEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 sm:py-3 bg-input text-foreground text-xs sm:text-sm rounded-xl border border-border focus:outline-none focus:border-accent"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 sm:py-3 bg-accent text-white font-bold text-xs sm:text-sm uppercase tracking-wider rounded-xl hover:opacity-95 shadow-md shadow-accent/25 transition-all active:scale-98 disabled:opacity-50 mt-1"
            >
              {loading ? 'Sending...' : 'Send Reset Link'}
            </button>

            <button
              type="button"
              onClick={() => {
                setIsForgotPassword(false);
                setError('');
                setSuccessMessage('');
              }}
              className="text-xs text-muted hover:text-foreground text-center transition-colors mt-1"
            >
              Back to Login
            </button>
          </form>
        ) : (
          <>
            {/* Primary Tab Switcher: LOGIN vs REGISTER */}
            <div className="grid grid-cols-2 p-1 bg-input rounded-2xl border border-border">
              <button
                type="button"
                onClick={() => handleTabChange('login')}
                className={`py-2 text-xs sm:text-sm font-semibold rounded-xl transition-all ${
                  authTab === 'login'
                    ? 'bg-card text-foreground shadow-xs'
                    : 'text-muted hover:text-foreground'
                }`}
              >
                Login
              </button>
              <button
                type="button"
                onClick={() => handleTabChange('register')}
                className={`py-2 text-xs sm:text-sm font-semibold rounded-xl transition-all ${
                  authTab === 'register'
                    ? 'bg-card text-foreground shadow-xs'
                    : 'text-muted hover:text-foreground'
                }`}
              >
                Register
              </button>
            </div>

            {/* ========================================================================= */}
            {/* TAB 1: LOGIN FORM                                                         */}
            {/* ========================================================================= */}
            {authTab === 'login' && (
              <form onSubmit={handleLoginSubmit} className="flex flex-col gap-3.5 sm:gap-4">
                {/* Email or Username */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-foreground">
                    Email or Username
                  </label>
                  <div className="relative">
                    <Mail size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" />
                    <input
                      type="text"
                      required
                      placeholder="yourname@gmail.com or @username"
                      value={loginIdentifier}
                      onChange={(e) => setLoginIdentifier(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 sm:py-3 bg-input text-foreground text-xs sm:text-sm rounded-xl border border-border focus:outline-none focus:border-accent"
                    />
                  </div>
                </div>

                {/* Password */}
                <div className="flex flex-col gap-1.5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-semibold text-foreground">Password</label>
                    <button
                      type="button"
                      onClick={() => {
                        setIsForgotPassword(true);
                        setResetEmail(loginIdentifier.includes('@') ? loginIdentifier : '');
                        setError('');
                        setSuccessMessage('');
                      }}
                      className="text-[11px] text-accent hover:underline font-medium"
                    >
                      Forgot password?
                    </button>
                  </div>
                  <div className="relative">
                    <Lock size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      placeholder="Enter your password"
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      className="w-full pl-10 pr-10 py-2.5 sm:py-3 bg-input text-foreground text-xs sm:text-sm rounded-xl border border-border focus:outline-none focus:border-accent"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-muted hover:text-foreground"
                    >
                      {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                    </button>
                  </div>
                </div>

                {/* LOGIN BUTTON */}
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-2.5 sm:py-3 bg-accent text-white font-bold text-xs sm:text-sm uppercase tracking-wider rounded-xl hover:opacity-95 shadow-md shadow-accent/25 transition-all active:scale-98 disabled:opacity-50 mt-1 flex items-center justify-center gap-2"
                >
                  {loading ? (
                    <span>Logging in...</span>
                  ) : (
                    <>
                      <span>LOGIN</span>
                      <ArrowRight size={15} />
                    </>
                  )}
                </button>

                {/* Demo autofill shortcut */}
                <div className="flex items-center justify-between pt-2 border-t border-border/80">
                  <button
                    type="button"
                    onClick={handleFillDemo}
                    className="text-[11px] text-muted hover:text-accent transition-colors flex items-center gap-1 font-medium"
                  >
                    <Sparkles size={13} />
                    <span>Fill Demo Credentials</span>
                  </button>
                </div>
              </form>
            )}

            {/* ========================================================================= */}
            {/* TAB 2: REGISTER FORM (ONLY GMAIL / DETAILS -> CREATE ACCOUNT)             */}
            {/* ========================================================================= */}
            {authTab === 'register' && (
              <form onSubmit={handleRegisterSubmit} className="flex flex-col gap-3 sm:gap-3.5">
                {/* Full Name */}
                <div className="flex flex-col gap-1">
                  <label className="text-xs font-semibold text-foreground">Full Name</label>
                  <div className="relative">
                    <User size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" />
                    <input
                      type="text"
                      required
                      placeholder="e.g. Alex Johnson"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 sm:py-2.5 bg-input text-foreground text-xs sm:text-sm rounded-xl border border-border focus:outline-none focus:border-accent"
                    />
                  </div>
                </div>

                {/* Email Address (Gmail) */}
                <div className="flex flex-col gap-1">
                  <label className="text-xs font-semibold text-foreground">Gmail / Email Address</label>
                  <div className="relative">
                    <Mail size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" />
                    <input
                      type="email"
                      required
                      placeholder="yourname@gmail.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 sm:py-2.5 bg-input text-foreground text-xs sm:text-sm rounded-xl border border-border focus:outline-none focus:border-accent"
                    />
                  </div>
                </div>

                {/* Password */}
                <div className="flex flex-col gap-1">
                  <label className="text-xs font-semibold text-foreground">Password</label>
                  <div className="relative">
                    <Lock size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      placeholder="At least 6 characters"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full pl-10 pr-10 py-2 sm:py-2.5 bg-input text-foreground text-xs sm:text-sm rounded-xl border border-border focus:outline-none focus:border-accent"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-muted hover:text-foreground"
                    >
                      {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                    </button>
                  </div>
                </div>

                {/* CREATE ACCOUNT BUTTON */}
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-2.5 sm:py-3 bg-accent text-white font-bold text-xs sm:text-sm uppercase tracking-wider rounded-xl hover:opacity-95 shadow-md shadow-accent/25 transition-all active:scale-98 disabled:opacity-50 mt-2 flex items-center justify-center gap-2"
                >
                  {loading ? (
                    <span>Creating Account...</span>
                  ) : (
                    <>
                      <span>CREATE ACCOUNT</span>
                      <ArrowRight size={15} />
                    </>
                  )}
                </button>
              </form>
            )}

            {/* Google OAuth Option */}
            <div className="flex flex-col gap-2 pt-2 border-t border-border">
              <button
                type="button"
                onClick={loginWithGoogle}
                className="w-full py-2.5 sm:py-2.5 px-4 bg-input hover:bg-border/60 text-foreground font-semibold text-xs sm:text-sm rounded-xl border border-border transition-colors flex items-center justify-center gap-2.5"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>Continue with Google</span>
              </button>
            </div>
          </>
        )}

        {/* Footer */}
        <p className="text-center text-[10px] sm:text-xs text-muted">
          By continuing, you agree to LIVO's Terms of Service and Privacy Policy.
        </p>
      </div>
    </div>
  );
};
