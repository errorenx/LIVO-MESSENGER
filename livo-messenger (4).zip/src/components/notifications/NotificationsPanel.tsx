import React from 'react';
import {
  Bell,
  CheckCheck,
  MessageSquare,
  UserPlus,
  Phone,
  Users,
  Clock,
} from 'lucide-react';
import { useChat } from '../../contexts/ChatContext';

export const NotificationsPanel: React.FC = () => {
  const { notifications, markNotificationRead, clearAllNotifications } = useChat();

  const getIcon = (type: string) => {
    switch (type) {
      case 'message':
        return <MessageSquare size={16} className="text-accent" />;
      case 'contact_request':
        return <UserPlus size={16} className="text-blue-500" />;
      case 'call':
        return <Phone size={16} className="text-emerald-500" />;
      case 'group':
        return <Users size={16} className="text-purple-500" />;
      default:
        return <Bell size={16} className="text-muted" />;
    }
  };

  const formatTime = (dateStr: string) => {
    const d = new Date(dateStr);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-sidebar/40 overflow-hidden select-none">
      {/* Header */}
      <div className="p-5 border-b border-border bg-card/60 backdrop-blur-md flex items-center justify-between">
        <div>
          <h2 className="font-display font-bold text-2xl text-foreground tracking-tight">
            Notifications
          </h2>
          <p className="text-xs text-muted mt-0.5">
            Realtime activity and direct interaction alerts
          </p>
        </div>

        {notifications.length > 0 && (
          <button
            onClick={clearAllNotifications}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-input hover:bg-border/60 text-xs font-semibold text-foreground rounded-xl transition-colors"
          >
            <CheckCheck size={14} />
            <span>Mark All Read</span>
          </button>
        )}
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto p-5 max-w-2xl mx-auto w-full">
        {notifications.length === 0 ? (
          <div className="py-16 text-center text-muted text-xs">
            No notifications. You are all caught up!
          </div>
        ) : (
          <div className="flex flex-col gap-2.5">
            {notifications.map((n) => {
              const isUnread = !n.read_at;

              return (
                <div
                  key={n.id}
                  onClick={() => markNotificationRead(n.id)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start gap-3.5 shadow-xs ${
                    isUnread
                      ? 'bg-card border-accent/40 shadow-accent/5'
                      : 'bg-card/70 border-border/60 hover:bg-card'
                  }`}
                >
                  <div className="p-2.5 rounded-xl bg-input flex-shrink-0 mt-0.5">
                    {getIcon(n.type)}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <h4
                        className={`text-sm truncate ${
                          isUnread ? 'font-bold text-foreground' : 'font-medium text-foreground/80'
                        }`}
                      >
                        {n.title}
                      </h4>
                      <span className="text-[11px] font-mono text-muted flex-shrink-0">
                        {formatTime(n.created_at)}
                      </span>
                    </div>
                    <p className="text-xs text-muted mt-0.5 leading-relaxed">{n.body}</p>
                  </div>

                  {isUnread && (
                    <span className="w-2 h-2 rounded-full bg-accent mt-2 flex-shrink-0" />
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
