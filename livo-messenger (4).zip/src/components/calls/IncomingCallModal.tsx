import React from 'react';
import { Phone, PhoneOff, Video } from 'lucide-react';
import { useCall } from '../../contexts/CallContext';
import { Avatar } from '../common/Avatar';

export const IncomingCallModal: React.FC = () => {
  const { incomingCall, acceptCall, rejectCall } = useCall();

  if (!incomingCall) return null;

  const isVideo = incomingCall.callType === 'video';
  const caller = incomingCall.callerProfile;
  const callerName = caller?.display_name || 'Incoming Caller';
  const callerUsername = caller?.username || 'user';
  const callerAvatar = caller?.avatar_url;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-md animate-in fade-in duration-300">
      <div className="relative w-full max-w-sm rounded-3xl bg-card border border-border p-6 shadow-2xl flex flex-col items-center text-center overflow-hidden">
        {/* Glow ambient background */}
        <div className="absolute -top-16 -left-16 w-32 h-32 rounded-full bg-accent/20 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -right-16 w-32 h-32 rounded-full bg-emerald-500/20 blur-3xl pointer-events-none" />

        {/* Call Type Badge */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-accent/15 text-accent border border-accent/20 text-xs font-semibold uppercase tracking-wider mb-6">
          {isVideo ? <Video size={14} /> : <Phone size={14} />}
          <span>Incoming {isVideo ? 'Video' : 'Voice'} Call</span>
        </div>

        {/* Pulsing Avatar */}
        <div className="relative mb-4">
          <span className="absolute -inset-3 rounded-full bg-emerald-500/30 animate-ping" />
          <span className="absolute -inset-6 rounded-full bg-accent/20 animate-pulse" />
          <Avatar
            src={callerAvatar}
            name={callerName}
            size="xl"
            className="relative ring-4 ring-card shadow-xl"
          />
        </div>

        <h3 className="font-display font-bold text-xl text-foreground mt-2">{callerName}</h3>
        <p className="text-xs font-mono text-muted mt-0.5">@{callerUsername}</p>

        <p className="text-xs text-muted font-medium mt-4 animate-pulse">
          Ringing on LIVO Messenger...
        </p>

        {/* Action Buttons */}
        <div className="flex items-center justify-center gap-6 mt-8 w-full">
          {/* Decline Button */}
          <div className="flex flex-col items-center gap-1.5">
            <button
              onClick={() => rejectCall('declined')}
              className="w-14 h-14 rounded-full bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center shadow-lg shadow-rose-600/30 transition-transform active:scale-95"
              title="Decline"
            >
              <PhoneOff size={22} />
            </button>
            <span className="text-[11px] font-medium text-muted">Decline</span>
          </div>

          {/* Accept Button */}
          <div className="flex flex-col items-center gap-1.5">
            <button
              onClick={acceptCall}
              className="w-14 h-14 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center shadow-lg shadow-emerald-600/30 transition-transform active:scale-95 animate-bounce"
              title="Accept"
            >
              {isVideo ? <Video size={22} /> : <Phone size={22} />}
            </button>
            <span className="text-[11px] font-medium text-emerald-400">Accept</span>
          </div>
        </div>
      </div>
    </div>
  );
};
