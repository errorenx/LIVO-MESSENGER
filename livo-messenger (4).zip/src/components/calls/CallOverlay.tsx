import React from 'react';
import {
  PhoneOff,
  Mic,
  MicOff,
  Video,
  VideoOff,
  ShieldCheck,
  AlertTriangle,
  RefreshCw,
  X,
  Volume2,
} from 'lucide-react';
import { useCall } from '../../contexts/CallContext';
import { Avatar } from '../common/Avatar';
import { IncomingCallModal } from './IncomingCallModal';

export const CallOverlay: React.FC = () => {
  const {
    activeCall,
    incomingCall,
    endCall,
    toggleMute,
    toggleCamera,
    callDuration,
    localVideoRef,
    remoteVideoRef,
    permissionError,
    clearPermissionError,
    retryCall,
  } = useCall();

  // Format call duration MM:SS
  const formatDuration = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remaining = secs % 60;
    return `${mins}:${remaining < 10 ? '0' : ''}${remaining}`;
  };

  // If there's an incoming call modal, render it
  const incomingModal = incomingCall ? <IncomingCallModal /> : null;

  if (!activeCall && !permissionError) {
    return incomingModal;
  }

  // Permission error overlay
  if (permissionError) {
    return (
      <>
        {incomingModal}
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-md rounded-3xl bg-card border border-border p-6 shadow-2xl flex flex-col items-center text-center">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/15 border border-amber-500/20 text-amber-500 flex items-center justify-center mb-4">
              <AlertTriangle size={28} />
            </div>

            <h3 className="font-display font-bold text-lg text-foreground mb-1">
              Media Permission Required
            </h3>
            <p className="text-sm text-muted mb-6 leading-relaxed">
              {permissionError}
            </p>

            <div className="flex items-center gap-3 w-full">
              <button
                onClick={clearPermissionError}
                className="flex-1 py-2.5 px-4 rounded-xl border border-border hover:bg-muted/10 text-foreground font-medium text-xs transition-colors"
              >
                Dismiss
              </button>
              <button
                onClick={retryCall}
                className="flex-1 py-2.5 px-4 rounded-xl bg-accent hover:bg-accent-hover text-white font-medium text-xs flex items-center justify-center gap-1.5 transition-colors shadow-sm"
              >
                <RefreshCw size={14} />
                <span>Retry Call</span>
              </button>
            </div>
          </div>
        </div>
      </>
    );
  }

  if (!activeCall) {
    return incomingModal;
  }

  const isVideo = activeCall.type === 'video';
  const isConnected = activeCall.status === 'connected';
  const isCalling = activeCall.status === 'calling';
  const isRinging = activeCall.status === 'ringing';
  const isConnecting = activeCall.status === 'connecting';
  const isBusy = activeCall.status === 'busy';
  const isRejected = activeCall.status === 'rejected';
  const isTimeout = activeCall.status === 'timeout';
  const isFailed = activeCall.status === 'failed';

  const getStatusText = () => {
    if (isConnected) return `WebRTC P2P • ${formatDuration(callDuration)}`;
    if (isCalling) return 'Calling...';
    if (isRinging) return 'Ringing...';
    if (isConnecting) return 'Connecting P2P...';
    if (isBusy) return 'Line Busy';
    if (isRejected) return 'Call Declined';
    if (isTimeout) return 'No Answer';
    if (isFailed) return 'Call Failed';
    return 'Connecting...';
  };

  return (
    <>
      {incomingModal}
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/90 backdrop-blur-xl p-2 sm:p-4 select-none animate-in fade-in duration-300">
        <div className="relative w-full max-w-4xl h-[92vh] sm:h-[85vh] max-h-[780px] bg-slate-900 rounded-3xl overflow-hidden border border-white/10 shadow-2xl flex flex-col justify-between">
          {/* Top Floating Status Bar */}
          <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-30 pointer-events-none">
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-black/50 backdrop-blur-md border border-white/10 text-white text-xs pointer-events-auto">
              <span
                className={`w-2 h-2 rounded-full ${
                  isConnected
                    ? 'bg-emerald-400 animate-pulse'
                    : isFailed || isRejected || isBusy
                    ? 'bg-rose-400'
                    : 'bg-amber-400 animate-ping'
                }`}
              />
              <span className="font-medium font-mono text-[11px] sm:text-xs">
                {getStatusText()}
              </span>
            </div>

            <div className="flex items-center gap-2 text-white/80 text-xs px-3 py-1.5 rounded-full bg-black/50 backdrop-blur-md border border-white/10 pointer-events-auto">
              <ShieldCheck size={14} className="text-emerald-400" />
              <span className="hidden sm:inline font-medium text-[11px]">E2E Encrypted</span>
            </div>
          </div>

          {/* Video / Voice Display Area */}
          <div className="relative flex-1 w-full h-full flex items-center justify-center overflow-hidden">
            {isVideo ? (
              <>
                {/* Remote Video Stream container */}
                <div className="w-full h-full relative flex items-center justify-center bg-slate-950">
                  <video
                    ref={remoteVideoRef}
                    autoPlay
                    playsInline
                    className={`w-full h-full object-cover transition-opacity duration-500 ${
                      isConnected && activeCall.remote_stream ? 'opacity-100' : 'opacity-0 absolute'
                    }`}
                  />

                  {/* Fallback avatar preview when waiting for remote video connection */}
                  {(!isConnected || !activeCall.remote_stream) && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-b from-slate-900 via-slate-900/90 to-slate-950 p-6">
                      <div className="relative mb-4">
                        <span className="absolute -inset-3 rounded-full bg-accent/20 animate-ping" />
                        <span className="absolute -inset-6 rounded-full bg-accent/10 animate-pulse" />
                        <Avatar
                          src={activeCall.peer.avatar_url}
                          name={activeCall.peer.display_name}
                          size="xl"
                          className="relative ring-4 ring-white/10 shadow-2xl"
                        />
                      </div>
                      <h3 className="font-display font-bold text-2xl text-white">
                        {activeCall.peer.display_name}
                      </h3>
                      <p className="text-xs text-accent font-mono mt-1">
                        @{activeCall.peer.username}
                      </p>
                      <p className="text-xs text-white/50 font-medium mt-3 animate-pulse">
                        {getStatusText()}
                      </p>
                    </div>
                  )}
                </div>

                {/* Local Picture-in-Picture Video */}
                <div className="absolute bottom-24 right-4 w-32 sm:w-48 aspect-video rounded-2xl overflow-hidden border-2 border-white/20 shadow-2xl bg-black z-30 transition-all">
                  <video
                    ref={localVideoRef}
                    autoPlay
                    playsInline
                    muted
                    className={`w-full h-full object-cover ${
                      activeCall.is_camera_off ? 'hidden' : ''
                    }`}
                  />
                  {activeCall.is_camera_off && (
                    <div className="w-full h-full flex items-center justify-center bg-slate-800 text-white/60 text-xs font-medium">
                      Camera Off
                    </div>
                  )}
                  <div className="absolute bottom-1 left-2 text-[10px] text-white/80 font-mono bg-black/60 px-1.5 rounded">
                    You
                  </div>
                </div>
              </>
            ) : (
              /* Voice Call Screen */
              <div className="flex flex-col items-center justify-center text-center p-6 sm:p-8 z-10">
                <div className="relative mb-6">
                  {/* Signal Pulse Waves */}
                  <span className="absolute -inset-4 rounded-full bg-accent/20 animate-ping" />
                  <span className="absolute -inset-8 rounded-full bg-accent/10 animate-pulse" />
                  <Avatar
                    src={activeCall.peer.avatar_url}
                    name={activeCall.peer.display_name}
                    size="xl"
                    className="relative shadow-2xl ring-4 ring-accent/30"
                  />
                </div>

                <h2 className="font-display font-bold text-2xl text-white">
                  {activeCall.peer.display_name}
                </h2>
                <p className="text-sm font-mono text-accent mt-1">
                  @{activeCall.peer.username}
                </p>
                <div className="mt-4 px-3 py-1 rounded-full bg-white/5 border border-white/10 inline-flex items-center gap-2">
                  <Volume2 size={14} className="text-accent animate-pulse" />
                  <span className="text-xs text-white/70 font-mono">
                    {getStatusText()}
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Bottom Control Bar */}
          <div className="p-4 sm:p-6 bg-gradient-to-t from-black/90 via-black/50 to-transparent flex items-center justify-center gap-4 z-30">
            {/* Mute Toggle */}
            <button
              onClick={toggleMute}
              className={`p-3.5 rounded-2xl backdrop-blur-md transition-all ${
                activeCall.is_muted
                  ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/30'
                  : 'bg-white/10 hover:bg-white/20 text-white'
              }`}
              title={activeCall.is_muted ? 'Unmute microphone' : 'Mute microphone'}
            >
              {activeCall.is_muted ? <MicOff size={20} /> : <Mic size={20} />}
            </button>

            {/* Camera Toggle for video */}
            {isVideo && (
              <button
                onClick={toggleCamera}
                className={`p-3.5 rounded-2xl backdrop-blur-md transition-all ${
                  activeCall.is_camera_off
                    ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/30'
                    : 'bg-white/10 hover:bg-white/20 text-white'
                }`}
                title={activeCall.is_camera_off ? 'Turn camera on' : 'Turn camera off'}
              >
                {activeCall.is_camera_off ? <VideoOff size={20} /> : <Video size={20} />}
              </button>
            )}

            {/* End Call Button */}
            <button
              onClick={endCall}
              className="p-4 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white shadow-xl shadow-rose-600/40 transition-transform active:scale-95"
              title="End call"
            >
              <PhoneOff size={24} />
            </button>
          </div>
        </div>
      </div>
    </>
  );
};
