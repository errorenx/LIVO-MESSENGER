import React from 'react';
import {
  Phone,
  Video,
  PhoneIncoming,
  PhoneOutgoing,
  PhoneMissed,
  Clock,
  ArrowUpRight,
  ArrowDownLeft,
} from 'lucide-react';
import { useChat } from '../../contexts/ChatContext';
import { useCall } from '../../contexts/CallContext';
import { useAuth } from '../../contexts/AuthContext';
import { Avatar } from '../common/Avatar';

export const CallHistoryView: React.FC = () => {
  const { callHistory } = useChat();
  const { startCall } = useCall();
  const { user } = useAuth();
  const [filter, setFilter] = React.useState<'all' | 'missed'>('all');

  const filteredCalls = callHistory.filter((c) => {
    if (filter === 'missed') {
      return c.status === 'missed';
    }
    return true;
  });

  const formatDuration = (secs?: number) => {
    if (!secs || secs === 0) return '0s';
    const mins = Math.floor(secs / 60);
    const s = secs % 60;
    if (mins === 0) return `${s}s`;
    return `${mins}m ${s}s`;
  };

  const formatDate = (dateStr: string) => {
    const d = new Date(dateStr);
    return d.toLocaleDateString(undefined, {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-sidebar/40 overflow-hidden select-none">
      {/* Header */}
      <div className="p-5 border-b border-border bg-card/60 backdrop-blur-md flex flex-col gap-3">
        <div>
          <h2 className="font-display font-bold text-2xl text-foreground tracking-tight">
            Call History
          </h2>
          <p className="text-xs text-muted mt-0.5">
            Recent WebRTC voice and video calls
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-2 pt-1 border-t border-border/40">
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1 rounded-xl text-xs font-semibold transition-all ${
              filter === 'all'
                ? 'bg-accent text-white shadow-xs'
                : 'text-muted hover:text-foreground hover:bg-input'
            }`}
          >
            All Calls ({callHistory.length})
          </button>
          <button
            onClick={() => setFilter('missed')}
            className={`px-3 py-1 rounded-xl text-xs font-semibold transition-all ${
              filter === 'missed'
                ? 'bg-rose-500 text-white shadow-xs'
                : 'text-muted hover:text-foreground hover:bg-input'
            }`}
          >
            Missed Calls ({callHistory.filter((c) => c.status === 'missed').length})
          </button>
        </div>
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto p-5 max-w-3xl mx-auto w-full">
        {filteredCalls.length === 0 ? (
          <div className="py-16 text-center text-muted text-xs">
            {filter === 'missed' ? 'No missed calls.' : 'No recent calls. Start a voice or video call with any contact!'}
          </div>
        ) : (
          <div className="flex flex-col gap-2.5">
            {filteredCalls.map((call) => {
              const isOutgoing = call.caller_id === user?.id;
              const peer = isOutgoing ? call.receiver_profile : call.caller_profile;
              const isVideo = call.type === 'video';

              return (
                <div
                  key={call.id}
                  className="bg-card p-3.5 rounded-2xl border border-border flex items-center justify-between shadow-xs hover:border-accent/40 transition-colors"
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <Avatar
                      src={peer?.avatar_url}
                      name={peer?.display_name || 'User'}
                      size="md"
                    />

                    <div className="min-w-0">
                      <h4 className="font-semibold text-sm text-foreground truncate">
                        {peer?.display_name}
                      </h4>
                      <div className="flex items-center gap-2 text-xs text-muted mt-0.5">
                        <span className="flex items-center gap-1 font-medium">
                          {isOutgoing ? (
                            <ArrowUpRight size={14} className="text-emerald-500" />
                          ) : call.status === 'missed' ? (
                            <ArrowDownLeft size={14} className="text-rose-500" />
                          ) : (
                            <ArrowDownLeft size={14} className="text-blue-500" />
                          )}
                          <span
                            className={
                              call.status === 'missed'
                                ? 'text-rose-500 font-semibold'
                                : 'capitalize'
                            }
                          >
                            {call.status}
                          </span>
                        </span>

                        <span>•</span>
                        <span className="font-mono text-[11px]">{formatDate(call.started_at)}</span>

                        {call.duration && call.duration > 0 ? (
                          <>
                            <span>•</span>
                            <span className="font-mono text-[11px] text-accent">
                              {formatDuration(call.duration)}
                            </span>
                          </>
                        ) : null}
                      </div>
                    </div>
                  </div>

                  {/* Call Back Actions */}
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => peer && startCall(peer, isVideo ? 'video' : 'voice')}
                      className="p-2.5 rounded-xl bg-input hover:bg-accent hover:text-white text-muted transition-colors"
                      title={isVideo ? 'Video Call Again' : 'Voice Call Again'}
                    >
                      {isVideo ? <Video size={17} /> : <Phone size={17} />}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
