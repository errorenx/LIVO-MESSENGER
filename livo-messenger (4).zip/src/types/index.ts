export type ThemeMode = 'white' | 'black' | 'rainbow';
export type AppearanceMode = 'light' | 'dark' | 'system' | 'white' | 'black' | 'rainbow';

export type AccentColor =
  | 'monochrome'
  | 'violet'
  | 'blue'
  | 'cyan'
  | 'emerald'
  | 'rose'
  | 'orange'
  | 'pink'
  | 'indigo';

export interface AccentColorDef {
  id: AccentColor;
  name: string;
  hex: string;
  rgb: string;
  hover: string;
}

export const ACCENT_COLORS: Record<AccentColor, AccentColorDef> = {
  monochrome: { id: 'monochrome', name: 'Black & White', hex: '#0f172a', rgb: '15, 23, 42', hover: '#1e293b' },
  violet: { id: 'violet', name: 'Violet', hex: '#8B5CF6', rgb: '139, 92, 246', hover: '#7C3AED' },
  blue: { id: 'blue', name: 'Blue', hex: '#3B82F6', rgb: '59, 130, 246', hover: '#2563EB' },
  cyan: { id: 'cyan', name: 'Cyan', hex: '#06B6D4', rgb: '6, 182, 212', hover: '#0891B2' },
  emerald: { id: 'emerald', name: 'Emerald', hex: '#10B981', rgb: '16, 185, 129', hover: '#059669' },
  rose: { id: 'rose', name: 'Rose', hex: '#F43F5E', rgb: '244, 63, 94', hover: '#E11D48' },
  orange: { id: 'orange', name: 'Orange', hex: '#F97316', rgb: '249, 115, 22', hover: '#EA580C' },
  pink: { id: 'pink', name: 'Pink', hex: '#EC4899', rgb: '236, 72, 153', hover: '#DB2777' },
  indigo: { id: 'indigo', name: 'Indigo', hex: '#6366F1', rgb: '99, 102, 241', hover: '#4F46E5' },
};

export interface UserProfile {
  id: string;
  username: string; // e.g. '@error123'
  display_name: string;
  avatar_url: string;
  bio?: string;
  phone?: string;
  status_message?: string;
  created_at: string;
  updated_at?: string;
  last_seen: string;
  online_status: 'online' | 'offline' | 'away';
  email?: string;
}

export interface Contact {
  id: string;
  user_id: string;
  contact_user_id: string;
  contact_profile: UserProfile;
  created_at: string;
}

export interface ContactRequest {
  id: string;
  sender_id: string;
  receiver_id: string;
  sender_profile: UserProfile;
  receiver_profile?: UserProfile;
  status: 'pending' | 'accepted' | 'rejected';
  created_at: string;
  updated_at?: string;
}

export type MessageType =
  | 'text'
  | 'image'
  | 'video'
  | 'document'
  | 'audio'
  | 'voice'
  | 'gif';

export type MessageDeliveryStatus = 'sending' | 'sent' | 'delivered' | 'seen' | 'failed';

export interface MessageMediaMeta {
  name?: string;
  size?: number; // bytes
  duration?: number; // seconds
  mime?: string;
  dimensions?: { width: number; height: number };
}

export interface Message {
  id: string;
  conversation_id: string;
  sender_id: string;
  sender_profile?: UserProfile;
  content: string;
  message_type: MessageType;
  media_url?: string;
  media_meta?: MessageMediaMeta;
  reply_to?: string;
  reply_message?: {
    id: string;
    sender_name: string;
    content: string;
    type: MessageType;
  };
  reactions?: Record<string, string[]>; // emoji -> [user_ids]
  status: MessageDeliveryStatus;
  is_pinned?: boolean;
  is_starred?: boolean;
  edited_at?: string;
  deleted_at?: string;
  created_at: string;
}

export interface ConversationMember {
  id: string;
  conversation_id: string;
  user_id: string;
  role: 'admin' | 'member';
  joined_at: string;
  profile?: UserProfile;
}

export interface Conversation {
  id: string;
  type: 'direct' | 'group' | 'channel';
  name?: string;
  avatar_url?: string;
  description?: string;
  created_by?: string;
  created_at: string;
  updated_at: string;
  members: ConversationMember[];
  last_message?: Message;
  unread_count?: number;
  is_pinned?: boolean;
  is_archived?: boolean;
  typing_users?: string[]; // user_ids currently typing
}

export interface StatusStory {
  id: string;
  user_id: string;
  author: UserProfile;
  content?: string;
  media_url?: string;
  media_type: 'text' | 'image' | 'video';
  bg_gradient?: string;
  created_at: string;
  expires_at: string;
  views_count: number;
  has_viewed: boolean;
  viewers?: { user: UserProfile; viewed_at: string }[];
}

export type CallType = 'voice' | 'video';
export type CallStatus = 'missed' | 'completed' | 'rejected' | 'busy' | 'ongoing';

export interface CallRecord {
  id: string;
  caller_id: string;
  caller_profile: UserProfile;
  receiver_id: string;
  receiver_profile: UserProfile;
  type: CallType;
  status: CallStatus;
  started_at: string;
  ended_at?: string;
  duration?: number; // seconds
}

export type ActiveCallStatus =
  | 'calling'
  | 'ringing'
  | 'connecting'
  | 'connected'
  | 'rejected'
  | 'busy'
  | 'timeout'
  | 'ended'
  | 'failed';

export interface ActiveCall {
  id: string;
  peer: UserProfile;
  type: CallType;
  direction: 'incoming' | 'outgoing';
  status: ActiveCallStatus;
  started_at?: number;
  is_muted: boolean;
  is_camera_off: boolean;
  local_stream?: MediaStream;
  remote_stream?: MediaStream;
  error_message?: string;
}

export interface NotificationItem {
  id: string;
  user_id: string;
  type: 'message' | 'contact_request' | 'contact_accepted' | 'group' | 'call';
  title: string;
  body: string;
  data?: Record<string, any>;
  read_at?: string;
  created_at: string;
}

export interface UserSettings {
  appearance_mode: AppearanceMode;
  accent_color: AccentColor;
  enter_to_send: boolean;
  chat_wallpaper: 'default' | 'mesh' | 'geometric' | 'minimal';
  media_auto_download: boolean;
  notifications_sound: boolean;
  notifications_desktop: boolean;
  privacy_last_seen: 'everyone' | 'contacts' | 'nobody';
  privacy_online: 'everyone' | 'contacts' | 'nobody';
  privacy_read_receipts: boolean;
  privacy_avatar: 'everyone' | 'contacts' | 'nobody';
  privacy_bio: 'everyone' | 'contacts' | 'nobody';
}

export interface BlockedUser {
  id: string;
  blocker_id: string;
  blocked_user_id: string;
  blocked_profile: UserProfile;
  created_at: string;
}

export type NavigationTab = 'chats' | 'contacts' | 'status' | 'calls' | 'notifications' | 'settings';
