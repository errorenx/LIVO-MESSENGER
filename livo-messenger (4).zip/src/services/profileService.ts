import { getSupabaseClient } from '../lib/supabase/client';
import { UserProfile } from '../types';

// In-memory cache for ultra-fast lookup and offline fallback
const profileMemoryCache = new Map<string, UserProfile>();

function getLocalCachedProfile(userId: string): UserProfile | null {
  if (!userId) return null;
  if (profileMemoryCache.has(userId)) {
    return profileMemoryCache.get(userId)!;
  }
  if (typeof window !== 'undefined') {
    try {
      const activeStr = localStorage.getItem('livo_active_user');
      if (activeStr) {
        const active = JSON.parse(activeStr) as UserProfile;
        if (active?.id === userId) {
          profileMemoryCache.set(userId, active);
          return active;
        }
      }
      const cachedStr = localStorage.getItem(`livo_profile_${userId}`);
      if (cachedStr) {
        const cached = JSON.parse(cachedStr) as UserProfile;
        if (cached?.id === userId) {
          profileMemoryCache.set(userId, cached);
          return cached;
        }
      }
    } catch {
      // Ignore JSON parse errors
    }
  }
  return null;
}

function saveLocalCachedProfile(profile: UserProfile): void {
  if (!profile?.id) return;
  profileMemoryCache.set(profile.id, profile);
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem(`livo_profile_${profile.id}`, JSON.stringify(profile));
      const activeStr = localStorage.getItem('livo_active_user');
      if (activeStr) {
        const active = JSON.parse(activeStr);
        if (active?.id === profile.id) {
          localStorage.setItem('livo_active_user', JSON.stringify(profile));
        }
      }
    } catch {
      // Storage full or unavailable
    }
  }
}

function isFetchOrNetworkError(err: any): boolean {
  if (!err) return false;
  const msg = (err?.message || err?.details || String(err)).toLowerCase();
  return (
    msg.includes('failed to fetch') ||
    msg.includes('networkerror') ||
    msg.includes('network request failed') ||
    msg.includes('load failed') ||
    msg.includes('abort') ||
    msg.includes('timeout')
  );
}

export async function getProfile(userId: string): Promise<UserProfile | null> {
  if (!userId) return null;

  // Check local cache first
  const cached = getLocalCachedProfile(userId);

  const supabase = getSupabaseClient();
  if (!supabase) {
    return cached;
  }

  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();

    if (error) {
      if (isFetchOrNetworkError(error)) {
        // Network or fetch issue: fall back gracefully to cache without triggering error logs
        console.warn('Offline or network issue fetching profile for', userId, error.message || error);
        return cached;
      }
      console.warn('Notice fetching profile for', userId, error.message || error);
      return cached;
    }

    if (data) {
      const profile = data as UserProfile;
      saveLocalCachedProfile(profile);
      return profile;
    }

    return cached;
  } catch (err: any) {
    if (isFetchOrNetworkError(err)) {
      console.warn('Network unavailable while fetching profile:', err?.message || err);
    } else {
      console.warn('Notice in getProfile:', err?.message || err);
    }
    return cached;
  }
}

export async function ensureUserProfile(
  authUser: { id: string; email?: string; phone?: string; user_metadata?: Record<string, any> },
  overrides?: { displayName?: string; username?: string; avatarUrl?: string; phone?: string }
): Promise<UserProfile> {
  // 1. Check if profile already exists in cache or Supabase
  const existing = (await getProfile(authUser.id)) || getLocalCachedProfile(authUser.id);
  if (existing) {
    const phoneToSync = overrides?.phone || authUser.user_metadata?.phone || authUser.phone;
    if (phoneToSync && !existing.phone) {
      existing.phone = phoneToSync;
      saveLocalCachedProfile(existing);
      const supabase = getSupabaseClient();
      if (supabase) {
        Promise.resolve(supabase.from('profiles').update({ phone: phoneToSync }).eq('id', existing.id)).catch(() => {});
      }
    }
    saveLocalCachedProfile(existing);
    return existing;
  }

  // 2. Generate a clean, unique LIVO username
  let candidateUsername = overrides?.username;
  if (!candidateUsername) {
    const metaUsername = authUser.user_metadata?.user_name || authUser.user_metadata?.preferred_username;
    if (metaUsername) {
      candidateUsername = metaUsername.startsWith('@') ? metaUsername : `@${metaUsername}`;
    } else if (authUser.email) {
      const emailPrefix = authUser.email.split('@')[0].replace(/[^a-zA-Z0-9_]/g, '');
      candidateUsername = `@${emailPrefix}`;
    } else {
      candidateUsername = `@user_${authUser.id.substring(0, 6)}`;
    }
  }

  // Clean formatting
  candidateUsername = candidateUsername.toLowerCase();
  if (!candidateUsername.startsWith('@')) candidateUsername = `@${candidateUsername}`;

  const displayName =
    overrides?.displayName ||
    authUser.user_metadata?.full_name ||
    authUser.user_metadata?.name ||
    authUser.email?.split('@')[0] ||
    'LIVO User';

  const avatarUrl =
    overrides?.avatarUrl ||
    authUser.user_metadata?.avatar_url ||
    `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(candidateUsername)}`;

  const phone = overrides?.phone || authUser.user_metadata?.phone || authUser.phone || undefined;

  const newProfile: UserProfile = {
    id: authUser.id,
    username: candidateUsername,
    display_name: displayName,
    avatar_url: avatarUrl,
    bio: 'Available on LIVO',
    phone,
    created_at: new Date().toISOString(),
    last_seen: new Date().toISOString(),
    online_status: 'online',
    email: authUser.email,
  };

  // Cache immediately locally so the app is 100% functional even offline
  saveLocalCachedProfile(newProfile);

  const supabase = getSupabaseClient();
  if (supabase) {
    // Attempt remote upsert in background without blocking or crashing
    (async () => {
      try {
        await supabase.from('profiles').upsert(
          {
            id: newProfile.id,
            username: newProfile.username,
            display_name: newProfile.display_name,
            avatar_url: newProfile.avatar_url,
            bio: newProfile.bio,
            phone: newProfile.phone,
            last_seen: newProfile.last_seen,
            online_status: newProfile.online_status,
            updated_at: new Date().toISOString(),
          },
          { onConflict: 'id', ignoreDuplicates: true }
        );

        await supabase.from('user_settings').upsert(
          {
            user_id: newProfile.id,
            appearance_mode: 'system',
            accent_color: 'violet',
            enter_to_send: true,
            media_auto_download: true,
            notifications_sound: true,
            notifications_desktop: true,
            privacy_last_seen: 'everyone',
            privacy_online: 'everyone',
            privacy_read_receipts: true,
            privacy_avatar: 'everyone',
            privacy_bio: 'everyone',
          },
          { onConflict: 'user_id', ignoreDuplicates: true }
        );
      } catch (err: any) {
        console.warn('Notice saving profile remotely:', err?.message || err);
      }
    })();
  }

  return newProfile;
}

export async function updateProfile(
  userId: string,
  updates: Partial<UserProfile>
): Promise<{ profile?: UserProfile; error?: string }> {
  const current = (await getProfile(userId)) || getLocalCachedProfile(userId);
  const updated: UserProfile = {
    ...(current || {
      id: userId,
      username: `@user_${userId.substring(0, 6)}`,
      display_name: 'LIVO User',
      avatar_url: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(userId)}`,
      bio: 'Available on LIVO',
      created_at: new Date().toISOString(),
      last_seen: new Date().toISOString(),
      online_status: 'online',
    }),
    ...updates,
  };

  saveLocalCachedProfile(updated);

  const supabase = getSupabaseClient();
  if (!supabase) {
    return { profile: updated };
  }

  try {
    const payload: Record<string, any> = {
      updated_at: new Date().toISOString(),
    };

    if (updates.display_name !== undefined) payload.display_name = updates.display_name.trim();
    if (updates.bio !== undefined) payload.bio = updates.bio;
    if (updates.avatar_url !== undefined) payload.avatar_url = updates.avatar_url;
    if (updates.phone !== undefined) payload.phone = updates.phone;

    if (updates.username !== undefined) {
      let u = updates.username.trim().toLowerCase();
      if (!u.startsWith('@')) u = `@${u}`;
      payload.username = u;
      updated.username = u;
    }

    const { data, error } = await supabase
      .from('profiles')
      .update(payload)
      .eq('id', userId)
      .select()
      .maybeSingle();

    if (error) {
      if (isFetchOrNetworkError(error)) {
        console.warn('Network issue updating profile remotely:', error.message || error);
        return { profile: updated };
      }
      return { error: error.message };
    }

    const finalProfile = (data as UserProfile) || updated;
    saveLocalCachedProfile(finalProfile);
    return { profile: finalProfile };
  } catch (err: any) {
    if (isFetchOrNetworkError(err)) {
      console.warn('Network issue in updateProfile:', err?.message || err);
      return { profile: updated };
    }
    return { error: err.message || 'Failed to update profile.' };
  }
}

export async function searchUsers(query: string, currentUserId: string): Promise<UserProfile[]> {
  const cleanTerm = query.trim().replace(/^@/, '').toLowerCase();
  if (!cleanTerm) return [];

  // Always collect from local memory cache first
  const localResults: UserProfile[] = [];
  profileMemoryCache.forEach((prof) => {
    if (prof.id !== currentUserId) {
      const matchName = prof.display_name?.toLowerCase().includes(cleanTerm);
      const matchUser = prof.username?.toLowerCase().includes(cleanTerm);
      if (matchName || matchUser) {
        localResults.push(prof);
      }
    }
  });

  const supabase = getSupabaseClient();
  if (!supabase) return localResults;

  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .or(`username.ilike.%${cleanTerm}%,display_name.ilike.%${cleanTerm}%`)
      .neq('id', currentUserId)
      .limit(20);

    if (error) {
      if (isFetchOrNetworkError(error)) {
        console.warn('Network issue searching users:', error.message || error);
      } else {
        console.warn('Notice searching users:', error.message || error);
      }
      return localResults;
    }

    const remoteProfiles = (data || []) as UserProfile[];
    remoteProfiles.forEach((p) => saveLocalCachedProfile(p));
    return remoteProfiles.length > 0 ? remoteProfiles : localResults;
  } catch (err: any) {
    console.warn('Exception in searchUsers:', err?.message || err);
    return localResults;
  }
}

export async function updatePresence(
  userId: string,
  status: 'online' | 'offline' | 'away'
): Promise<void> {
  if (!userId) return;

  const current = getLocalCachedProfile(userId);
  if (current) {
    current.online_status = status;
    current.last_seen = new Date().toISOString();
    saveLocalCachedProfile(current);
  }

  const supabase = getSupabaseClient();
  if (!supabase) return;

  try {
    await supabase
      .from('profiles')
      .update({
        online_status: status,
        last_seen: new Date().toISOString(),
      })
      .eq('id', userId);
  } catch (err) {
    // Silent presence failure
  }
}

