import { getSupabaseClient } from '../lib/supabase/client';
import { UserSettings } from '../types';

export const DEFAULT_USER_SETTINGS: UserSettings = {
  appearance_mode: 'system',
  accent_color: 'violet',
  enter_to_send: true,
  chat_wallpaper: 'default',
  media_auto_download: true,
  notifications_sound: true,
  notifications_desktop: true,
  privacy_last_seen: 'everyone',
  privacy_online: 'everyone',
  privacy_read_receipts: true,
  privacy_avatar: 'everyone',
  privacy_bio: 'everyone',
};

export async function getUserSettings(userId: string): Promise<UserSettings> {
  const supabase = getSupabaseClient();
  if (!supabase || !userId) return DEFAULT_USER_SETTINGS;

  try {
    const { data, error } = await supabase
      .from('user_settings')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();

    if (error || !data) {
      return DEFAULT_USER_SETTINGS;
    }

    return {
      appearance_mode: data.appearance_mode || 'dark',
      accent_color: data.accent_color || 'violet',
      enter_to_send: data.enter_to_send !== undefined ? data.enter_to_send : true,
      chat_wallpaper: data.chat_wallpaper || 'default',
      media_auto_download: data.media_auto_download !== undefined ? data.media_auto_download : true,
      notifications_sound: data.notifications_sound !== undefined ? data.notifications_sound : true,
      notifications_desktop: data.notifications_desktop !== undefined ? data.notifications_desktop : true,
      privacy_last_seen: data.privacy_last_seen || 'everyone',
      privacy_online: data.privacy_online || 'everyone',
      privacy_read_receipts: data.privacy_read_receipts !== undefined ? data.privacy_read_receipts : true,
      privacy_avatar: data.privacy_avatar || 'everyone',
      privacy_bio: data.privacy_bio || 'everyone',
    };
  } catch (err: any) {
    console.warn('Notice fetching user settings:', err?.message || err);
    return DEFAULT_USER_SETTINGS;
  }
}

export async function updateUserSettings(
  userId: string,
  updates: Partial<UserSettings>
): Promise<{ success?: boolean; error?: string }> {
  const supabase = getSupabaseClient();
  if (!supabase || !userId) return { error: 'Not connected' };

  try {
    const { error } = await supabase
      .from('user_settings')
      .upsert({
        user_id: userId,
        ...updates,
        updated_at: new Date().toISOString(),
      });

    if (error) return { error: error.message };
    return { success: true };
  } catch (err: any) {
    return { error: err.message };
  }
}
