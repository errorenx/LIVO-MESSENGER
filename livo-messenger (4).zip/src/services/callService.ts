import { getSupabaseClient } from '../lib/supabase/client';
import { CallRecord, CallType, CallStatus, UserProfile } from '../types';

export async function getCallHistory(userId: string): Promise<CallRecord[]> {
  const supabase = getSupabaseClient();
  if (!supabase || !userId) return [];

  try {
    const { data, error } = await supabase
      .from('calls')
      .select('*')
      .or(`caller_id.eq.${userId},receiver_id.eq.${userId}`)
      .order('started_at', { ascending: false })
      .limit(50);

    if (error || !data) {
      console.warn('Notice fetching call history:', error?.message || error);
      return [];
    }

    if (data.length === 0) return [];

    const userIds = Array.from(
      new Set(data.flatMap((c) => [c.caller_id, c.receiver_id]))
    );

    const { data: profiles } = await supabase
      .from('profiles')
      .select('*')
      .in('id', userIds);

    const profileMap = new Map((profiles || []).map((p) => [p.id, p]));

    return data.map((c) => ({
      id: c.id,
      caller_id: c.caller_id,
      caller_profile: (profileMap.get(c.caller_id) || {
        id: c.caller_id,
        username: '@caller',
        display_name: 'Caller',
        avatar_url: '',
        created_at: c.started_at,
        last_seen: new Date().toISOString(),
        online_status: 'offline',
      }) as UserProfile,
      receiver_id: c.receiver_id,
      receiver_profile: (profileMap.get(c.receiver_id) || {
        id: c.receiver_id,
        username: '@receiver',
        display_name: 'Receiver',
        avatar_url: '',
        created_at: c.started_at,
        last_seen: new Date().toISOString(),
        online_status: 'offline',
      }) as UserProfile,
      type: c.type as CallType,
      status: c.status as CallStatus,
      started_at: c.started_at,
      ended_at: c.ended_at,
      duration: c.duration || 0,
    }));
  } catch (err: any) {
    console.warn('Notice fetching call history:', err?.message || err);
    return [];
  }
}

export async function recordCall(
  callerId: string,
  receiverId: string,
  type: CallType,
  status: CallStatus,
  duration: number = 0
): Promise<CallRecord | null> {
  const supabase = getSupabaseClient();
  if (!supabase) return null;

  try {
    const { data, error } = await supabase
      .from('calls')
      .insert({
        caller_id: callerId,
        receiver_id: receiverId,
        type,
        status,
        started_at: new Date().toISOString(),
        ended_at: new Date().toISOString(),
        duration,
      })
      .select()
      .single();

    if (error || !data) {
      console.warn('Could not record call:', error?.message);
      return null;
    }

    const { data: profiles } = await supabase
      .from('profiles')
      .select('*')
      .in('id', [callerId, receiverId]);

    const profileMap = new Map((profiles || []).map((p) => [p.id, p]));

    return {
      id: data.id,
      caller_id: data.caller_id,
      caller_profile: profileMap.get(callerId) as UserProfile,
      receiver_id: data.receiver_id,
      receiver_profile: profileMap.get(receiverId) as UserProfile,
      type: data.type,
      status: data.status,
      started_at: data.started_at,
      ended_at: data.ended_at,
      duration: data.duration,
    };
  } catch (err: any) {
    console.warn('Notice recording call:', err?.message || err);
    return null;
  }
}
