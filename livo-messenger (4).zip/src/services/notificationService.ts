import { getSupabaseClient } from '../lib/supabase/client';
import { NotificationItem } from '../types';

export async function getNotifications(userId: string): Promise<NotificationItem[]> {
  const supabase = getSupabaseClient();
  if (!supabase || !userId) return [];

  try {
    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(50);

    if (error || !data) {
      console.warn('Notice fetching notifications:', error?.message || error);
      return [];
    }

    return data as NotificationItem[];
  } catch (err: any) {
    console.warn('Notice fetching notifications:', err?.message || err);
    return [];
  }
}

export async function markNotificationRead(
  notificationId: string,
  userId: string
): Promise<void> {
  const supabase = getSupabaseClient();
  if (!supabase) return;

  try {
    await supabase
      .from('notifications')
      .update({ read_at: new Date().toISOString() })
      .eq('id', notificationId)
      .eq('user_id', userId);
  } catch (err) {
    console.warn('Could not mark notification read:', err);
  }
}

export async function markAllNotificationsRead(userId: string): Promise<void> {
  const supabase = getSupabaseClient();
  if (!supabase || !userId) return;

  try {
    await supabase
      .from('notifications')
      .update({ read_at: new Date().toISOString() })
      .eq('user_id', userId)
      .is('read_at', null);
  } catch (err) {
    console.warn('Could not mark all notifications read:', err);
  }
}

export async function deleteNotification(
  notificationId: string,
  userId: string
): Promise<void> {
  const supabase = getSupabaseClient();
  if (!supabase) return;

  try {
    await supabase
      .from('notifications')
      .delete()
      .eq('id', notificationId)
      .eq('user_id', userId);
  } catch (err) {
    console.warn('Could not delete notification:', err);
  }
}
