import { getSupabaseClient } from '../lib/supabase/client';

export interface UploadResult {
  url: string;
  name: string;
  size: number;
  mime: string;
  error?: string;
}

export type StorageBucket =
  | 'avatars'
  | 'chat-media'
  | 'documents'
  | 'voice-messages'
  | 'status-media';

export async function uploadFile(
  file: File | Blob,
  bucket: StorageBucket,
  fileNamePrefix: string = 'file',
  onProgress?: (percent: number) => void
): Promise<UploadResult> {
  const supabase = getSupabaseClient();
  const mime = file.type || 'application/octet-stream';
  const size = file.size;

  // Generate unique file path
  const ext = file instanceof File && file.name.includes('.')
    ? file.name.split('.').pop()
    : mime.split('/')[1] || 'bin';

  const cleanName = `${fileNamePrefix}_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.${ext}`;
  const path = `${cleanName}`;

  if (onProgress) onProgress(25);

  if (supabase) {
    try {
      const { data, error } = await supabase.storage
        .from(bucket)
        .upload(path, file, {
          cacheControl: '3600',
          upsert: true,
        });

      if (onProgress) onProgress(75);

      if (!error && data) {
        const { data: publicUrlData } = supabase.storage
          .from(bucket)
          .getPublicUrl(data.path);

        if (onProgress) onProgress(100);
        return {
          url: publicUrlData.publicUrl,
          name: file instanceof File ? file.name : cleanName,
          size,
          mime,
        };
      } else {
        console.warn(`Storage upload to ${bucket} error:`, error?.message);
      }
    } catch (err: any) {
      console.warn(`Storage upload exception in ${bucket}:`, err?.message);
    }
  }

  // Resilient fallback: Convert to Data URL
  return new Promise<UploadResult>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (onProgress) onProgress(100);
      resolve({
        url: reader.result as string,
        name: file instanceof File ? file.name : cleanName,
        size,
        mime,
      });
    };
    reader.onerror = () => {
      reject(new Error('Failed to read file data'));
    };
    reader.readAsDataURL(file);
  });
}

export async function uploadAvatar(file: File): Promise<string> {
  const res = await uploadFile(file, 'avatars', 'avatar');
  return res.url;
}

export async function uploadVoiceRecording(blob: Blob): Promise<string> {
  const res = await uploadFile(blob, 'voice-messages', 'voice_note');
  return res.url;
}

export async function uploadStatusMedia(file: File): Promise<string> {
  const res = await uploadFile(file, 'status-media', 'status');
  return res.url;
}
