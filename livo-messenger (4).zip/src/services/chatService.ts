import { getSupabaseClient } from '../lib/supabase/client';
import {
  Conversation,
  Message,
  MessageType,
  UserProfile,
  ConversationMember,
} from '../types';

// Helper to retrieve user profile from memory or localStorage
function getCachedUserProfile(userId: string): UserProfile | null {
  if (typeof window === 'undefined') return null;
  try {
    const activeStr = localStorage.getItem('livo_active_user');
    if (activeStr) {
      const active = JSON.parse(activeStr);
      if (active.id === userId) return active;
    }
    const profStr = localStorage.getItem(`livo_profile_${userId}`);
    if (profStr) return JSON.parse(profStr);
  } catch (e) {}
  return null;
}

// Guarantees that the user's personal self-chat "[User Name] (YOU)" exists and is ready
export function ensureSelfConversation(user: UserProfile): Conversation {
  const selfId = `self_${user.id}`;
  const selfName = `${user.display_name} (YOU)`;

  let storedConvs: Conversation[] = [];
  if (typeof window !== 'undefined') {
    try {
      const saved = localStorage.getItem(`livo_conversations_${user.id}`);
      if (saved) storedConvs = JSON.parse(saved);
    } catch (e) {}
  }

  let selfConv = storedConvs.find((c) => c.id === selfId || c.name?.endsWith('(YOU)'));

  if (!selfConv) {
    const welcomeMsg: Message = {
      id: `msg_welcome_${selfId}`,
      conversation_id: selfId,
      sender_id: user.id,
      sender_profile: user,
      content: `Welcome to your personal chat, ${user.display_name}! 📝 This is your own private chat (YOU) to save notes, voice memos, photos, files, and reminders. Everything here is private and visible only to you.`,
      message_type: 'text',
      status: 'seen',
      created_at: new Date().toISOString(),
    };

    selfConv = {
      id: selfId,
      type: 'direct',
      name: selfName,
      avatar_url: user.avatar_url,
      description: 'Personal notes & saved messages • Visible only to you',
      created_by: user.id,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      is_pinned: true,
      members: [
        {
          id: `mem_${selfId}`,
          conversation_id: selfId,
          user_id: user.id,
          role: 'admin',
          joined_at: new Date().toISOString(),
          profile: user,
        },
      ],
      last_message: welcomeMsg,
      unread_count: 0,
    };

    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem(`livo_msgs_${selfId}`, JSON.stringify([welcomeMsg]));
      } catch (e) {}
    }
  } else {
    // Keep name and avatar up to date with user's current profile
    selfConv.name = selfName;
    selfConv.avatar_url = user.avatar_url;
    selfConv.is_pinned = true;
    if (selfConv.members && selfConv.members.length > 0) {
      selfConv.members[0].profile = user;
    }
  }

  // Update in localStorage
  if (typeof window !== 'undefined') {
    try {
      const filtered = storedConvs.filter((c) => c.id !== selfId && !c.name?.endsWith('(YOU)'));
      localStorage.setItem(`livo_conversations_${user.id}`, JSON.stringify([selfConv, ...filtered]));
    } catch (e) {}
  }

  // Also sync with Supabase if connected
  const supabase = getSupabaseClient();
  if (supabase) {
    Promise.resolve(
      supabase
        .from('conversations')
        .upsert({
          id: selfId,
          type: 'direct',
          name: selfName,
          avatar_url: user.avatar_url,
          description: 'Personal notes & saved messages',
          created_by: user.id,
          updated_at: new Date().toISOString(),
        })
    )
      .then(() => {
        return supabase.from('conversation_members').upsert({
          id: `mem_${selfId}`,
          conversation_id: selfId,
          user_id: user.id,
          role: 'admin',
        });
      })
      .catch(() => {});
  }

  return selfConv;
}

export async function getConversations(
  userId: string,
  activeUser?: UserProfile
): Promise<Conversation[]> {
  const profile = activeUser || getCachedUserProfile(userId);
  let selfConv: Conversation | null = null;
  if (profile) {
    selfConv = ensureSelfConversation(profile);
  }

  // Read local conversations
  let localConvs: Conversation[] = [];
  if (typeof window !== 'undefined') {
    try {
      const raw = localStorage.getItem(`livo_conversations_${userId}`);
      if (raw) localConvs = JSON.parse(raw);
    } catch (e) {}
  }

  let remoteConvs: Conversation[] = [];
  const supabase = getSupabaseClient();

  if (supabase && userId) {
    try {
      // 1. Get user's conversation memberships
      const { data: memberships, error: memErr } = await supabase
        .from('conversation_members')
        .select('conversation_id, role, joined_at')
        .eq('user_id', userId);

      if (!memErr && memberships && memberships.length > 0) {
        const convIds = memberships.map((m) => m.conversation_id);

        // 2. Fetch conversation records
        const { data: convData } = await supabase
          .from('conversations')
          .select('*')
          .in('id', convIds)
          .order('updated_at', { ascending: false });

        if (convData) {
          // 3. Fetch all members for these conversations
          const { data: allMembers } = await supabase
            .from('conversation_members')
            .select('id, conversation_id, user_id, role, joined_at')
            .in('conversation_id', convIds);

          const memberUserIds = Array.from(new Set((allMembers || []).map((m) => m.user_id)));

          // 4. Fetch profiles for all members
          const { data: memberProfiles } = await supabase
            .from('profiles')
            .select('*')
            .in('id', memberUserIds);

          const profileMap = new Map((memberProfiles || []).map((p) => [p.id, p]));

          // 5. Fetch last message for each conversation
          const { data: recentMessages } = await supabase
            .from('messages')
            .select('*')
            .in('conversation_id', convIds)
            .order('created_at', { ascending: false });

          const lastMessageMap = new Map<string, Message>();
          const unreadCountMap = new Map<string, number>();

          if (recentMessages) {
            for (const msg of recentMessages) {
              if (!lastMessageMap.has(msg.conversation_id)) {
                lastMessageMap.set(msg.conversation_id, {
                  ...msg,
                  sender_profile: profileMap.get(msg.sender_id),
                });
              }
              if (msg.sender_id !== userId && msg.status !== 'seen') {
                unreadCountMap.set(
                  msg.conversation_id,
                  (unreadCountMap.get(msg.conversation_id) || 0) + 1
                );
              }
            }
          }

          // Build the conversations list
          remoteConvs = convData.map((conv) => {
            const convMembers: ConversationMember[] = (allMembers || [])
              .filter((m) => m.conversation_id === conv.id)
              .map((m) => ({
                id: m.id,
                conversation_id: m.conversation_id,
                user_id: m.user_id,
                role: m.role,
                joined_at: m.joined_at,
                profile: profileMap.get(m.user_id),
              }));

            let displayName = conv.name;
            let displayAvatar = conv.avatar_url;

            if (conv.type === 'direct' && !conv.id.startsWith('self_')) {
              const peer = convMembers.find((m) => m.user_id !== userId);
              if (peer?.profile) {
                displayName = peer.profile.display_name;
                displayAvatar = peer.profile.avatar_url;
              }
            }

            return {
              id: conv.id,
              type: conv.type,
              name: displayName,
              avatar_url: displayAvatar,
              description: conv.description,
              created_by: conv.created_by,
              created_at: conv.created_at,
              updated_at: conv.updated_at,
              members: convMembers,
              last_message: lastMessageMap.get(conv.id),
              unread_count: unreadCountMap.get(conv.id) || 0,
            };
          });
        }
      }
    } catch (err: any) {
      console.warn('Notice fetching conversations:', err?.message || err);
    }
  }

  // Merge map: local + remote
  const map = new Map<string, Conversation>();
  for (const c of localConvs) map.set(c.id, c);
  for (const c of remoteConvs) map.set(c.id, c);

  if (selfConv) {
    map.set(selfConv.id, selfConv);
  }

  const merged = Array.from(map.values());

  // Guarantee: Self conversation is ALWAYS the very first conversation
  merged.sort((a, b) => {
    const isASelf = a.id.startsWith('self_') || a.name?.includes('(YOU)');
    const isBSelf = b.id.startsWith('self_') || b.name?.includes('(YOU)');
    if (isASelf && !isBSelf) return -1;
    if (!isASelf && isBSelf) return 1;
    if (a.is_pinned && !b.is_pinned) return -1;
    if (!a.is_pinned && b.is_pinned) return 1;
    return new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime();
  });

  return merged;
}

export async function getConversationMessages(
  conversationId: string,
  limit: number = 100
): Promise<Message[]> {
  let localMsgs: Message[] = [];
  if (typeof window !== 'undefined') {
    try {
      const raw = localStorage.getItem(`livo_msgs_${conversationId}`);
      if (raw) localMsgs = JSON.parse(raw);
    } catch (e) {}
  }

  // If this is a self chat and no messages exist yet, generate the initial welcome note
  if (conversationId.startsWith('self_') && localMsgs.length === 0) {
    const userId = conversationId.replace('self_', '');
    const profile = getCachedUserProfile(userId);
    const welcomeMsg: Message = {
      id: `msg_welcome_${conversationId}`,
      conversation_id: conversationId,
      sender_id: userId,
      sender_profile: profile || undefined,
      content: `Welcome to your personal chat, ${profile?.display_name || 'there'}! 📝 This is your private space (YOU) to save notes, voice memos, photos, files, and reminders. Everything here is private and visible only to you.`,
      message_type: 'text',
      status: 'seen',
      created_at: new Date().toISOString(),
    };
    localMsgs = [welcomeMsg];
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem(`livo_msgs_${conversationId}`, JSON.stringify(localMsgs));
      } catch (e) {}
    }
  }

  const supabase = getSupabaseClient();
  if (!supabase || !conversationId) return localMsgs;

  try {
    const { data, error } = await supabase
      .from('messages')
      .select('*')
      .eq('conversation_id', conversationId)
      .order('created_at', { ascending: true })
      .limit(limit);

    if (error || !data || data.length === 0) {
      return localMsgs;
    }

    // Fetch sender profiles
    const senderIds = Array.from(new Set(data.map((m) => m.sender_id)));
    const { data: profiles } = await supabase
      .from('profiles')
      .select('*')
      .in('id', senderIds);

    const profileMap = new Map((profiles || []).map((p) => [p.id, p]));

    // Fetch reactions for these messages
    const messageIds = data.map((m) => m.id);
    const { data: reactionsData } = await supabase
      .from('message_reactions')
      .select('message_id, user_id, reaction')
      .in('message_id', messageIds);

    const reactionMap = new Map<string, Record<string, string[]>>();
    if (reactionsData) {
      for (const r of reactionsData) {
        if (!reactionMap.has(r.message_id)) {
          reactionMap.set(r.message_id, {});
        }
        const obj = reactionMap.get(r.message_id)!;
        if (!obj[r.reaction]) obj[r.reaction] = [];
        if (!obj[r.reaction].includes(r.user_id)) {
          obj[r.reaction].push(r.user_id);
        }
      }
    }

    const remoteHydrated: Message[] = data.map((m) => ({
      ...m,
      sender_profile: profileMap.get(m.sender_id),
      reactions: reactionMap.get(m.id) || {},
    }));

    // Merge local and remote
    const map = new Map<string, Message>();
    for (const m of localMsgs) map.set(m.id, m);
    for (const m of remoteHydrated) map.set(m.id, m);

    return Array.from(map.values()).sort(
      (a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
    );
  } catch (err: any) {
    console.warn('Notice fetching messages:', err?.message || err);
    return localMsgs;
  }
}

export async function createDirectConversation(
  currentUserId: string,
  peerUserId: string,
  peerProfile?: UserProfile
): Promise<{ conversation?: Conversation; error?: string }> {
  // If user is starting direct chat with themselves, return self conversation
  if (currentUserId === peerUserId) {
    const user = getCachedUserProfile(currentUserId) || peerProfile;
    if (user) {
      const selfConv = ensureSelfConversation(user);
      return { conversation: selfConv };
    }
  }

  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      // 1. Check if direct conversation already exists between these 2 users
      const { data: userMemberships } = await supabase
        .from('conversation_members')
        .select('conversation_id')
        .eq('user_id', currentUserId);

      if (userMemberships && userMemberships.length > 0) {
        const convIds = userMemberships.map((m) => m.conversation_id);
        const { data: peerMemberships } = await supabase
          .from('conversation_members')
          .select('conversation_id')
          .eq('user_id', peerUserId)
          .in('conversation_id', convIds);

        if (peerMemberships && peerMemberships.length > 0) {
          const sharedIds = peerMemberships.map((m) => m.conversation_id);
          const { data: existingDirect } = await supabase
            .from('conversations')
            .select('*')
            .eq('type', 'direct')
            .in('id', sharedIds)
            .maybeSingle();

          if (existingDirect) {
            const fullConvs = await getConversations(currentUserId);
            const found = fullConvs.find((c) => c.id === existingDirect.id);
            if (found) return { conversation: found };
          }
        }
      }

      // 2. Create new direct conversation
      const { data: newConv, error: convErr } = await supabase
        .from('conversations')
        .insert({
          type: 'direct',
          created_by: currentUserId,
        })
        .select()
        .single();

      if (!convErr && newConv) {
        await supabase.from('conversation_members').insert([
          { conversation_id: newConv.id, user_id: currentUserId, role: 'admin' },
          { conversation_id: newConv.id, user_id: peerUserId, role: 'member' },
        ]);

        const allConvs = await getConversations(currentUserId);
        const hydrated = allConvs.find((c) => c.id === newConv.id);
        if (hydrated) return { conversation: hydrated };
      }
    } catch (err: any) {
      console.warn('Notice creating direct conversation via cloud:', err?.message || err);
    }
  }

  // Local fallback creation
  const localId = `conv_dir_${currentUserId}_${peerUserId}`;
  const currentUser = getCachedUserProfile(currentUserId);
  const targetPeer = peerProfile || getCachedUserProfile(peerUserId);

  const localConv: Conversation = {
    id: localId,
    type: 'direct',
    name: targetPeer?.display_name || 'Direct Chat',
    avatar_url: targetPeer?.avatar_url || '',
    created_by: currentUserId,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    members: [
      {
        id: `mem_${localId}_1`,
        conversation_id: localId,
        user_id: currentUserId,
        role: 'admin',
        joined_at: new Date().toISOString(),
        profile: currentUser || undefined,
      },
      {
        id: `mem_${localId}_2`,
        conversation_id: localId,
        user_id: peerUserId,
        role: 'member',
        joined_at: new Date().toISOString(),
        profile: targetPeer || undefined,
      },
    ],
  };

  if (typeof window !== 'undefined') {
    try {
      const saved = localStorage.getItem(`livo_conversations_${currentUserId}`);
      const list: Conversation[] = saved ? JSON.parse(saved) : [];
      const updated = [localConv, ...list.filter((c) => c.id !== localId)];
      localStorage.setItem(`livo_conversations_${currentUserId}`, JSON.stringify(updated));
    } catch (e) {}
  }

  return { conversation: localConv };
}

export async function createGroupConversation(
  creatorId: string,
  name: string,
  description: string,
  avatarUrl: string,
  memberIds: string[]
): Promise<{ conversation?: Conversation; error?: string }> {
  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      const { data: newConv, error: convErr } = await supabase
        .from('conversations')
        .insert({
          type: 'group',
          name: name.trim(),
          description: description.trim(),
          avatar_url: avatarUrl || '',
          created_by: creatorId,
        })
        .select()
        .single();

      if (!convErr && newConv) {
        // Add creator as admin
        const memberRows = [
          { conversation_id: newConv.id, user_id: creatorId, role: 'admin' },
          ...memberIds
            .filter((id) => id !== creatorId)
            .map((id) => ({
              conversation_id: newConv.id,
              user_id: id,
              role: 'member',
            })),
        ];

        await supabase.from('conversation_members').insert(memberRows);

        const allConvs = await getConversations(creatorId);
        const hydrated = allConvs.find((c) => c.id === newConv.id);
        return { conversation: hydrated || (newConv as any) };
      }
    } catch (err: any) {
      console.warn('Notice creating group via cloud:', err?.message || err);
    }
  }

  // Local fallback
  const localId = `grp_${Date.now()}`;
  const creator = getCachedUserProfile(creatorId);
  const localGroup: Conversation = {
    id: localId,
    type: 'group',
    name: name.trim(),
    description: description.trim(),
    avatar_url: avatarUrl || '',
    created_by: creatorId,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    members: [
      {
        id: `mem_${localId}_admin`,
        conversation_id: localId,
        user_id: creatorId,
        role: 'admin',
        joined_at: new Date().toISOString(),
        profile: creator || undefined,
      },
    ],
  };

  if (typeof window !== 'undefined') {
    try {
      const saved = localStorage.getItem(`livo_conversations_${creatorId}`);
      const list: Conversation[] = saved ? JSON.parse(saved) : [];
      localStorage.setItem(`livo_conversations_${creatorId}`, JSON.stringify([localGroup, ...list]));
    } catch (e) {}
  }

  return { conversation: localGroup };
}

export async function updateGroup(
  conversationId: string,
  updates: { name?: string; description?: string; avatar_url?: string }
): Promise<{ success?: boolean; error?: string }> {
  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      await supabase
        .from('conversations')
        .update({
          ...updates,
          updated_at: new Date().toISOString(),
        })
        .eq('id', conversationId);
    } catch (err) {}
  }
  return { success: true };
}

export async function leaveGroup(
  conversationId: string,
  userId: string
): Promise<{ success?: boolean; error?: string }> {
  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      await supabase
        .from('conversation_members')
        .delete()
        .eq('conversation_id', conversationId)
        .eq('user_id', userId);
    } catch (err) {}
  }
  return { success: true };
}

export async function addGroupMembers(
  conversationId: string,
  userIds: string[]
): Promise<{ success?: boolean; error?: string }> {
  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      const rows = userIds.map((uid) => ({
        conversation_id: conversationId,
        user_id: uid,
        role: 'member',
      }));
      await supabase.from('conversation_members').upsert(rows);
    } catch (err) {}
  }
  return { success: true };
}

export async function removeGroupMember(
  conversationId: string,
  memberUserId: string
): Promise<{ success?: boolean; error?: string }> {
  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      await supabase
        .from('conversation_members')
        .delete()
        .eq('conversation_id', conversationId)
        .eq('user_id', memberUserId);
    } catch (err) {}
  }
  return { success: true };
}

export async function sendMessage(
  conversationId: string,
  senderId: string,
  content: string,
  messageType: MessageType = 'text',
  mediaUrl?: string,
  mediaMeta?: any,
  replyTo?: string
): Promise<{ message?: Message; error?: string }> {
  const profile = getCachedUserProfile(senderId);
  const isSelf = conversationId.startsWith('self_') || conversationId.includes('self');

  const newMsg: Message = {
    id: 'msg_' + Date.now() + '_' + Math.random().toString(36).substring(2, 9),
    conversation_id: conversationId,
    sender_id: senderId,
    sender_profile: profile || undefined,
    content: content.trim(),
    message_type: messageType,
    media_url: mediaUrl || undefined,
    media_meta: mediaMeta || {},
    reply_to: replyTo || undefined,
    status: isSelf ? 'seen' : 'sent',
    created_at: new Date().toISOString(),
  };

  // Always persist locally
  if (typeof window !== 'undefined') {
    try {
      const raw = localStorage.getItem(`livo_msgs_${conversationId}`);
      const list: Message[] = raw ? JSON.parse(raw) : [];
      list.push(newMsg);
      localStorage.setItem(`livo_msgs_${conversationId}`, JSON.stringify(list));

      // Update conversation's last message in localStorage
      const convsRaw = localStorage.getItem(`livo_conversations_${senderId}`);
      if (convsRaw) {
        const convs: Conversation[] = JSON.parse(convsRaw);
        const target = convs.find((c) => c.id === conversationId);
        if (target) {
          target.last_message = newMsg;
          target.updated_at = newMsg.created_at;
          localStorage.setItem(`livo_conversations_${senderId}`, JSON.stringify(convs));
        }
      }
    } catch (e) {}
  }

  // Also sync with Supabase if connected
  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      await supabase.from('messages').insert({
        id: newMsg.id,
        conversation_id: conversationId,
        sender_id: senderId,
        content: content.trim(),
        message_type: messageType,
        media_url: mediaUrl || null,
        media_meta: mediaMeta || {},
        reply_to: replyTo || null,
        status: newMsg.status,
      });

      await supabase
        .from('conversations')
        .update({ updated_at: new Date().toISOString() })
        .eq('id', conversationId);
    } catch (err: any) {
      console.warn('Notice sending message to cloud:', err?.message || err);
    }
  }

  return { message: newMsg };
}

export async function editMessage(
  messageId: string,
  senderId: string,
  newContent: string
): Promise<{ success?: boolean; error?: string }> {
  // Update local storage
  if (typeof window !== 'undefined') {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith('livo_msgs_')) {
        try {
          const raw = localStorage.getItem(key);
          if (raw && raw.includes(messageId)) {
            const list: Message[] = JSON.parse(raw);
            const item = list.find((m) => m.id === messageId);
            if (item) {
              item.content = newContent.trim();
              item.edited_at = new Date().toISOString();
              localStorage.setItem(key, JSON.stringify(list));
              break;
            }
          }
        } catch (e) {}
      }
    }
  }

  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      await supabase
        .from('messages')
        .update({
          content: newContent.trim(),
          edited_at: new Date().toISOString(),
        })
        .eq('id', messageId)
        .eq('sender_id', senderId);
    } catch (err) {}
  }

  return { success: true };
}

export async function deleteMessage(
  messageId: string,
  senderId: string
): Promise<{ success?: boolean; error?: string }> {
  // Update local storage
  if (typeof window !== 'undefined') {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith('livo_msgs_')) {
        try {
          const raw = localStorage.getItem(key);
          if (raw && raw.includes(messageId)) {
            const list: Message[] = JSON.parse(raw);
            const filtered = list.filter((m) => m.id !== messageId);
            localStorage.setItem(key, JSON.stringify(filtered));
            break;
          }
        } catch (e) {}
      }
    }
  }

  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      await supabase
        .from('messages')
        .delete()
        .eq('id', messageId)
        .eq('sender_id', senderId);
    } catch (err) {}
  }

  return { success: true };
}

export async function reactToMessage(
  messageId: string,
  userId: string,
  reaction: string
): Promise<{ success?: boolean; error?: string }> {
  // Update local storage
  if (typeof window !== 'undefined') {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith('livo_msgs_')) {
        try {
          const raw = localStorage.getItem(key);
          if (raw && raw.includes(messageId)) {
            const list: Message[] = JSON.parse(raw);
            const item = list.find((m) => m.id === messageId);
            if (item) {
              if (!item.reactions) item.reactions = {};
              if (!item.reactions[reaction]) item.reactions[reaction] = [];
              const idx = item.reactions[reaction].indexOf(userId);
              if (idx >= 0) {
                item.reactions[reaction].splice(idx, 1);
                if (item.reactions[reaction].length === 0) delete item.reactions[reaction];
              } else {
                item.reactions[reaction].push(userId);
              }
              localStorage.setItem(key, JSON.stringify(list));
              break;
            }
          }
        } catch (e) {}
      }
    }
  }

  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      const { data: existing } = await supabase
        .from('message_reactions')
        .select('id')
        .eq('message_id', messageId)
        .eq('user_id', userId)
        .eq('reaction', reaction)
        .maybeSingle();

      if (existing) {
        await supabase.from('message_reactions').delete().eq('id', existing.id);
      } else {
        await supabase.from('message_reactions').insert({
          message_id: messageId,
          user_id: userId,
          reaction,
        });
      }
    } catch (err) {}
  }

  return { success: true };
}

export async function togglePinMessage(
  messageId: string,
  currentPinned: boolean
): Promise<{ success?: boolean; error?: string }> {
  if (typeof window !== 'undefined') {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith('livo_msgs_')) {
        try {
          const raw = localStorage.getItem(key);
          if (raw && raw.includes(messageId)) {
            const list: Message[] = JSON.parse(raw);
            const item = list.find((m) => m.id === messageId);
            if (item) {
              item.is_pinned = !currentPinned;
              localStorage.setItem(key, JSON.stringify(list));
              break;
            }
          }
        } catch (e) {}
      }
    }
  }

  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      await supabase
        .from('messages')
        .update({ is_pinned: !currentPinned })
        .eq('id', messageId);
    } catch (err) {}
  }

  return { success: true };
}

export async function toggleStarMessage(
  messageId: string,
  currentStarred: boolean
): Promise<{ success?: boolean; error?: string }> {
  if (typeof window !== 'undefined') {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith('livo_msgs_')) {
        try {
          const raw = localStorage.getItem(key);
          if (raw && raw.includes(messageId)) {
            const list: Message[] = JSON.parse(raw);
            const item = list.find((m) => m.id === messageId);
            if (item) {
              item.is_starred = !currentStarred;
              localStorage.setItem(key, JSON.stringify(list));
              break;
            }
          }
        } catch (e) {}
      }
    }
  }

  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      await supabase
        .from('messages')
        .update({ is_starred: !currentStarred })
        .eq('id', messageId);
    } catch (err) {}
  }

  return { success: true };
}

export async function markConversationSeen(
  conversationId: string,
  userId: string
): Promise<void> {
  const supabase = getSupabaseClient();
  if (!supabase || !conversationId) return;

  try {
    await supabase
      .from('messages')
      .update({ status: 'seen' })
      .eq('conversation_id', conversationId)
      .neq('sender_id', userId)
      .neq('status', 'seen');
  } catch (err) {
    console.warn('Could not mark conversation seen:', err);
  }
}

