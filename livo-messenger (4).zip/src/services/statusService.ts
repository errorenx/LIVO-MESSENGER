import { getSupabaseClient } from '../lib/supabase/client';
import { StatusStory, UserProfile } from '../types';

export async function getActiveStatuses(currentUserId: string): Promise<StatusStory[]> {
  const supabase = getSupabaseClient();
  if (!supabase) return [];

  try {
    const now = new Date().toISOString();

    const { data: statusesData, error } = await supabase
      .from('statuses')
      .select('*')
      .gt('expires_at', now)
      .order('created_at', { ascending: false });

    if (error || !statusesData) {
      console.warn('Notice fetching statuses:', error?.message || error);
      return [];
    }

    if (statusesData.length === 0) return [];

    // Fetch author profiles
    const authorIds = Array.from(new Set(statusesData.map((s) => s.user_id)));
    const { data: profiles } = await supabase
      .from('profiles')
      .select('*')
      .in('id', authorIds);

    const profileMap = new Map((profiles || []).map((p) => [p.id, p]));

    // Fetch status views for these statuses
    const statusIds = statusesData.map((s) => s.id);
    const { data: viewsData } = await supabase
      .from('status_views')
      .select('status_id, viewer_id, viewed_at')
      .in('status_id', statusIds);

    const viewerUserIds = Array.from(new Set((viewsData || []).map((v) => v.viewer_id)));
    const { data: viewerProfiles } = viewerUserIds.length > 0
      ? await supabase.from('profiles').select('*').in('id', viewerUserIds)
      : { data: [] };

    const viewerProfileMap = new Map((viewerProfiles || []).map((p) => [p.id, p]));

    const viewsMap = new Map<string, { user: UserProfile; viewed_at: string }[]>();
    const hasViewedMap = new Map<string, boolean>();

    if (viewsData) {
      for (const v of viewsData) {
        if (!viewsMap.has(v.status_id)) {
          viewsMap.set(v.status_id, []);
        }
        const prof = viewerProfileMap.get(v.viewer_id);
        if (prof) {
          viewsMap.get(v.status_id)!.push({
            user: prof,
            viewed_at: v.viewed_at,
          });
        }
        if (v.viewer_id === currentUserId) {
          hasViewedMap.set(v.status_id, true);
        }
      }
    }

    return statusesData.map((s) => ({
      id: s.id,
      user_id: s.user_id,
      author: (profileMap.get(s.user_id) || {
        id: s.user_id,
        username: '@user',
        display_name: 'LIVO User',
        avatar_url: '',
        created_at: s.created_at,
        last_seen: new Date().toISOString(),
        online_status: 'offline',
      }) as UserProfile,
      content: s.content,
      media_url: s.media_url,
      media_type: s.media_type || 'text',
      bg_gradient: s.bg_gradient || 'from-violet-600 to-indigo-700',
      created_at: s.created_at,
      expires_at: s.expires_at,
      views_count: (viewsMap.get(s.id) || []).length,
      has_viewed: hasViewedMap.get(s.id) || false,
      viewers: viewsMap.get(s.id) || [],
    }));
  } catch (err: any) {
    console.warn('Notice fetching active statuses:', err?.message || err);
    return [];
  }
}

export async function createStatus(
  userId: string,
  content?: string,
  mediaType: 'text' | 'image' | 'video' = 'text',
  mediaUrl?: string,
  bgGradient?: string
): Promise<{ status?: StatusStory; error?: string }> {
  const supabase = getSupabaseClient();
  if (!supabase) return { error: 'Supabase not connected' };

  try {
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();

    const { data, error } = await supabase
      .from('statuses')
      .insert({
        user_id: userId,
        content: content || null,
        media_url: mediaUrl || null,
        media_type: mediaType,
        bg_gradient: bgGradient || 'from-violet-600 to-indigo-700',
        expires_at: expiresAt,
      })
      .select()
      .single();

    if (error || !data) return { error: error?.message || 'Failed to create status' };

    const { data: prof } = await supabase.from('profiles').select('*').eq('id', userId).single();

    return {
      status: {
        id: data.id,
        user_id: data.user_id,
        author: prof as UserProfile,
        content: data.content,
        media_url: data.media_url,
        media_type: data.media_type,
        bg_gradient: data.bg_gradient,
        created_at: data.created_at,
        expires_at: data.expires_at,
        views_count: 0,
        has_viewed: false,
        viewers: [],
      },
    };
  } catch (err: any) {
    return { error: err.message };
  }
}

export async function deleteStatus(
  statusId: string,
  userId: string
): Promise<{ success?: boolean; error?: string }> {
  const supabase = getSupabaseClient();
  if (!supabase) return { error: 'Supabase not connected' };

  try {
    const { error } = await supabase
      .from('statuses')
      .delete()
      .eq('id', statusId)
      .eq('user_id', userId);

    if (error) return { error: error.message };
    return { success: true };
  } catch (err: any) {
    return { error: err.message };
  }
}

export async function recordStatusView(
  statusId: string,
  viewerId: string
): Promise<void> {
  const supabase = getSupabaseClient();
  if (!supabase || !statusId || !viewerId) return;

  try {
    await supabase.from('status_views').upsert(
      {
        status_id: statusId,
        viewer_id: viewerId,
        viewed_at: new Date().toISOString(),
      },
      { onConflict: 'status_id,viewer_id' }
    );
  } catch (err) {
    console.warn('Could not record status view:', err);
  }
}
