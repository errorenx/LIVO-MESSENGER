import { getSupabaseClient } from '../../lib/supabase/client';
import { isSupabaseConfigured } from '../../lib/supabase/config';
import { UserProfile, CallType } from '../../types';
import { SignalingPayload, SignalingMessageType } from './types';

export type SignalingListener = (payload: SignalingPayload) => void;

class CallManager {
  private currentUserId: string | null = null;
  private currentUserProfile: UserProfile | null = null;
  private channel: any = null;
  private broadcastChannel: BroadcastChannel | null = null;
  private listeners: Set<SignalingListener> = new Set();
  private callTimeoutTimer: any = null;
  private blockedUserIds: Set<string> = new Set();

  constructor() {
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
      try {
        this.broadcastChannel = new BroadcastChannel('livo-webrtc-signaling');
        this.broadcastChannel.onmessage = (event) => {
          this.handleIncomingPayload(event.data);
        };
      } catch (err) {
        console.warn('BroadcastChannel not available:', err);
      }
    }
  }

  public setBlockedUsers(blockedIds: string[]): void {
    this.blockedUserIds = new Set(blockedIds);
  }

  /**
   * Initialize user signaling listener on their private user room
   */
  public init(user: UserProfile): void {
    if (this.currentUserId === user.id && this.channel) {
      return; // Already initialized
    }

    this.cleanup();
    this.currentUserId = user.id;
    this.currentUserProfile = user;

    // Connect Supabase Realtime channel if configured
    if (isSupabaseConfigured()) {
      const supabase = getSupabaseClient();
      if (supabase) {
        // Private room for this user
        const channelName = `call_signal_${user.id}`;
        this.channel = supabase.channel(channelName, {
          config: {
            broadcast: { self: false },
          },
        });

        this.channel
          .on('broadcast', { event: 'signal' }, ({ payload }: { payload: SignalingPayload }) => {
            this.handleIncomingPayload(payload);
          })
          .subscribe((status: string) => {
            if (status === 'SUBSCRIBED') {
              // Successfully listening on Realtime channel
            }
          });
      }
    }
  }

  public addListener(listener: SignalingListener): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private handleIncomingPayload(payload: SignalingPayload): void {
    if (!payload || !this.currentUserId) return;

    // Only process if destined for this user
    if (payload.receiverId !== this.currentUserId) return;

    // Security check: Ignore if caller is blocked
    if (this.blockedUserIds.has(payload.callerId)) {
      if (payload.type === 'call:offer') {
        this.sendSignal({
          type: 'call:reject',
          callId: payload.callId,
          callerId: this.currentUserId,
          receiverId: payload.callerId,
          callType: payload.callType,
          reason: 'blocked',
          timestamp: Date.now(),
        });
      }
      return;
    }

    // Notify all active listeners
    this.listeners.forEach((listener) => {
      try {
        listener(payload);
      } catch (err) {
        console.error('Error in signaling listener:', err);
      }
    });
  }

  /**
   * Send a signaling message to a peer (via Supabase Realtime + local BroadcastChannel)
   */
  public async sendSignal(payload: SignalingPayload): Promise<void> {
    // 1. Broadcast via local BroadcastChannel (for instant multi-tab local testing)
    if (this.broadcastChannel) {
      try {
        this.broadcastChannel.postMessage(payload);
      } catch (err) {
        console.warn('BroadcastChannel send error:', err);
      }
    }

    // 2. Broadcast via Supabase Realtime to target peer's channel
    if (isSupabaseConfigured()) {
      const supabase = getSupabaseClient();
      if (supabase) {
        try {
          const peerChannelName = `call_signal_${payload.receiverId}`;
          const peerChannel = supabase.channel(peerChannelName);
          await peerChannel.send({
            type: 'broadcast',
            event: 'signal',
            payload,
          });
        } catch (err) {
          console.warn('Supabase Realtime signal send failed:', err);
        }
      }
    }
  }

  /**
   * Send Call Offer to receiver
   */
  public async sendOffer(
    callId: string,
    receiverId: string,
    callType: CallType,
    sdp: RTCSessionDescriptionInit
  ): Promise<void> {
    if (!this.currentUserId) return;

    const payload: SignalingPayload = {
      type: 'call:offer',
      callId,
      callerId: this.currentUserId,
      callerProfile: this.currentUserProfile || undefined,
      receiverId,
      callType,
      sdp,
      timestamp: Date.now(),
    };

    await this.sendSignal(payload);
  }

  /**
   * Send Call Answer to caller
   */
  public async sendAnswer(
    callId: string,
    callerId: string,
    callType: CallType,
    sdp: RTCSessionDescriptionInit
  ): Promise<void> {
    if (!this.currentUserId) return;

    const payload: SignalingPayload = {
      type: 'call:answer',
      callId,
      callerId: callerId,
      receiverId: callerId,
      callType,
      sdp,
      timestamp: Date.now(),
    };

    await this.sendSignal(payload);
  }

  /**
   * Send ICE candidate to peer
   */
  public async sendIceCandidate(
    callId: string,
    targetUserId: string,
    callType: CallType,
    candidate: RTCIceCandidate
  ): Promise<void> {
    if (!this.currentUserId) return;

    const payload: SignalingPayload = {
      type: 'call:ice-candidate',
      callId,
      callerId: this.currentUserId,
      receiverId: targetUserId,
      callType,
      candidate: candidate.toJSON(),
      timestamp: Date.now(),
    };

    await this.sendSignal(payload);
  }

  /**
   * Send Ringing confirmation to caller
   */
  public async sendRinging(callId: string, callerId: string, callType: CallType): Promise<void> {
    if (!this.currentUserId) return;
    await this.sendSignal({
      type: 'call:ringing',
      callId,
      callerId,
      receiverId: callerId,
      callType,
      timestamp: Date.now(),
    });
  }

  /**
   * Send Rejection to caller
   */
  public async sendReject(
    callId: string,
    targetUserId: string,
    callType: CallType,
    reason: string = 'declined'
  ): Promise<void> {
    if (!this.currentUserId) return;
    await this.sendSignal({
      type: 'call:reject',
      callId,
      callerId: this.currentUserId,
      receiverId: targetUserId,
      callType,
      reason,
      timestamp: Date.now(),
    });
  }

  /**
   * Send Call Ended signal to peer
   */
  public async sendEnd(callId: string, targetUserId: string, callType: CallType): Promise<void> {
    if (!this.currentUserId) return;
    await this.sendSignal({
      type: 'call:end',
      callId,
      callerId: this.currentUserId,
      receiverId: targetUserId,
      callType,
      timestamp: Date.now(),
    });
  }

  /**
   * Send Busy signal
   */
  public async sendBusy(callId: string, callerId: string, callType: CallType): Promise<void> {
    if (!this.currentUserId) return;
    await this.sendSignal({
      type: 'call:busy',
      callId,
      callerId,
      receiverId: callerId,
      callType,
      reason: 'busy',
      timestamp: Date.now(),
    });
  }

  /**
   * Start timeout timer for outgoing call
   */
  public startOutgoingCallTimeout(onTimeout: () => void, timeoutMs = 35000): void {
    this.clearCallTimeout();
    this.callTimeoutTimer = setTimeout(() => {
      onTimeout();
    }, timeoutMs);
  }

  public clearCallTimeout(): void {
    if (this.callTimeoutTimer) {
      clearTimeout(this.callTimeoutTimer);
      this.callTimeoutTimer = null;
    }
  }

  /**
   * Cleanup channels and timers
   */
  public cleanup(): void {
    this.clearCallTimeout();
    if (this.channel && isSupabaseConfigured()) {
      const supabase = getSupabaseClient();
      if (supabase) {
        try {
          supabase.removeChannel(this.channel);
        } catch {}
      }
      this.channel = null;
    }
  }
}

export const callManager = new CallManager();
