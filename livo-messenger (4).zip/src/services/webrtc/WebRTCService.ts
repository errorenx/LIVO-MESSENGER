import { getRTCConfiguration } from './iceConfig';
import { CallType } from '../../types';

export interface WebRTCCallbacks {
  onRemoteStream: (stream: MediaStream) => void;
  onLocalStream: (stream: MediaStream) => void;
  onIceCandidate: (candidate: RTCIceCandidate) => void;
  onConnectionStateChange: (state: RTCPeerConnectionState) => void;
  onIceConnectionStateChange: (state: RTCIceConnectionState) => void;
  onError: (error: Error) => void;
}

export class WebRTCService {
  private peerConnection: RTCPeerConnection | null = null;
  private localStream: MediaStream | null = null;
  private remoteStream: MediaStream | null = null;
  private callbacks: WebRTCCallbacks;
  private pendingCandidates: RTCIceCandidateInit[] = [];
  private isRemoteDescriptionSet = false;

  constructor(callbacks: WebRTCCallbacks) {
    this.callbacks = callbacks;
  }

  /**
   * Acquire local media stream (Microphone only for voice, Camera + Microphone for video)
   */
  public async getLocalMedia(type: CallType): Promise<MediaStream> {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      throw new Error('MediaDevices API not supported in this browser environment.');
    }

    const constraints: MediaStreamConstraints = {
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
      },
      video:
        type === 'video'
          ? {
              width: { ideal: 1280, max: 1920 },
              height: { ideal: 720, max: 1080 },
              facingMode: 'user',
              frameRate: { ideal: 30, max: 60 },
            }
          : false,
    };

    try {
      this.localStream = await navigator.mediaDevices.getUserMedia(constraints);
      this.callbacks.onLocalStream(this.localStream);
      return this.localStream;
    } catch (err: any) {
      const isVideo = type === 'video';
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        throw new Error(
          isVideo
            ? 'Camera and microphone access was denied. Please allow permissions in browser settings.'
            : 'Microphone access was denied. Please allow microphone permission in browser settings.'
        );
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        throw new Error(
          isVideo
            ? 'Camera or microphone device not found on this system.'
            : 'Microphone device not found on this system.'
        );
      } else if (err.name === 'NotReadableError') {
        throw new Error('Camera or microphone is currently in use by another application.');
      }
      throw err;
    }
  }

  /**
   * Initialize RTCPeerConnection and attach event listeners
   */
  public initPeerConnection(): RTCPeerConnection {
    if (this.peerConnection) {
      this.close();
    }

    const config = getRTCConfiguration();
    const pc = new RTCPeerConnection(config);
    this.peerConnection = pc;
    this.isRemoteDescriptionSet = false;
    this.pendingCandidates = [];

    // Create remote media stream container
    this.remoteStream = new MediaStream();

    // Track remote tracks
    pc.ontrack = (event) => {
      if (event.streams && event.streams[0]) {
        this.remoteStream = event.streams[0];
        this.callbacks.onRemoteStream(this.remoteStream);
      } else if (event.track) {
        this.remoteStream?.addTrack(event.track);
        if (this.remoteStream) {
          this.callbacks.onRemoteStream(this.remoteStream);
        }
      }
    };

    // ICE Candidates
    pc.onicecandidate = (event) => {
      if (event.candidate) {
        this.callbacks.onIceCandidate(event.candidate);
      }
    };

    // Connection state
    pc.onconnectionstatechange = () => {
      if (this.peerConnection) {
        this.callbacks.onConnectionStateChange(this.peerConnection.connectionState);
      }
    };

    // ICE connection state
    pc.oniceconnectionstatechange = () => {
      if (this.peerConnection) {
        this.callbacks.onIceConnectionStateChange(this.peerConnection.iceConnectionState);
      }
    };

    // Add local tracks if stream already acquired
    if (this.localStream) {
      this.localStream.getTracks().forEach((track) => {
        pc.addTrack(track, this.localStream!);
      });
    }

    return pc;
  }

  /**
   * Create SDP Offer
   */
  public async createOffer(): Promise<RTCSessionDescriptionInit> {
    if (!this.peerConnection) {
      this.initPeerConnection();
    }
    const pc = this.peerConnection!;

    const offer = await pc.createOffer({
      offerToReceiveAudio: true,
      offerToReceiveVideo: true,
    });

    await pc.setLocalDescription(offer);
    return offer;
  }

  /**
   * Handle incoming offer and create SDP Answer
   */
  public async handleOfferAndCreateAnswer(
    offer: RTCSessionDescriptionInit
  ): Promise<RTCSessionDescriptionInit> {
    if (!this.peerConnection) {
      this.initPeerConnection();
    }
    const pc = this.peerConnection!;

    await pc.setRemoteDescription(new RTCSessionDescription(offer));
    this.isRemoteDescriptionSet = true;
    await this.flushPendingIceCandidates();

    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    return answer;
  }

  /**
   * Handle incoming SDP Answer from peer
   */
  public async handleAnswer(answer: RTCSessionDescriptionInit): Promise<void> {
    if (!this.peerConnection) return;
    await this.peerConnection.setRemoteDescription(new RTCSessionDescription(answer));
    this.isRemoteDescriptionSet = true;
    await this.flushPendingIceCandidates();
  }

  /**
   * Add incoming ICE candidate or queue if remote description isn't set yet
   */
  public async addIceCandidate(candidateInit: RTCIceCandidateInit): Promise<void> {
    if (!this.peerConnection || !this.isRemoteDescriptionSet) {
      this.pendingCandidates.push(candidateInit);
      return;
    }

    try {
      await this.peerConnection.addIceCandidate(new RTCIceCandidate(candidateInit));
    } catch (err) {
      console.warn('Failed to add ICE candidate:', err);
    }
  }

  private async flushPendingIceCandidates(): Promise<void> {
    if (!this.peerConnection || !this.isRemoteDescriptionSet) return;
    for (const cand of this.pendingCandidates) {
      try {
        await this.peerConnection.addIceCandidate(new RTCIceCandidate(cand));
      } catch (err) {
        console.warn('Failed to add queued ICE candidate:', err);
      }
    }
    this.pendingCandidates = [];
  }

  /**
   * Toggle local audio mute
   */
  public setAudioMuted(muted: boolean): boolean {
    if (!this.localStream) return muted;
    this.localStream.getAudioTracks().forEach((track) => {
      track.enabled = !muted;
    });
    return muted;
  }

  /**
   * Toggle local video camera on/off
   */
  public setVideoEnabled(enabled: boolean): boolean {
    if (!this.localStream) return enabled;
    this.localStream.getVideoTracks().forEach((track) => {
      track.enabled = enabled;
    });
    return enabled;
  }

  /**
   * Complete cleanup: Stop all tracks, close peer connection, clear references
   */
  public close(): void {
    // 1. Stop local media tracks to ensure camera light turns off
    if (this.localStream) {
      this.localStream.getTracks().forEach((track) => {
        try {
          track.stop();
        } catch {}
      });
      this.localStream = null;
    }

    // 2. Stop remote tracks
    if (this.remoteStream) {
      this.remoteStream.getTracks().forEach((track) => {
        try {
          track.stop();
        } catch {}
      });
      this.remoteStream = null;
    }

    // 3. Close RTCPeerConnection
    if (this.peerConnection) {
      try {
        this.peerConnection.ontrack = null;
        this.peerConnection.onicecandidate = null;
        this.peerConnection.onconnectionstatechange = null;
        this.peerConnection.oniceconnectionstatechange = null;
        this.peerConnection.close();
      } catch {}
      this.peerConnection = null;
    }

    this.pendingCandidates = [];
    this.isRemoteDescriptionSet = false;
  }
}
