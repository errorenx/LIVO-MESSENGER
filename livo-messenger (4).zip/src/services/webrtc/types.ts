import { CallType, UserProfile } from '../../types';

export type CallDirection = 'incoming' | 'outgoing';

export type WebRTCCallStatus =
  | 'idle'
  | 'calling'       // Caller initiated, waiting for receiver
  | 'ringing'       // Receiver is being notified
  | 'connecting'    // Offer/Answer exchanged, ICE connecting
  | 'connected'     // WebRTC P2P media flowing
  | 'rejected'      // Receiver declined
  | 'busy'          // Receiver already on another call
  | 'timeout'       // No answer within timeout window
  | 'ended'         // Normal termination
  | 'failed';       // Network or permission failure

export interface ICEServerConfig {
  urls: string | string[];
  username?: string;
  credential?: string;
}

export type SignalingMessageType =
  | 'call:offer'
  | 'call:answer'
  | 'call:ice-candidate'
  | 'call:ringing'
  | 'call:accept'
  | 'call:reject'
  | 'call:end'
  | 'call:busy'
  | 'call:timeout';

export interface SignalingPayload {
  type: SignalingMessageType;
  callId: string;
  callerId: string;
  callerProfile?: UserProfile;
  receiverId: string;
  callType: CallType;
  sdp?: RTCSessionDescriptionInit;
  candidate?: RTCIceCandidateInit;
  reason?: string;
  timestamp: number;
}

export interface ActiveCallState {
  id: string;
  peer: UserProfile;
  type: CallType;
  direction: CallDirection;
  status: WebRTCCallStatus;
  startedAt?: number;
  isMuted: boolean;
  isCameraOff: boolean;
  localStream: MediaStream | null;
  remoteStream: MediaStream | null;
  errorMessage?: string;
  connectionQuality?: 'good' | 'fair' | 'poor';
}
