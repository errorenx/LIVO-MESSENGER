import { ICEServerConfig } from './types';

/**
 * Default STUN servers (fast, globally distributed, public)
 */
const DEFAULT_STUN_SERVERS: RTCIceServer[] = [
  { urls: 'stun:stun.l.google.com:19302' },
  { urls: 'stun:stun1.l.google.com:19302' },
  { urls: 'stun:stun2.l.google.com:19302' },
  { urls: 'stun:stun.cloudflare.com:3478' },
];

/**
 * Resolves ICE servers from runtime environment, localStorage override, or default public STUNs.
 * Modular and provider-independent (supports self-hosted coturn, Twilio, Metered, LiveKit, etc.)
 */
export function getIceServers(): RTCIceServer[] {
  // 1. Check for custom JSON configuration in environment
  const metaEnv = (import.meta as unknown as { env?: Record<string, string> }).env || {};
  const customIceEnv = metaEnv.VITE_ICE_SERVERS;

  if (customIceEnv) {
    try {
      const parsed = JSON.parse(customIceEnv);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed as RTCIceServer[];
      }
    } catch {
      // If it's a comma-separated string of urls
      const urls = customIceEnv.split(',').map((u) => u.trim()).filter(Boolean);
      if (urls.length > 0) {
        return [{ urls }];
      }
    }
  }

  // 2. Check for explicit TURN credentials in environment
  const turnUrl = metaEnv.VITE_TURN_URL;
  const turnUser = metaEnv.VITE_TURN_USERNAME;
  const turnCred = metaEnv.VITE_TURN_CREDENTIAL;

  const servers: RTCIceServer[] = [...DEFAULT_STUN_SERVERS];

  if (turnUrl) {
    const turnEntry: RTCIceServer = {
      urls: turnUrl.includes(',') ? turnUrl.split(',').map((u) => u.trim()) : turnUrl.trim(),
    };
    if (turnUser) turnEntry.username = turnUser;
    if (turnCred) turnEntry.credential = turnCred;
    servers.push(turnEntry);
  }

  return servers;
}

/**
 * Standard WebRTC RTCConfiguration options
 */
export function getRTCConfiguration(): RTCConfiguration {
  return {
    iceServers: getIceServers(),
    iceCandidatePoolSize: 10,
    bundlePolicy: 'max-bundle',
    rtcpMuxPolicy: 'require',
  };
}
