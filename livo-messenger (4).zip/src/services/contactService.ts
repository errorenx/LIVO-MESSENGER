import { getSupabaseClient } from '../lib/supabase/client';
import { Contact, ContactRequest, BlockedUser, UserProfile } from '../types';

export async function getContacts(userId: string): Promise<Contact[]> {
  const supabase = getSupabaseClient();
  if (!supabase || !userId) return [];

  try {
    const { data, error } = await supabase
      .from('contacts')
      .select('id, user_id, contact_user_id, created_at, contact_profile:profiles!contacts_contact_user_id_fkey(*)')
      .eq('user_id', userId);

    if (error) {
      // Fallback query if FK name differs
      const { data: fallbackData, error: fbError } = await supabase
        .from('contacts')
        .select('id, user_id, contact_user_id, created_at')
        .eq('user_id', userId);

      if (fbError || !fallbackData) {
        console.warn('Notice fetching contacts fallback:', fbError?.message || error?.message);
        return [];
      }

      // Populate profiles manually
      const userIds = fallbackData.map((c) => c.contact_user_id);
      if (userIds.length === 0) return [];

      const { data: profs } = await supabase
        .from('profiles')
        .select('*')
        .in('id', userIds);

      const profileMap = new Map((profs || []).map((p) => [p.id, p]));

      return fallbackData.map((c) => ({
        id: c.id,
        user_id: c.user_id,
        contact_user_id: c.contact_user_id,
        created_at: c.created_at,
        contact_profile: (profileMap.get(c.contact_user_id) || {
          id: c.contact_user_id,
          username: '@user',
          display_name: 'Contact',
          avatar_url: '',
          created_at: c.created_at,
          last_seen: new Date().toISOString(),
          online_status: 'offline',
        }) as UserProfile,
      }));
    }

    return (data || []).map((c: any) => ({
      id: c.id,
      user_id: c.user_id,
      contact_user_id: c.contact_user_id,
      created_at: c.created_at,
      contact_profile: c.contact_profile || {
        id: c.contact_user_id,
        username: '@user',
        display_name: 'Contact',
        avatar_url: '',
        created_at: c.created_at,
        last_seen: new Date().toISOString(),
        online_status: 'offline',
      },
    }));
  } catch (err: any) {
    console.warn('Notice fetching contacts:', err?.message || err);
    return [];
  }
}

export async function getContactRequests(userId: string): Promise<ContactRequest[]> {
  const supabase = getSupabaseClient();
  if (!supabase || !userId) return [];

  try {
    const { data, error } = await supabase
      .from('contact_requests')
      .select('id, sender_id, receiver_id, status, created_at, updated_at')
      .eq('receiver_id', userId)
      .eq('status', 'pending');

    if (error) {
      console.warn('Notice fetching contact requests:', error.message || error);
      return [];
    }

    if (!data || data.length === 0) return [];

    const senderIds = data.map((r) => r.sender_id);
    const { data: profiles } = await supabase
      .from('profiles')
      .select('*')
      .in('id', senderIds);

    const profileMap = new Map((profiles || []).map((p) => [p.id, p]));

    return data.map((r) => ({
      id: r.id,
      sender_id: r.sender_id,
      receiver_id: r.receiver_id,
      status: r.status,
      created_at: r.created_at,
      updated_at: r.updated_at,
      sender_profile: (profileMap.get(r.sender_id) || {
        id: r.sender_id,
        username: '@user',
        display_name: 'User',
        avatar_url: '',
        created_at: r.created_at,
        last_seen: new Date().toISOString(),
        online_status: 'offline',
      }) as UserProfile,
    }));
  } catch (err: any) {
    console.warn('Notice fetching contact requests:', err?.message || err);
    return [];
  }
}

export async function sendContactRequest(
  senderId: string,
  receiverId: string
): Promise<{ success?: boolean; error?: string }> {
  const supabase = getSupabaseClient();
  if (!supabase) return { error: 'Supabase client not connected.' };
  if (senderId === receiverId) return { error: 'You cannot add yourself as a contact.' };

  try {
    // 1. Check if already contacts
    const { data: existingContact } = await supabase
      .from('contacts')
      .select('id')
      .eq('user_id', senderId)
      .eq('contact_user_id', receiverId)
      .maybeSingle();

    if (existingContact) {
      return { error: 'This user is already in your contacts.' };
    }

    // 2. Check if blocked
    const { data: blocked } = await supabase
      .from('blocked_users')
      .select('id')
      .or(`and(blocker_id.eq.${senderId},blocked_user_id.eq.${receiverId}),and(blocker_id.eq.${receiverId},blocked_user_id.eq.${senderId})`)
      .maybeSingle();

    if (blocked) {
      return { error: 'Cannot send contact request to this user.' };
    }

    // 3. Check existing request
    const { data: existingRequest } = await supabase
      .from('contact_requests')
      .select('id, status')
      .or(`and(sender_id.eq.${senderId},receiver_id.eq.${receiverId}),and(sender_id.eq.${receiverId},receiver_id.eq.${senderId})`)
      .maybeSingle();

    if (existingRequest) {
      if (existingRequest.status === 'pending') {
        return { error: 'A pending request already exists between you and this user.' };
      }
      if (existingRequest.status === 'accepted') {
        return { error: 'You are already contacts.' };
      }
    }

    // 4. Insert contact request
    const { error: insertErr } = await supabase.from('contact_requests').insert({
      sender_id: senderId,
      receiver_id: receiverId,
      status: 'pending',
    });

    if (insertErr) return { error: insertErr.message };

    // 5. Send notification to receiver
    const { data: senderProf } = await supabase.from('profiles').select('display_name').eq('id', senderId).single();
    await supabase.from('notifications').insert({
      user_id: receiverId,
      type: 'contact_request',
      title: 'New Contact Request',
      body: `${senderProf?.display_name || 'Someone'} sent you a contact request.`,
      data: { sender_id: senderId },
    });

    return { success: true };
  } catch (err: any) {
    return { error: err.message || 'Failed to send contact request.' };
  }
}

export async function acceptContactRequest(
  requestId: string,
  userId: string
): Promise<{ success?: boolean; error?: string }> {
  const supabase = getSupabaseClient();
  if (!supabase) return { error: 'Supabase client not connected.' };

  try {
    // Get the request details
    const { data: req, error: reqErr } = await supabase
      .from('contact_requests')
      .select('*')
      .eq('id', requestId)
      .eq('receiver_id', userId)
      .single();

    if (reqErr || !req) return { error: 'Contact request not found.' };

    // Update request status
    await supabase
      .from('contact_requests')
      .update({ status: 'accepted', updated_at: new Date().toISOString() })
      .eq('id', requestId);

    // Insert mutual contact entries
    await supabase.from('contacts').upsert([
      { user_id: req.receiver_id, contact_user_id: req.sender_id },
      { user_id: req.sender_id, contact_user_id: req.receiver_id },
    ]);

    // Send acceptance notification to the sender
    const { data: receiverProf } = await supabase
      .from('profiles')
      .select('display_name')
      .eq('id', userId)
      .single();

    await supabase.from('notifications').insert({
      user_id: req.sender_id,
      type: 'contact_accepted',
      title: 'Contact Request Accepted',
      body: `${receiverProf?.display_name || 'A user'} accepted your contact request!`,
      data: { contact_user_id: userId },
    });

    return { success: true };
  } catch (err: any) {
    return { error: err.message || 'Failed to accept contact request.' };
  }
}

export async function rejectContactRequest(
  requestId: string,
  userId: string
): Promise<{ success?: boolean; error?: string }> {
  const supabase = getSupabaseClient();
  if (!supabase) return { error: 'Supabase client not connected.' };

  try {
    const { error } = await supabase
      .from('contact_requests')
      .update({ status: 'rejected', updated_at: new Date().toISOString() })
      .eq('id', requestId)
      .eq('receiver_id', userId);

    if (error) return { error: error.message };
    return { success: true };
  } catch (err: any) {
    return { error: err.message };
  }
}

export async function removeContact(
  userId: string,
  contactUserId: string
): Promise<{ success?: boolean; error?: string }> {
  const supabase = getSupabaseClient();
  if (!supabase) return { error: 'Supabase client not connected.' };

  try {
    await supabase
      .from('contacts')
      .delete()
      .or(`and(user_id.eq.${userId},contact_user_id.eq.${contactUserId}),and(user_id.eq.${contactUserId},contact_user_id.eq.${userId})`);

    return { success: true };
  } catch (err: any) {
    return { error: err.message };
  }
}

export async function getBlockedUsers(userId: string): Promise<BlockedUser[]> {
  const supabase = getSupabaseClient();
  if (!supabase || !userId) return [];

  try {
    const { data, error } = await supabase
      .from('blocked_users')
      .select('id, blocker_id, blocked_user_id, created_at')
      .eq('blocker_id', userId);

    if (error || !data) return [];

    const blockedIds = data.map((b) => b.blocked_user_id);
    if (blockedIds.length === 0) return [];

    const { data: profiles } = await supabase
      .from('profiles')
      .select('*')
      .in('id', blockedIds);

    const profileMap = new Map((profiles || []).map((p) => [p.id, p]));

    return data.map((b) => ({
      id: b.id,
      blocker_id: b.blocker_id,
      blocked_user_id: b.blocked_user_id,
      created_at: b.created_at,
      blocked_profile: (profileMap.get(b.blocked_user_id) || {
        id: b.blocked_user_id,
        username: '@blocked',
        display_name: 'Blocked User',
        avatar_url: '',
        created_at: b.created_at,
        last_seen: new Date().toISOString(),
        online_status: 'offline',
      }) as UserProfile,
    }));
  } catch (err: any) {
    console.warn('Notice in getBlockedUsers:', err?.message || err);
    return [];
  }
}

export async function blockUser(
  userId: string,
  targetUserId: string
): Promise<{ success?: boolean; error?: string }> {
  const supabase = getSupabaseClient();
  if (!supabase) return { error: 'Supabase client not connected.' };

  try {
    const { error } = await supabase.from('blocked_users').upsert({
      blocker_id: userId,
      blocked_user_id: targetUserId,
    });

    if (error) return { error: error.message };
    return { success: true };
  } catch (err: any) {
    return { error: err.message };
  }
}

export async function unblockUser(
  userId: string,
  targetUserId: string
): Promise<{ success?: boolean; error?: string }> {
  const supabase = getSupabaseClient();
  if (!supabase) return { error: 'Supabase client not connected.' };

  try {
    const { error } = await supabase
      .from('blocked_users')
      .delete()
      .eq('blocker_id', userId)
      .eq('blocked_user_id', targetUserId);

    if (error) return { error: error.message };
    return { success: true };
  } catch (err: any) {
    return { error: err.message };
  }
}

export async function reportTarget(
  reporterId: string,
  reportedUserId: string,
  reason: string
): Promise<{ success?: boolean; error?: string }> {
  const supabase = getSupabaseClient();
  if (!supabase) return { error: 'Supabase client not connected.' };

  try {
    const { error } = await supabase.from('reports').insert({
      reporter_id: reporterId,
      reported_user_id: reportedUserId,
      reason: reason.trim(),
    });

    if (error) return { error: error.message };
    return { success: true };
  } catch (err: any) {
    return { error: err.message };
  }
}
