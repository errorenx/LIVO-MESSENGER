import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { getSupabaseConfig } from './config';

let clientInstance: SupabaseClient | null = null;
let lastUsedUrl = '';
let lastUsedKey = '';

export function getSupabaseClient(): SupabaseClient | null {
  const config = getSupabaseConfig();

  if (!config.isConfigured) {
    return null;
  }

  // Reuse instance if parameters haven't changed
  if (clientInstance && lastUsedUrl === config.url && lastUsedKey === config.anonKey) {
    return clientInstance;
  }

  try {
    clientInstance = createClient(config.url, config.anonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
      },
      realtime: {
        params: {
          eventsPerSecond: 10,
        },
      },
    });
    lastUsedUrl = config.url;
    lastUsedKey = config.anonKey;
    return clientInstance;
  } catch (err) {
    console.error('Failed to initialize Supabase client:', err);
    return null;
  }
}

export function resetSupabaseClient(): void {
  clientInstance = null;
  lastUsedUrl = '';
  lastUsedKey = '';
}
