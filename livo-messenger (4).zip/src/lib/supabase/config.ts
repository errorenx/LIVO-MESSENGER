// Supabase configuration helper
// Reads from Vite environment variables or localStorage override

export interface SupabaseConfig {
  url: string;
  anonKey: string;
  isConfigured: boolean;
}

export function getSupabaseConfig(): SupabaseConfig {
  // Check localStorage first for runtime override
  const localUrl = typeof window !== 'undefined' ? localStorage.getItem('livo_supabase_url') : null;
  const localKey = typeof window !== 'undefined' ? localStorage.getItem('livo_supabase_anon_key') : null;

  // Fallback to Vite env
  const metaEnv = (import.meta as unknown as { env?: Record<string, string> }).env || {};
  const envUrl = metaEnv.VITE_SUPABASE_URL;
  const envKey = metaEnv.VITE_SUPABASE_ANON_KEY;

  let normalizedUrl = (localUrl || envUrl || '').trim();
  if (normalizedUrl && !normalizedUrl.startsWith('http://') && !normalizedUrl.startsWith('https://')) {
    normalizedUrl = `https://${normalizedUrl}`;
  }
  normalizedUrl = normalizedUrl.replace(/\/+$/, '');

  const anonKey = (localKey || envKey || '').trim();

  // Basic validation to check if it has a valid URL and anon key
  const isConfigured = Boolean(
    normalizedUrl &&
    (normalizedUrl.startsWith('https://') || normalizedUrl.startsWith('http://')) &&
    anonKey &&
    anonKey.length > 15
  );

  return {
    url: normalizedUrl,
    anonKey,
    isConfigured,
  };
}

export function saveSupabaseConfig(url: string, anonKey: string): void {
  if (typeof window !== 'undefined') {
    if (url) localStorage.setItem('livo_supabase_url', url.trim());
    else localStorage.removeItem('livo_supabase_url');

    if (anonKey) localStorage.setItem('livo_supabase_anon_key', anonKey.trim());
    else localStorage.removeItem('livo_supabase_anon_key');
  }
}

export function isSupabaseConfigured(): boolean {
  return getSupabaseConfig().isConfigured;
}

export function getSupabaseUrl(): string {
  return getSupabaseConfig().url;
}

export function getSupabaseAnonKey(): string {
  return getSupabaseConfig().anonKey;
}

export function setCustomSupabaseConfig(url: string, anonKey: string): void {
  saveSupabaseConfig(url, anonKey);
}
