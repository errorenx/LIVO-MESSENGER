import React, {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  useRef,
} from 'react';
import {
  Conversation,
  Message,
  MessageType,
  StatusStory,
  CallRecord,
  NotificationItem,
  Contact,
  ContactRequest,
  BlockedUser,
  UserSettings,
} from '../types';
import { useAuth } from './AuthContext';
import { getSupabaseClient } from '../lib/supabase/client';
import * as chatService from '../services/chatService';
import * as contactService from '../services/contactService';
import * as statusService from '../services/statusService';
import * as callService from '../services/callService';
import * as notificationService from '../services/notificationService';
import * as settingsService from '../services/settingsService';
import { callManager } from '../services/webrtc/callManager';

interface ChatContextType {
  // Conversations & Messages
  conversations: Conversation[];
  activeConversationId: string | null;
  activeConversation: Conversation | null;
  activeMessages: Message[];
  setActiveConversationId: (id: string | null) => void;
  messagesMap: Record<string, Message[]>;
  messages: Record<string, Message[]>;
  replyingTo: Message | null;
  setReplyingTo: (msg: Message | null) => void;
  isPeerTyping: boolean;
  typingUsers: string[];
  sendTypingIndicator: (isTyping: boolean) => void;
  sendTypingSignal?: (conversationId?: string) => void;
  sendMessage: (
    contentOrConvId: string,
    messageType?: MessageType | string,
    mediaUrl?: string,
    mediaMeta?: any
  ) => Promise<void>;
  sendVoiceMessage?: (conversationIdOrUrl: string, audioUrlOrDuration?: any, duration?: number) => Promise<void>;
  sendMediaMessage?: (conversationIdOrType: string, typeOrUrl?: any, urlOrCaption?: any, captionOrMeta?: any, meta?: any) => Promise<void>;
  editMessage: (messageId: string, newContent: string) => Promise<void>;
  deleteMessage: (messageId: string) => Promise<void>;
  reactToMessage: (messageId: string, reaction: string) => Promise<void>;
  togglePinMessage: (messageId: string) => Promise<void>;
  toggleStarMessage: (messageId: string) => Promise<void>;

  // Conversation Management
  createDirectChat: (peerUserId: string) => Promise<Conversation>;
  createGroup: (
    name: string,
    description?: string,
    avatarUrlOrMembers?: string | string[],
    memberIds?: string[]
  ) => Promise<Conversation>;
  createGroupChat: (
    name: string,
    description?: string,
    memberIds?: string[],
    avatarUrl?: string
  ) => Promise<Conversation>;
  createChannel: (
    name: string,
    description?: string,
    avatarUrl?: string
  ) => Promise<Conversation>;
  updateGroupInfo: (
    conversationId: string,
    updates: { name?: string; description?: string; avatar_url?: string }
  ) => Promise<void>;
  leaveGroup: (conversationId: string) => Promise<void>;
  addGroupMembers: (conversationId: string, userIds: string[]) => Promise<void>;
  removeGroupMember: (conversationId: string, memberId: string) => Promise<void>;

  // Contacts
  contacts: Contact[];
  contactRequests: ContactRequest[];
  blockedUsers: BlockedUser[];
  sendContactRequest: (receiverUserId: string) => Promise<{ success?: boolean; error?: string }>;
  acceptContactRequest: (requestId: string) => Promise<{ success?: boolean; error?: string }>;
  rejectContactRequest: (requestId: string) => Promise<{ success?: boolean; error?: string }>;
  removeContact: (contactUserId: string) => Promise<{ success?: boolean; error?: string }>;
  blockUser: (targetUserId: string) => Promise<{ success?: boolean; error?: string }>;
  unblockUser: (targetUserId: string) => Promise<{ success?: boolean; error?: string }>;
  reportUser: (targetUserId: string, reason: string) => Promise<{ success?: boolean; error?: string }>;

  // Statuses
  statuses: StatusStory[];
  createStatusStory: (
    content?: string,
    mediaType?: 'text' | 'image' | 'video',
    mediaUrl?: string,
    bgGradient?: string
  ) => Promise<{ status?: StatusStory; error?: string }>;
  deleteStatusStory: (statusId: string) => Promise<void>;
  viewStatusStory: (statusId: string) => Promise<void>;

  // Calls & Notifications
  callHistory: CallRecord[];
  notifications: NotificationItem[];
  unreadNotificationsCount: number;
  markNotificationAsRead: (id: string) => Promise<void>;
  markAllNotificationsAsRead: () => Promise<void>;
  deleteNotification: (id: string) => Promise<void>;

  // Settings
  userSettings: UserSettings;
  updateSettings: (updates: Partial<UserSettings>) => Promise<void>;

  // Search & Filtering
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  refreshData: () => Promise<void>;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export const ChatProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();

  // State initialized clean without any mock data
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [messagesMap, setMessagesMap] = useState<Record<string, Message[]>>({});
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [replyingTo, setReplyingTo] = useState<Message | null>(null);
  const [typingMap, setTypingMap] = useState<Record<string, string[]>>({});

  // Contacts
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [contactRequests, setContactRequests] = useState<ContactRequest[]>([]);
  const [blockedUsers, setBlockedUsers] = useState<BlockedUser[]>([]);

  // Statuses
  const [statuses, setStatuses] = useState<StatusStory[]>([]);

  // Calls & Notifications
  const [callHistory, setCallHistory] = useState<CallRecord[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);

  // Settings
  const [userSettings, setUserSettings] = useState<UserSettings>(settingsService.DEFAULT_USER_SETTINGS);

  // Search
  const [searchQuery, setSearchQuery] = useState<string>('');

  const realtimeChannelRef = useRef<any>(null);
  const typingChannelRef = useRef<any>(null);

  // Derived state
  const activeConversation = conversations.find((c) => c.id === activeConversationId) || null;
  const activeMessages = activeConversationId ? messagesMap[activeConversationId] || [] : [];
  const unreadNotificationsCount = notifications.filter((n) => !n.read_at).length;
  const typingUsers = activeConversationId ? typingMap[activeConversationId] || [] : [];
  const isPeerTyping = typingUsers.length > 0;

  // Sync blocked users to call manager
  useEffect(() => {
    callManager.setBlockedUsers(blockedUsers.map((b) => b.blocked_user_id));
  }, [blockedUsers]);

  // Load all initial data for authenticated user
  const loadInitialData = useCallback(async () => {
    if (!user?.id) {
      setConversations([]);
      setMessagesMap({});
      setContacts([]);
      setContactRequests([]);
      setBlockedUsers([]);
      setStatuses([]);
      setCallHistory([]);
      setNotifications([]);
      return;
    }

    try {
      const [
        convs,
        cnts,
        reqs,
        blks,
        stts,
        cls,
        ntfs,
        sttngs,
      ] = await Promise.all([
        chatService.getConversations(user.id, user),
        contactService.getContacts(user.id),
        contactService.getContactRequests(user.id),
        contactService.getBlockedUsers(user.id),
        statusService.getActiveStatuses(user.id),
        callService.getCallHistory(user.id),
        notificationService.getNotifications(user.id),
        settingsService.getUserSettings(user.id),
      ]);

      setConversations(convs);
      setContacts(cnts);
      setContactRequests(reqs);
      setBlockedUsers(blks);
      setStatuses(stts);
      setCallHistory(cls);
      setNotifications(ntfs);
      setUserSettings(sttngs);

      // Auto-select first conversation (e.g. self-chat) on desktop if none selected
      if (convs.length > 0 && !activeConversationId) {
        setActiveConversationId(convs[0].id);
      }
    } catch (err) {
      console.warn('Notice loading initial chat data:', err);
    }
  }, [user?.id, activeConversationId]);

  useEffect(() => {
    loadInitialData();
  }, [user?.id]);

  // Load messages when active conversation changes
  useEffect(() => {
    if (!activeConversationId || !user?.id) return;

    const loadMessages = async () => {
      try {
        const msgs = await chatService.getConversationMessages(activeConversationId);
        setMessagesMap((prev) => ({
          ...prev,
          [activeConversationId]: msgs,
        }));
        // Mark conversation messages as seen
        await chatService.markConversationSeen(activeConversationId, user.id);
      } catch (err) {
        console.warn('Notice fetching conversation messages:', err);
      }
    };

    loadMessages();
  }, [activeConversationId, user?.id]);

  // Setup Realtime subscriptions
  useEffect(() => {
    if (!user?.id) return;
    const supabase = getSupabaseClient();
    if (!supabase) return;

    // 1. Database Postgres Changes Channel
    const dbChannel = supabase
      .channel(`livo_db_events_${user.id}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'messages' },
        async (payload) => {
          const newMsg = payload.new as any;
          if (!newMsg?.conversation_id) return;

          // Fetch full message with sender profile
          const msgs = await chatService.getConversationMessages(newMsg.conversation_id);
          setMessagesMap((prev) => ({
            ...prev,
            [newMsg.conversation_id]: msgs,
          }));

          // Refresh conversations to update last_message and unread counter
          const updatedConvs = await chatService.getConversations(user.id);
          setConversations(updatedConvs);
        }
      )
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'messages' },
        (payload) => {
          const updated = payload.new as any;
          if (!updated?.conversation_id) return;
          setMessagesMap((prev) => ({
            ...prev,
            [updated.conversation_id]: (prev[updated.conversation_id] || []).map((m) =>
              m.id === updated.id ? { ...m, ...updated } : m
            ),
          }));
        }
      )
      .on(
        'postgres_changes',
        { event: 'DELETE', schema: 'public', table: 'messages' },
        (payload) => {
          const deleted = payload.old as any;
          if (!deleted?.id) return;
          setMessagesMap((prev) => {
            const nextMap: Record<string, Message[]> = {};
            for (const [k, v] of Object.entries(prev)) {
              nextMap[k] = (v as Message[]).filter((m) => m.id !== deleted.id);
            }
            return nextMap;
          });
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'message_reactions' },
        async () => {
          if (activeConversationId) {
            const msgs = await chatService.getConversationMessages(activeConversationId);
            setMessagesMap((prev) => ({ ...prev, [activeConversationId]: msgs }));
          }
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'contact_requests' },
        async () => {
          const reqs = await contactService.getContactRequests(user.id);
          setContactRequests(reqs);
          const cnts = await contactService.getContacts(user.id);
          setContacts(cnts);
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'contacts' },
        async () => {
          const cnts = await contactService.getContacts(user.id);
          setContacts(cnts);
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'notifications' },
        async () => {
          const ntfs = await notificationService.getNotifications(user.id);
          setNotifications(ntfs);
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'statuses' },
        async () => {
          const stts = await statusService.getActiveStatuses(user.id);
          setStatuses(stts);
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'calls' },
        async () => {
          const cls = await callService.getCallHistory(user.id);
          setCallHistory(cls);
        }
      )
      .subscribe();

    realtimeChannelRef.current = dbChannel;

    // 2. Typing Broadcast Channel
    const typingChannel = supabase
      .channel('livo_typing_broadcast')
      .on('broadcast', { event: 'typing' }, (payload: any) => {
        const { conversation_id, user_id, is_typing } = payload.payload || {};
        if (!conversation_id || user_id === user.id) return;

        setTypingMap((prev) => {
          const current = prev[conversation_id] || [];
          if (is_typing) {
            if (!current.includes(user_id)) {
              return { ...prev, [conversation_id]: [...current, user_id] };
            }
          } else {
            return {
              ...prev,
              [conversation_id]: current.filter((id) => id !== user_id),
            };
          }
          return prev;
        });
      })
      .subscribe();

    typingChannelRef.current = typingChannel;

    return () => {
      supabase.removeChannel(dbChannel);
      supabase.removeChannel(typingChannel);
    };
  }, [user?.id, activeConversationId]);

  // Send Typing broadcast
  const sendTypingIndicator = useCallback(
    (isTyping: boolean) => {
      if (!user?.id || !activeConversationId || !typingChannelRef.current) return;
      typingChannelRef.current.send({
        type: 'broadcast',
        event: 'typing',
        payload: {
          conversation_id: activeConversationId,
          user_id: user.id,
          is_typing: isTyping,
        },
      });
    },
    [user?.id, activeConversationId]
  );

  // Send message with flexible signature
  const sendMessage = async (
    arg1: string,
    arg2: MessageType | string = 'text',
    arg3?: any,
    arg4?: any
  ): Promise<void> => {
    if (!user?.id) return;

    // Detect if first argument is a conversation ID
    const isFirstArgConvId =
      conversations.some((c) => c.id === arg1) ||
      arg1.startsWith('self_') ||
      arg1.startsWith('conv_') ||
      arg1.startsWith('grp_');

    const targetConvId = isFirstArgConvId ? arg1 : activeConversationId;
    if (!targetConvId) return;

    let content: string;
    let messageType: MessageType;
    let mediaUrl: string | undefined;
    let mediaMeta: any;

    if (isFirstArgConvId) {
      content = (arg2 as string) || '';
      messageType = 'text';
      mediaUrl = undefined;
      mediaMeta = undefined;
    } else {
      content = arg1 || '';
      messageType = (arg2 as MessageType) || 'text';
      mediaUrl = typeof arg3 === 'string' ? arg3 : undefined;
      mediaMeta = typeof arg3 === 'object' && !arg4 ? arg3 : arg4;
    }

    const replyId = replyingTo?.id;
    setReplyingTo(null);

    // Optimistic local update
    const tempId = `tmp_${Date.now()}`;
    const optimisticMessage: Message = {
      id: tempId,
      conversation_id: targetConvId,
      sender_id: user.id,
      sender_profile: user,
      content,
      message_type: messageType,
      media_url: mediaUrl,
      media_meta: mediaMeta,
      reply_to: replyId,
      reply_message: replyingTo
        ? {
            id: replyingTo.id,
            sender_name: replyingTo.sender_profile?.display_name || 'User',
            content: replyingTo.content,
            type: replyingTo.message_type,
          }
        : undefined,
      status: 'sending',
      created_at: new Date().toISOString(),
    };

    setMessagesMap((prev) => ({
      ...prev,
      [targetConvId]: [...(prev[targetConvId] || []), optimisticMessage],
    }));

    try {
      const res = await chatService.sendMessage(
        targetConvId,
        user.id,
        content,
        messageType,
        mediaUrl,
        mediaMeta,
        replyId
      );

      if (res.message) {
        setMessagesMap((prev) => ({
          ...prev,
          [targetConvId]: (prev[targetConvId] || []).map((m) =>
            m.id === tempId ? { ...res.message!, sender_profile: user } : m
          ),
        }));

        const updatedConvs = await chatService.getConversations(user.id, user);
        setConversations(updatedConvs);
      }
    } catch (err) {
      console.warn('Notice sending message:', err);
      setMessagesMap((prev) => ({
        ...prev,
        [targetConvId]: (prev[targetConvId] || []).map((m) =>
          m.id === tempId ? { ...m, status: 'failed' } : m
        ),
      }));
    }
  };

  const sendVoiceMessage = async (
    targetOrUrl: string,
    urlOrDuration?: any,
    duration?: number
  ): Promise<void> => {
    const audioUrl = typeof urlOrDuration === 'string' ? urlOrDuration : targetOrUrl;
    const dur = typeof urlOrDuration === 'number' ? urlOrDuration : (duration || 0);
    await sendMessage('', 'audio', audioUrl, { duration: dur });
  };

  const sendMediaMessage = async (
    targetOrType: string,
    typeOrUrl?: any,
    urlOrCaption?: any,
    captionOrMeta?: any,
    metaParam?: any
  ): Promise<void> => {
    if (
      typeof typeOrUrl === 'string' &&
      (typeOrUrl === 'image' || typeOrUrl === 'video' || typeOrUrl === 'document')
    ) {
      await sendMessage(captionOrMeta || '', typeOrUrl as MessageType, urlOrCaption, metaParam);
    } else {
      await sendMessage(urlOrCaption || '', targetOrType as MessageType, typeOrUrl, captionOrMeta);
    }
  };

  const sendTypingSignal = (_convId?: string) => {
    sendTypingIndicator(true);
  };

  const editMessage = async (messageId: string, newContent: string): Promise<void> => {
    if (!user?.id || !activeConversationId) return;
    await chatService.editMessage(messageId, user.id, newContent);
    setMessagesMap((prev) => ({
      ...prev,
      [activeConversationId]: (prev[activeConversationId] || []).map((m) =>
        m.id === messageId ? { ...m, content: newContent, edited_at: new Date().toISOString() } : m
      ),
    }));
  };

  const deleteMessage = async (messageId: string): Promise<void> => {
    if (!user?.id || !activeConversationId) return;
    await chatService.deleteMessage(messageId, user.id);
    setMessagesMap((prev) => ({
      ...prev,
      [activeConversationId]: (prev[activeConversationId] || []).filter((m) => m.id !== messageId),
    }));
  };

  const reactToMessage = async (messageId: string, reaction: string): Promise<void> => {
    if (!user?.id || !activeConversationId) return;
    await chatService.reactToMessage(messageId, user.id, reaction);
    // Reload messages to get updated reaction map
    const msgs = await chatService.getConversationMessages(activeConversationId);
    setMessagesMap((prev) => ({ ...prev, [activeConversationId]: msgs }));
  };

  const togglePinMessage = async (messageId: string): Promise<void> => {
    if (!activeConversationId) return;
    const msg = activeMessages.find((m) => m.id === messageId);
    if (!msg) return;
    await chatService.togglePinMessage(messageId, Boolean(msg.is_pinned));
    setMessagesMap((prev) => ({
      ...prev,
      [activeConversationId]: (prev[activeConversationId] || []).map((m) =>
        m.id === messageId ? { ...m, is_pinned: !m.is_pinned } : m
      ),
    }));
  };

  const toggleStarMessage = async (messageId: string): Promise<void> => {
    if (!activeConversationId) return;
    const msg = activeMessages.find((m) => m.id === messageId);
    if (!msg) return;
    await chatService.toggleStarMessage(messageId, Boolean(msg.is_starred));
    setMessagesMap((prev) => ({
      ...prev,
      [activeConversationId]: (prev[activeConversationId] || []).map((m) =>
        m.id === messageId ? { ...m, is_starred: !m.is_starred } : m
      ),
    }));
  };

  const createDirectChat = async (peerUserId: string): Promise<Conversation> => {
    if (!user?.id) throw new Error('Not authenticated');
    const res = await chatService.createDirectConversation(user.id, peerUserId);
    if (res.conversation) {
      setConversations((prev) => {
        const exists = prev.some((c) => c.id === res.conversation!.id);
        return exists ? prev : [res.conversation!, ...prev];
      });
      setActiveConversationId(res.conversation.id);
      return res.conversation;
    }
    throw new Error(res.error || 'Failed to create chat');
  };

  const createGroup = async (
    name: string,
    description: string = '',
    avatarUrlOrMembers: string | string[] = '',
    memberIdsList?: string[]
  ): Promise<Conversation> => {
    if (!user?.id) throw new Error('Not authenticated');
    let avatarUrl = '';
    let memberIds: string[] = [];

    if (Array.isArray(avatarUrlOrMembers)) {
      memberIds = avatarUrlOrMembers;
      avatarUrl = '';
    } else {
      avatarUrl = avatarUrlOrMembers || '';
      memberIds = memberIdsList || [];
    }

    const res = await chatService.createGroupConversation(
      user.id,
      name,
      description,
      avatarUrl,
      memberIds
    );
    if (res.conversation) {
      setConversations((prev) => {
        const exists = prev.some((c) => c.id === res.conversation!.id);
        return exists ? prev : [res.conversation!, ...prev];
      });
      setActiveConversationId(res.conversation.id);
      return res.conversation;
    }
    throw new Error(res.error || 'Failed to create group');
  };

  const createGroupChat = async (
    name: string,
    description: string = '',
    memberIds: string[] = [],
    avatarUrl: string = ''
  ): Promise<Conversation> => {
    return createGroup(name, description, avatarUrl, memberIds);
  };

  const createChannel = async (
    name: string,
    description: string = '',
    avatarUrl: string = ''
  ): Promise<Conversation> => {
    if (!user?.id) throw new Error('Not authenticated');
    const channelDesc = description.startsWith('[Channel]')
      ? description
      : `[Channel] ${description}`.trim();

    const res = await chatService.createGroupConversation(
      user.id,
      name,
      channelDesc,
      avatarUrl,
      []
    );
    if (res.conversation) {
      const channelConv: Conversation = {
        ...res.conversation,
        type: 'channel',
      };
      setConversations((prev) => {
        const exists = prev.some((c) => c.id === channelConv.id);
        return exists ? prev : [channelConv, ...prev];
      });
      setActiveConversationId(channelConv.id);
      return channelConv;
    }
    throw new Error(res.error || 'Failed to create channel');
  };

  const updateGroupInfo = async (
    conversationId: string,
    updates: { name?: string; description?: string; avatar_url?: string }
  ): Promise<void> => {
    await chatService.updateGroup(conversationId, updates);
    setConversations((prev) =>
      prev.map((c) => (c.id === conversationId ? { ...c, ...updates } : c))
    );
  };

  const leaveGroup = async (conversationId: string): Promise<void> => {
    if (!user?.id) return;
    await chatService.leaveGroup(conversationId, user.id);
    setConversations((prev) => prev.filter((c) => c.id !== conversationId));
    if (activeConversationId === conversationId) {
      setActiveConversationId(null);
    }
  };

  const addGroupMembers = async (conversationId: string, userIds: string[]): Promise<void> => {
    await chatService.addGroupMembers(conversationId, userIds);
    if (user?.id) {
      const refreshed = await chatService.getConversations(user.id);
      setConversations(refreshed);
    }
  };

  const removeGroupMember = async (conversationId: string, memberId: string): Promise<void> => {
    await chatService.removeGroupMember(conversationId, memberId);
    if (user?.id) {
      const refreshed = await chatService.getConversations(user.id);
      setConversations(refreshed);
    }
  };

  const sendContactRequest = async (receiverUserId: string) => {
    if (!user?.id) return { error: 'Not authenticated' };
    return await contactService.sendContactRequest(user.id, receiverUserId);
  };

  const acceptContactRequest = async (requestId: string) => {
    if (!user?.id) return { error: 'Not authenticated' };
    const res = await contactService.acceptContactRequest(requestId, user.id);
    if (res.success) {
      setContactRequests((prev) => prev.filter((r) => r.id !== requestId));
      const cnts = await contactService.getContacts(user.id);
      setContacts(cnts);
    }
    return res;
  };

  const rejectContactRequest = async (requestId: string) => {
    if (!user?.id) return { error: 'Not authenticated' };
    const res = await contactService.rejectContactRequest(requestId, user.id);
    if (res.success) {
      setContactRequests((prev) => prev.filter((r) => r.id !== requestId));
    }
    return res;
  };

  const removeContact = async (contactUserId: string) => {
    if (!user?.id) return { error: 'Not authenticated' };
    const res = await contactService.removeContact(user.id, contactUserId);
    if (res.success) {
      setContacts((prev) => prev.filter((c) => c.contact_user_id !== contactUserId));
    }
    return res;
  };

  const blockUser = async (targetUserId: string) => {
    if (!user?.id) return { error: 'Not authenticated' };
    const res = await contactService.blockUser(user.id, targetUserId);
    if (res.success) {
      const blks = await contactService.getBlockedUsers(user.id);
      setBlockedUsers(blks);
      setContacts((prev) => prev.filter((c) => c.contact_user_id !== targetUserId));
    }
    return res;
  };

  const unblockUser = async (targetUserId: string) => {
    if (!user?.id) return { error: 'Not authenticated' };
    const res = await contactService.unblockUser(user.id, targetUserId);
    if (res.success) {
      setBlockedUsers((prev) => prev.filter((b) => b.blocked_user_id !== targetUserId));
    }
    return res;
  };

  const reportUser = async (targetUserId: string, reason: string) => {
    if (!user?.id) return { error: 'Not authenticated' };
    return await contactService.reportTarget(user.id, targetUserId, reason);
  };

  const createStatusStory = async (
    content?: string,
    mediaType: 'text' | 'image' | 'video' = 'text',
    mediaUrl?: string,
    bgGradient?: string
  ) => {
    if (!user?.id) return { error: 'Not authenticated' };
    const res = await statusService.createStatus(
      user.id,
      content,
      mediaType,
      mediaUrl,
      bgGradient
    );
    if (res.status) {
      setStatuses((prev) => [res.status!, ...prev]);
    }
    return res;
  };

  const deleteStatusStory = async (statusId: string): Promise<void> => {
    if (!user?.id) return;
    await statusService.deleteStatus(statusId, user.id);
    setStatuses((prev) => prev.filter((s) => s.id !== statusId));
  };

  const viewStatusStory = async (statusId: string): Promise<void> => {
    if (!user?.id) return;
    await statusService.recordStatusView(statusId, user.id);
    setStatuses((prev) =>
      prev.map((s) => (s.id === statusId ? { ...s, has_viewed: true, views_count: s.views_count + 1 } : s))
    );
  };

  const markNotificationAsRead = async (id: string): Promise<void> => {
    if (!user?.id) return;
    await notificationService.markNotificationRead(id, user.id);
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read_at: new Date().toISOString() } : n))
    );
  };

  const markAllNotificationsAsRead = async (): Promise<void> => {
    if (!user?.id) return;
    await notificationService.markAllNotificationsRead(user.id);
    setNotifications((prev) =>
      prev.map((n) => ({ ...n, read_at: n.read_at || new Date().toISOString() }))
    );
  };

  const deleteNotification = async (id: string): Promise<void> => {
    if (!user?.id) return;
    await notificationService.deleteNotification(id, user.id);
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  const updateSettings = async (updates: Partial<UserSettings>): Promise<void> => {
    if (!user?.id) return;
    const updated = { ...userSettings, ...updates };
    setUserSettings(updated);
    await settingsService.updateUserSettings(user.id, updates);
  };

  return (
    <ChatContext.Provider
      value={{
        conversations,
        activeConversationId,
        activeConversation,
        activeMessages,
        setActiveConversationId,
        messagesMap,
        messages: messagesMap,
        replyingTo,
        setReplyingTo,
        isPeerTyping,
        typingUsers,
        sendTypingIndicator,
        sendTypingSignal,
        sendMessage,
        sendVoiceMessage,
        sendMediaMessage,
        editMessage,
        deleteMessage,
        reactToMessage,
        togglePinMessage,
        toggleStarMessage,
        createDirectChat,
        createGroup,
        createGroupChat,
        createChannel,
        updateGroupInfo,
        leaveGroup,
        addGroupMembers,
        removeGroupMember,
        contacts,
        contactRequests,
        blockedUsers,
        sendContactRequest,
        acceptContactRequest,
        rejectContactRequest,
        removeContact,
        blockUser,
        unblockUser,
        reportUser,
        statuses,
        createStatusStory,
        deleteStatusStory,
        viewStatusStory,
        callHistory,
        notifications,
        unreadNotificationsCount,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        deleteNotification,
        userSettings,
        updateSettings,
        searchQuery,
        setSearchQuery,
        refreshData: loadInitialData,
      }}
    >
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = () => {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
};
