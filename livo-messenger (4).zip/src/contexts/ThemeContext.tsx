import React, { createContext, useContext, useEffect, useState, useMemo } from 'react';
import { AccentColor, ACCENT_COLORS, AppearanceMode, AccentColorDef, ThemeMode } from '../types';

interface ThemeContextType {
  themeMode: ThemeMode;
  setThemeMode: (mode: ThemeMode) => void;
  appearanceMode: AppearanceMode;
  setAppearanceMode: (mode: AppearanceMode) => void;
  accentColor: AccentColor;
  setAccentColor: (accent: AccentColor) => void;
  effectiveTheme: 'light' | 'dark';
  accentDef: AccentColorDef;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

const THEME_MODE_STORAGE_KEY = 'livo_appearance_mode';
const ACCENT_STORAGE_KEY = 'livo_accent_color';

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load initial theme mode (white, black, or rainbow)
  const [themeMode, setThemeModeState] = useState<ThemeMode>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem(THEME_MODE_STORAGE_KEY) as string | null;
      if (saved === 'white' || saved === 'light') return 'white';
      if (saved === 'rainbow') return 'rainbow';
      if (saved === 'black' || saved === 'dark') return 'black';
    }
    return 'black'; // Default to sleek black
  });

  // Load initial accent color
  const [accentColor, setAccentColorState] = useState<AccentColor>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem(ACCENT_STORAGE_KEY) as AccentColor | null;
      if (saved && saved in ACCENT_COLORS) {
        return saved;
      }
    }
    return 'violet';
  });

  // Compute effective theme ('light' or 'dark')
  const effectiveTheme = useMemo<'light' | 'dark'>(() => {
    if (themeMode === 'white') return 'light';
    return 'dark'; // black and rainbow are dark bases
  }, [themeMode]);

  const appearanceMode: AppearanceMode = themeMode;

  const accentDef = useMemo(() => {
    if (themeMode === 'rainbow') {
      return {
        id: 'violet' as AccentColor,
        name: 'Rainbow Multi-Color',
        hex: '#ff007a',
        rgb: '255, 0, 122',
        hover: '#8b5cf6',
      };
    }

    if (accentColor === 'monochrome') {
      if (themeMode === 'black') {
        return {
          id: 'monochrome' as AccentColor,
          name: 'Black & White',
          hex: '#ffffff',
          rgb: '255, 255, 255',
          hover: '#f4f4f5',
        };
      } else {
        return {
          id: 'monochrome' as AccentColor,
          name: 'Black & White',
          hex: '#18181b',
          rgb: '24, 24, 27',
          hover: '#27272a',
        };
      }
    }

    // User chosen accent color (emerald, blue, violet, rose, cyan, orange, pink, indigo)
    const chosen = ACCENT_COLORS[accentColor];
    if (chosen) {
      return chosen;
    }

    return ACCENT_COLORS.violet;
  }, [themeMode, accentColor]);

  // Apply theme classes and CSS variables globally to documentElement
  useEffect(() => {
    const root = document.documentElement;

    // Clear old theme classes
    root.classList.remove('dark', 'theme-white', 'theme-black', 'theme-rainbow');

    // Apply data-theme and classes
    root.setAttribute('data-theme', themeMode);
    root.classList.add(`theme-${themeMode}`);

    if (effectiveTheme === 'dark') {
      root.classList.add('dark');
      root.style.colorScheme = 'dark';
    } else {
      root.style.colorScheme = 'light';
    }

    root.setAttribute('data-accent', accentColor);

    // Apply global accent variables
    const { hex, rgb, hover } = accentDef;
    root.style.setProperty('--accent', hex);
    root.style.setProperty('--accent-rgb', rgb);
    root.style.setProperty('--accent-hover', hover);
    root.style.setProperty(
      '--accent-glow',
      effectiveTheme === 'dark' ? `rgba(${rgb}, 0.45)` : `rgba(${rgb}, 0.3)`
    );
    root.style.setProperty(
      '--accent-soft',
      effectiveTheme === 'dark' ? `rgba(${rgb}, 0.18)` : `rgba(${rgb}, 0.12)`
    );
    const contrast = accentColor === 'monochrome' && themeMode === 'black' ? '#000000' : '#ffffff';
    root.style.setProperty('--accent-contrast', contrast);
  }, [effectiveTheme, accentDef, accentColor, themeMode]);

  const setThemeMode = (mode: ThemeMode) => {
    setThemeModeState(mode);
    if (typeof window !== 'undefined') {
      localStorage.setItem(THEME_MODE_STORAGE_KEY, mode);
    }
  };

  const setAppearanceMode = (mode: AppearanceMode) => {
    if (mode === 'light' || mode === 'white') {
      setThemeMode('white');
    } else if (mode === 'rainbow') {
      setThemeMode('rainbow');
    } else {
      setThemeMode('black');
    }
  };

  const setAccentColor = (accent: AccentColor) => {
    setAccentColorState(accent);
    if (typeof window !== 'undefined') {
      localStorage.setItem(ACCENT_STORAGE_KEY, accent);
    }
  };

  return (
    <ThemeContext.Provider
      value={{
        themeMode,
        setThemeMode,
        appearanceMode,
        setAppearanceMode,
        accentColor,
        setAccentColor,
        effectiveTheme,
        accentDef,
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};
