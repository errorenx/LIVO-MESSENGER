import React, { createContext, useContext, useEffect, useState } from 'react';
import { UserProfile } from '../types';
import { authService } from '../services/authService';
import { ensureUserProfile, updateProfile as updateProfileApi, updatePresence } from '../services/profileService';
import { getSupabaseConfig } from '../lib/supabase/config';

interface AuthContextType {
  user: UserProfile | null;
  isAuthenticated: boolean;
  isSupabaseConnected: boolean;
  loading: boolean;
  signIn: (identifier: string, password: string) => Promise<{ error?: string; isEmailNotConfirmed?: boolean; isRateLimited?: boolean }>;
  login: (identifier: string, password: string) => Promise<{ error?: string; isEmailNotConfirmed?: boolean; isRateLimited?: boolean }>;
  loginWithIdentifier: (identifier: string, password: string) => Promise<{ error?: string; isEmailNotConfirmed?: boolean; isRateLimited?: boolean }>;
  loginWithEmail: (email: string, password: string) => Promise<{ error?: string; isEmailNotConfirmed?: boolean; isRateLimited?: boolean }>;
  signupWithEmail: (
    email: string,
    password: string,
    displayName: string,
    phone?: string
  ) => Promise<{ error?: string; requiresEmailConfirmation?: boolean; isEmailNotConfirmed?: boolean; isRateLimited?: boolean }>;
  signUp: (
    email: string,
    password: string,
    displayName: string,
    phone?: string
  ) => Promise<{ error?: string; requiresEmailConfirmation?: boolean; isEmailNotConfirmed?: boolean; isRateLimited?: boolean }>;
  loginWithGoogle: () => Promise<{ error?: string }>;
  resetPassword: (email: string) => Promise<{ error?: string; success?: boolean }>;
  resendConfirmationEmail: (email: string) => Promise<{ success: boolean; error?: string; isRateLimited?: boolean }>;
  checkEmailConfirmation: (email: string, password?: string) => Promise<{ confirmed: boolean; profile?: UserProfile; error?: string; isRateLimited?: boolean }>;
  logout: () => Promise<void>;
  signOut: () => Promise<void>;
  updateProfile: (updates: Partial<UserProfile>) => Promise<{ error?: string }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [isSupabaseConnected, setIsSupabaseConnected] = useState<boolean>(false);

  // Initialize auth on load & listen to auth state changes
  useEffect(() => {
    let isMounted = true;
    const config = getSupabaseConfig();
    setIsSupabaseConnected(config.isConfigured);

    const initAuth = async () => {
      try {
        const { session } = await authService.getSession();
        if (session?.user && isMounted) {
          const profile = await ensureUserProfile(session.user);
          if (isMounted) {
            setUser(profile);
            if (typeof window !== 'undefined') {
              localStorage.setItem('livo_active_user', JSON.stringify(profile));
            }
            await updatePresence(profile.id, 'online');
          }
        } else if (isMounted) {
          // Check local stored session as fallback
          if (typeof window !== 'undefined') {
            const saved = localStorage.getItem('livo_active_user');
            if (saved) {
              try {
                const parsed = JSON.parse(saved);
                if (parsed?.id) {
                  setUser(parsed);
                } else {
                  setUser(null);
                }
              } catch {
                setUser(null);
              }
            } else {
              setUser(null);
            }
          } else {
            setUser(null);
          }
        }
      } catch (err) {
        console.warn('Notice initializing session:', err);
        if (typeof window !== 'undefined') {
          const saved = localStorage.getItem('livo_active_user');
          if (saved && isMounted) {
            try {
              setUser(JSON.parse(saved));
            } catch {
              setUser(null);
            }
          } else if (isMounted) {
            setUser(null);
          }
        } else if (isMounted) {
          setUser(null);
        }
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    initAuth();

    // Listen to real-time auth changes
    const { unsubscribe } = authService.onAuthStateChange(async (event, authUser) => {
      if (!isMounted) return;

      if (event === 'SIGNED_IN' && authUser) {
        setLoading(true);
        try {
          const profile = await ensureUserProfile(authUser);
          setUser(profile);
          await updatePresence(profile.id, 'online');
        } catch (err) {
          console.warn('Notice synchronizing profile on sign-in:', err);
        } finally {
          setLoading(false);
        }
      } else if (event === 'SIGNED_OUT') {
        setUser(null);
        setLoading(false);
      } else if (event === 'USER_UPDATED' && authUser) {
        const profile = await ensureUserProfile(authUser);
        setUser(profile);
      }
    });

    // Cleanup on unmount / tab close
    const handleBeforeUnload = () => {
      if (user?.id) {
        updatePresence(user.id, 'offline');
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      isMounted = false;
      unsubscribe();
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, []);

  const loginWithGoogle = async (): Promise<{ error?: string }> => {
    return await authService.signInWithGoogle();
  };

  const signIn = async (
    identifier: string,
    password: string
  ): Promise<{ error?: string; isEmailNotConfirmed?: boolean }> => {
    const res = await authService.signInWithIdentifier(identifier, password);
    if (res.error) {
      return { error: res.error, isEmailNotConfirmed: res.isEmailNotConfirmed };
    }
    if (res.profile) {
      setUser(res.profile);
      if (typeof window !== 'undefined') {
        localStorage.setItem('livo_active_user', JSON.stringify(res.profile));
      }
      await updatePresence(res.profile.id, 'online');
    }
    return {};
  };

  const login = signIn;
  const loginWithIdentifier = signIn;
  const loginWithEmail = async (email: string, password: string): Promise<{ error?: string }> => {
    return signIn(email, password);
  };

  const signupWithEmail = async (
    email: string,
    password: string,
    displayName: string,
    phone?: string
  ): Promise<{
    error?: string;
    requiresEmailConfirmation?: boolean;
    isEmailNotConfirmed?: boolean;
    isRateLimited?: boolean;
  }> => {
    const res = await authService.signUpWithEmail(email, password, displayName, phone);
    if (res.error) {
      return {
        error: res.error,
        isEmailNotConfirmed: res.isEmailNotConfirmed,
        isRateLimited: res.isRateLimited,
      };
    }
    if (res.profile) {
      setUser(res.profile);
      if (typeof window !== 'undefined') {
        localStorage.setItem('livo_active_user', JSON.stringify(res.profile));
      }
      await updatePresence(res.profile.id, 'online');
      return {};
    }
    if (res.requiresEmailConfirmation) {
      return {
        requiresEmailConfirmation: true,
        isEmailNotConfirmed: true,
      };
    }
    return {};
  };

  const signUp = signupWithEmail;

  const resetPassword = async (email: string): Promise<{ error?: string; success?: boolean }> => {
    return await authService.resetPasswordForEmail(email);
  };

  const logout = async (): Promise<void> => {
    if (user?.id) {
      await updatePresence(user.id, 'offline');
    }
    await authService.signOut();
    if (typeof window !== 'undefined') {
      localStorage.removeItem('livo_active_user');
    }
    setUser(null);
  };

  const updateProfile = async (updates: Partial<UserProfile>): Promise<{ error?: string }> => {
    if (!user) return { error: 'Not authenticated' };
    const res = await updateProfileApi(user.id, updates);
    if (res.error) {
      return { error: res.error };
    }
    if (res.profile) {
      setUser(res.profile);
    }
    return {};
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: Boolean(user),
        isSupabaseConnected,
        loading,
        signIn,
        login,
        loginWithIdentifier,
        loginWithEmail,
        signupWithEmail,
        signUp,
        loginWithGoogle,
        resetPassword,
        resendConfirmationEmail: authService.resendConfirmationEmail.bind(authService),
        checkEmailConfirmation: authService.checkEmailConfirmation.bind(authService),
        logout,
        signOut: logout,
        updateProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
