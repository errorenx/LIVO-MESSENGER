import React, {
  createContext,
  useContext,
  useState,
  useRef,
  useEffect,
  useCallback,
} from 'react';
import { ActiveCall, CallType, UserProfile, CallRecord } from '../types';
import { useAuth } from './AuthContext';
import { useChat } from './ChatContext';
import { WebRTCService } from '../services/webrtc/WebRTCService';
import { callManager } from '../services/webrtc/callManager';
import { SignalingPayload } from '../services/webrtc/types';
import { getSupabaseClient } from '../lib/supabase/client';
import { isSupabaseConfigured } from '../lib/supabase/config';

interface CallContextType {
  activeCall: ActiveCall | null;
  incomingCall: SignalingPayload | null;
  startCall: (peer: UserProfile, type: CallType) => Promise<void>;
  acceptCall: () => Promise<void>;
  rejectCall: (reason?: string) => void;
  endCall: () => void;
  toggleMute: () => void;
  toggleCamera: () => void;
  callDuration: number;
  localVideoRef: React.RefObject<HTMLVideoElement | null>;
  remoteVideoRef: React.RefObject<HTMLVideoElement | null>;
  permissionError: string | null;
  clearPermissionError: () => void;
  retryCall: () => void;
}

const CallContext = createContext<CallContextType | undefined>(undefined);

// Web Audio tone generator for futuristic ringing and tone feedback
class RingtoneGenerator {
  private ctx: AudioContext | null = null;
  private interval: any = null;

  public startRinging(type: 'outgoing' | 'incoming') {
    this.stop();
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      this.ctx = new AudioCtx();

      const playChime = () => {
        if (!this.ctx || this.ctx.state === 'closed') return;
        const now = this.ctx.currentTime;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'sine';
        if (type === 'outgoing') {
          // Futuristic two-tone beep (440Hz -> 480Hz)
          osc.frequency.setValueAtTime(440, now);
          osc.frequency.exponentialRampToValueAtTime(480, now + 0.3);
          gain.gain.setValueAtTime(0.04, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 1.2);
        } else {
          // Melodic gentle incoming chime (523Hz -> 659Hz -> 784Hz)
          osc.frequency.setValueAtTime(523.25, now);
          osc.frequency.setValueAtTime(659.25, now + 0.15);
          osc.frequency.setValueAtTime(783.99, now + 0.3);
          gain.gain.setValueAtTime(0.06, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 1.4);
        }

        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(now);
        osc.stop(now + 1.5);
      };

      playChime();
      this.interval = setInterval(playChime, type === 'outgoing' ? 3000 : 2500);
    } catch {
      // Audio context might be restricted before user gesture
    }
  }

  public stop() {
    if (this.interval) {
      clearInterval(this.interval);
      this.interval = null;
    }
    if (this.ctx) {
      try {
        this.ctx.close();
      } catch {}
      this.ctx = null;
    }
  }
}

const ringtone = new RingtoneGenerator();

export const CallProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const { addCallRecord } = useChat();

  const [activeCall, setActiveCall] = useState<ActiveCall | null>(null);
  const [incomingCall, setIncomingCall] = useState<SignalingPayload | null>(null);
  const [callDuration, setCallDuration] = useState<number>(0);
  const [permissionError, setPermissionError] = useState<string | null>(null);

  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const remoteVideoRef = useRef<HTMLVideoElement | null>(null);
  const webrtcServiceRef = useRef<WebRTCService | null>(null);
  const timerRef = useRef<any>(null);
  const lastCallTargetRef = useRef<{ peer: UserProfile; type: CallType } | null>(null);

  // Initialize CallManager with current user
  useEffect(() => {
    if (user) {
      callManager.init(user);
    }
    return () => {
      callManager.cleanup();
    };
  }, [user]);

  // Duration timer
  useEffect(() => {
    if (activeCall && activeCall.status === 'connected') {
      ringtone.stop();
      timerRef.current = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    } else {
      setCallDuration(0);
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [activeCall?.status]);

  // Ringtone handling
  useEffect(() => {
    if (activeCall && (activeCall.status === 'calling' || activeCall.status === 'ringing')) {
      ringtone.startRinging('outgoing');
    } else if (incomingCall) {
      ringtone.startRinging('incoming');
    } else {
      ringtone.stop();
    }

    return () => {
      ringtone.stop();
    };
  }, [activeCall?.status, incomingCall]);

  // Save call record to local state and Supabase
  const persistCallRecord = useCallback(
    async (recordData: Omit<CallRecord, 'id'>) => {
      addCallRecord(recordData);

      if (isSupabaseConfigured()) {
        const supabase = getSupabaseClient();
        if (supabase) {
          try {
            await supabase.from('calls').insert({
              caller_id: recordData.caller_id,
              receiver_id: recordData.receiver_id,
              type: recordData.type,
              status: recordData.status,
              started_at: recordData.started_at,
              ended_at: recordData.ended_at || new Date().toISOString(),
              duration: recordData.duration || 0,
            });
          } catch (err) {
            console.warn('Could not persist call record to Supabase:', err);
          }
        }
      }
    },
    [addCallRecord]
  );

  // Complete cleanup of media tracks and peer connection
  const cleanupCall = useCallback(() => {
    ringtone.stop();
    callManager.clearCallTimeout();

    if (webrtcServiceRef.current) {
      webrtcServiceRef.current.close();
      webrtcServiceRef.current = null;
    }

    if (localVideoRef.current) {
      localVideoRef.current.srcObject = null;
    }
    if (remoteVideoRef.current) {
      remoteVideoRef.current.srcObject = null;
    }
  }, []);

  // Handle incoming signaling messages
  useEffect(() => {
    const unsubscribe = callManager.addListener(async (payload) => {
      // 1. Incoming Call Offer
      if (payload.type === 'call:offer') {
        if (activeCall && activeCall.status !== 'ended') {
          // Already on another call -> send busy
          await callManager.sendBusy(payload.callId, payload.callerId, payload.callType);
          return;
        }

        // Notify caller that receiver device is ringing
        await callManager.sendRinging(payload.callId, payload.callerId, payload.callType);
        setIncomingCall(payload);
        return;
      }

      // 2. Ringing confirmation from receiver
      if (payload.type === 'call:ringing') {
        if (activeCall && activeCall.id === payload.callId) {
          setActiveCall((prev) => (prev ? { ...prev, status: 'ringing' } : null));
        }
        return;
      }

      // 3. Call Answer from receiver
      if (payload.type === 'call:answer') {
        if (activeCall && activeCall.id === payload.callId && payload.sdp) {
          callManager.clearCallTimeout();
          try {
            if (webrtcServiceRef.current) {
              await webrtcServiceRef.current.handleAnswer(payload.sdp);
              setActiveCall((prev) => (prev ? { ...prev, status: 'connecting' } : null));
            }
          } catch (err) {
            console.error('Error handling WebRTC answer:', err);
          }
        }
        return;
      }

      // 4. Remote ICE candidate
      if (payload.type === 'call:ice-candidate') {
        if (webrtcServiceRef.current && payload.candidate) {
          await webrtcServiceRef.current.addIceCandidate(payload.candidate);
        }
        return;
      }

      // 5. Call Rejected
      if (payload.type === 'call:reject') {
        if (activeCall && activeCall.id === payload.callId) {
          setActiveCall((prev) =>
            prev ? { ...prev, status: payload.reason === 'busy' ? 'busy' : 'rejected' } : null
          );
          if (user) {
            persistCallRecord({
              caller_id: user.id,
              caller_profile: user,
              receiver_id: activeCall.peer.id,
              receiver_profile: activeCall.peer,
              type: activeCall.type,
              status: payload.reason === 'busy' ? 'busy' : 'rejected',
              started_at: new Date().toISOString(),
              duration: 0,
            });
          }
          setTimeout(() => {
            cleanupCall();
            setActiveCall(null);
          }, 2000);
        }
        return;
      }

      // 6. Call Busy
      if (payload.type === 'call:busy') {
        if (activeCall && activeCall.id === payload.callId) {
          setActiveCall((prev) => (prev ? { ...prev, status: 'busy' } : null));
          if (user) {
            persistCallRecord({
              caller_id: user.id,
              caller_profile: user,
              receiver_id: activeCall.peer.id,
              receiver_profile: activeCall.peer,
              type: activeCall.type,
              status: 'busy',
              started_at: new Date().toISOString(),
              duration: 0,
            });
          }
          setTimeout(() => {
            cleanupCall();
            setActiveCall(null);
          }, 2000);
        }
        return;
      }

      // 7. Call Ended by peer
      if (payload.type === 'call:end') {
        if (incomingCall && incomingCall.callId === payload.callId) {
          setIncomingCall(null);
        }
        if (activeCall && activeCall.id === payload.callId) {
          setActiveCall((prev) => (prev ? { ...prev, status: 'ended' } : null));
          if (user) {
            persistCallRecord({
              caller_id: activeCall.direction === 'outgoing' ? user.id : activeCall.peer.id,
              caller_profile: activeCall.direction === 'outgoing' ? user : activeCall.peer,
              receiver_id: activeCall.direction === 'outgoing' ? activeCall.peer.id : user.id,
              receiver_profile: activeCall.direction === 'outgoing' ? activeCall.peer : user,
              type: activeCall.type,
              status: callDuration > 0 ? 'completed' : 'missed',
              started_at: new Date(Date.now() - callDuration * 1000).toISOString(),
              ended_at: new Date().toISOString(),
              duration: callDuration,
            });
          }
          setTimeout(() => {
            cleanupCall();
            setActiveCall(null);
          }, 1200);
        }
        return;
      }
    });

    return () => {
      unsubscribe();
    };
  }, [activeCall, incomingCall, user, callDuration, cleanupCall, persistCallRecord]);

  // Initiate an Outgoing Voice or Video Call
  const startCall = async (peer: UserProfile, type: CallType) => {
    if (!user) return;
    cleanupCall();
    setPermissionError(null);
    lastCallTargetRef.current = { peer, type };

    const callId = `call_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

    const newCallState: ActiveCall = {
      id: callId,
      peer,
      type,
      direction: 'outgoing',
      status: 'calling',
      is_muted: false,
      is_camera_off: false,
    };
    setActiveCall(newCallState);

    // Create WebRTC Service
    const service = new WebRTCService({
      onLocalStream: (stream) => {
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
        }
        setActiveCall((prev) => (prev ? { ...prev, local_stream: stream } : null));
      },
      onRemoteStream: (stream) => {
        if (remoteVideoRef.current) {
          remoteVideoRef.current.srcObject = stream;
        }
        setActiveCall((prev) => (prev ? { ...prev, remote_stream: stream } : null));
      },
      onIceCandidate: (candidate) => {
        callManager.sendIceCandidate(callId, peer.id, type, candidate);
      },
      onConnectionStateChange: (state) => {
        if (state === 'connected') {
          setActiveCall((prev) =>
            prev ? { ...prev, status: 'connected', started_at: Date.now() } : null
          );
        } else if (state === 'failed' || state === 'disconnected') {
          setActiveCall((prev) => (prev ? { ...prev, status: 'failed' } : null));
        }
      },
      onIceConnectionStateChange: (state) => {
        if (state === 'connected' || state === 'completed') {
          setActiveCall((prev) =>
            prev ? { ...prev, status: 'connected', started_at: Date.now() } : null
          );
        }
      },
      onError: (err) => {
        console.error('WebRTC Error:', err);
      },
    });

    webrtcServiceRef.current = service;

    try {
      // 1. Request real camera/mic media
      await service.getLocalMedia(type);

      // 2. Create RTCPeerConnection and SDP Offer
      service.initPeerConnection();
      const offer = await service.createOffer();

      // 3. Send offer via Supabase Realtime
      await callManager.sendOffer(callId, peer.id, type, offer);

      // 4. Start 35s outgoing timeout
      callManager.startOutgoingCallTimeout(async () => {
        setActiveCall((prev) => (prev ? { ...prev, status: 'timeout' } : null));
        await callManager.sendSignal({
          type: 'call:timeout',
          callId,
          callerId: user.id,
          receiverId: peer.id,
          callType: type,
          timestamp: Date.now(),
        });
        persistCallRecord({
          caller_id: user.id,
          caller_profile: user,
          receiver_id: peer.id,
          receiver_profile: peer,
          type,
          status: 'missed',
          started_at: new Date().toISOString(),
          duration: 0,
        });
        setTimeout(() => {
          cleanupCall();
          setActiveCall(null);
        }, 2000);
      }, 35000);
    } catch (err: any) {
      console.warn('Local media access denied or failed:', err);
      setPermissionError(
        err.message || 'Media access is required to make a call. Please check browser permissions.'
      );
      setActiveCall((prev) =>
        prev
          ? {
              ...prev,
              status: 'failed',
              error_message:
                err.message || 'Camera or microphone access denied. Please grant permissions.',
            }
          : null
      );
    }
  };

  // Accept Incoming Call
  const acceptCall = async () => {
    if (!incomingCall || !user) return;

    const payload = incomingCall;
    setIncomingCall(null);
    cleanupCall();
    setPermissionError(null);

    const callerProfile: UserProfile = payload.callerProfile || {
      id: payload.callerId,
      username: `user_${payload.callerId.slice(0, 5)}`,
      display_name: `Caller ${payload.callerId.slice(0, 5)}`,
      avatar_url: `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80`,
      status_message: 'Calling on LIVO',
      online_status: 'online',
      created_at: new Date().toISOString(),
    };

    const newCallState: ActiveCall = {
      id: payload.callId,
      peer: callerProfile,
      type: payload.callType,
      direction: 'incoming',
      status: 'connecting',
      is_muted: false,
      is_camera_off: false,
    };
    setActiveCall(newCallState);

    const service = new WebRTCService({
      onLocalStream: (stream) => {
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
        }
        setActiveCall((prev) => (prev ? { ...prev, local_stream: stream } : null));
      },
      onRemoteStream: (stream) => {
        if (remoteVideoRef.current) {
          remoteVideoRef.current.srcObject = stream;
        }
        setActiveCall((prev) => (prev ? { ...prev, remote_stream: stream } : null));
      },
      onIceCandidate: (candidate) => {
        callManager.sendIceCandidate(payload.callId, payload.callerId, payload.callType, candidate);
      },
      onConnectionStateChange: (state) => {
        if (state === 'connected') {
          setActiveCall((prev) =>
            prev ? { ...prev, status: 'connected', started_at: Date.now() } : null
          );
        } else if (state === 'failed' || state === 'disconnected') {
          setActiveCall((prev) => (prev ? { ...prev, status: 'failed' } : null));
        }
      },
      onIceConnectionStateChange: (state) => {
        if (state === 'connected' || state === 'completed') {
          setActiveCall((prev) =>
            prev ? { ...prev, status: 'connected', started_at: Date.now() } : null
          );
        }
      },
      onError: (err) => {
        console.error('WebRTC Error:', err);
      },
    });

    webrtcServiceRef.current = service;

    try {
      // 1. Acquire media
      await service.getLocalMedia(payload.callType);

      // 2. Handle remote offer and generate SDP answer
      if (payload.sdp) {
        const answer = await service.handleOfferAndCreateAnswer(payload.sdp);
        await callManager.sendAnswer(payload.callId, payload.callerId, payload.callType, answer);
      }
    } catch (err: any) {
      console.warn('Failed to accept call media:', err);
      setPermissionError(
        err.message || 'Media permission is required to accept this call. Please check browser settings.'
      );
      await callManager.sendReject(payload.callId, payload.callerId, payload.callType, 'permission_denied');
      setActiveCall((prev) =>
        prev
          ? {
              ...prev,
              status: 'failed',
              error_message: 'Permission denied. Please enable camera/microphone permissions.',
            }
          : null
      );
    }
  };

  // Reject Incoming Call
  const rejectCall = (reason: string = 'declined') => {
    if (incomingCall && user) {
      callManager.sendReject(
        incomingCall.callId,
        incomingCall.callerId,
        incomingCall.callType,
        reason
      );

      const callerProfile: UserProfile = incomingCall.callerProfile || {
        id: incomingCall.callerId,
        username: 'user',
        display_name: 'Caller',
        avatar_url: '',
        status_message: '',
        online_status: 'offline',
        created_at: new Date().toISOString(),
      };

      persistCallRecord({
        caller_id: incomingCall.callerId,
        caller_profile: callerProfile,
        receiver_id: user.id,
        receiver_profile: user,
        type: incomingCall.callType,
        status: 'rejected',
        started_at: new Date().toISOString(),
        duration: 0,
      });

      setIncomingCall(null);
    } else if (activeCall && user) {
      callManager.sendReject(activeCall.id, activeCall.peer.id, activeCall.type, reason);
      persistCallRecord({
        caller_id: activeCall.direction === 'incoming' ? activeCall.peer.id : user.id,
        caller_profile: activeCall.direction === 'incoming' ? activeCall.peer : user,
        receiver_id: activeCall.direction === 'incoming' ? user.id : activeCall.peer.id,
        receiver_profile: activeCall.direction === 'incoming' ? user : activeCall.peer,
        type: activeCall.type,
        status: 'rejected',
        started_at: new Date().toISOString(),
        duration: 0,
      });
      cleanupCall();
      setActiveCall(null);
    }
  };

  // End Active Call
  const endCall = () => {
    if (activeCall && user) {
      callManager.sendEnd(activeCall.id, activeCall.peer.id, activeCall.type);

      persistCallRecord({
        caller_id: activeCall.direction === 'outgoing' ? user.id : activeCall.peer.id,
        caller_profile: activeCall.direction === 'outgoing' ? user : activeCall.peer,
        receiver_id: activeCall.direction === 'outgoing' ? activeCall.peer.id : user.id,
        receiver_profile: activeCall.direction === 'outgoing' ? activeCall.peer : user,
        type: activeCall.type,
        status: callDuration > 0 ? 'completed' : 'missed',
        started_at: new Date(Date.now() - callDuration * 1000).toISOString(),
        ended_at: new Date().toISOString(),
        duration: callDuration,
      });
    }

    cleanupCall();
    setActiveCall(null);
  };

  // Toggle Microphone Mute
  const toggleMute = () => {
    if (!activeCall || !webrtcServiceRef.current) return;
    const nextMuted = !activeCall.is_muted;
    webrtcServiceRef.current.setAudioMuted(nextMuted);
    setActiveCall((prev) => (prev ? { ...prev, is_muted: nextMuted } : null));
  };

  // Toggle Camera On/Off
  const toggleCamera = () => {
    if (!activeCall || !webrtcServiceRef.current) return;
    const nextCameraOff = !activeCall.is_camera_off;
    webrtcServiceRef.current.setVideoEnabled(!nextCameraOff);
    setActiveCall((prev) => (prev ? { ...prev, is_camera_off: nextCameraOff } : null));
  };

  const clearPermissionError = () => {
    setPermissionError(null);
  };

  const retryCall = () => {
    setPermissionError(null);
    if (lastCallTargetRef.current) {
      startCall(lastCallTargetRef.current.peer, lastCallTargetRef.current.type);
    }
  };

  return (
    <CallContext.Provider
      value={{
        activeCall,
        incomingCall,
        startCall,
        acceptCall,
        rejectCall,
        endCall,
        toggleMute,
        toggleCamera,
        callDuration,
        localVideoRef,
        remoteVideoRef,
        permissionError,
        clearPermissionError,
        retryCall,
      }}
    >
      {children}
    </CallContext.Provider>
  );
};

export const useCall = () => {
  const context = useContext(CallContext);
  if (!context) {
    throw new Error('useCall must be used within a CallProvider');
  }
  return context;
};
