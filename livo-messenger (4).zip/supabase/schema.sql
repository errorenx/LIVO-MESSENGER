-- =====================================================================
-- LIVO MESSENGER - SUPABASE PRODUCTION DATABASE SCHEMA & RLS POLICIES
-- =====================================================================

-- 1. Enable required PostgreSQL extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. User Profiles Table
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username TEXT UNIQUE NOT NULL,
  display_name TEXT NOT NULL,
  avatar_url TEXT DEFAULT '',
  bio TEXT DEFAULT 'Available on LIVO',
  phone TEXT,
  last_seen TIMESTAMPTZ DEFAULT NOW(),
  online_status TEXT DEFAULT 'online' CHECK (online_status IN ('online', 'offline', 'away')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Migration safety for existing databases
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS phone TEXT;

CREATE INDEX IF NOT EXISTS idx_profiles_username ON public.profiles(username);
CREATE INDEX IF NOT EXISTS idx_profiles_phone ON public.profiles(phone);

-- 3. User Settings Table
CREATE TABLE IF NOT EXISTS public.user_settings (
  user_id UUID PRIMARY KEY REFERENCES public.profiles(id) ON DELETE CASCADE,
  appearance_mode TEXT DEFAULT 'system' CHECK (appearance_mode IN ('light', 'dark', 'system')),
  accent_color TEXT DEFAULT 'violet' CHECK (accent_color IN ('violet', 'blue', 'cyan', 'emerald', 'rose', 'orange', 'pink', 'indigo')),
  enter_to_send BOOLEAN DEFAULT TRUE,
  chat_wallpaper TEXT DEFAULT 'default',
  media_auto_download BOOLEAN DEFAULT TRUE,
  notifications_sound BOOLEAN DEFAULT TRUE,
  notifications_desktop BOOLEAN DEFAULT TRUE,
  privacy_last_seen TEXT DEFAULT 'everyone' CHECK (privacy_last_seen IN ('everyone', 'contacts', 'nobody')),
  privacy_online TEXT DEFAULT 'everyone' CHECK (privacy_online IN ('everyone', 'contacts', 'nobody')),
  privacy_read_receipts BOOLEAN DEFAULT TRUE,
  privacy_avatar TEXT DEFAULT 'everyone' CHECK (privacy_avatar IN ('everyone', 'contacts', 'nobody')),
  privacy_bio TEXT DEFAULT 'everyone' CHECK (privacy_bio IN ('everyone', 'contacts', 'nobody')),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. Contacts & Contact Requests
CREATE TABLE IF NOT EXISTS public.contacts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  contact_user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, contact_user_id)
);

CREATE TABLE IF NOT EXISTS public.contact_requests (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sender_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  receiver_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(sender_id, receiver_id)
);

-- 5. Conversations & Members
CREATE TABLE IF NOT EXISTS public.conversations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  type TEXT DEFAULT 'direct' CHECK (type IN ('direct', 'group')),
  name TEXT,
  avatar_url TEXT,
  description TEXT,
  created_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.conversation_members (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  conversation_id UUID NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  role TEXT DEFAULT 'member' CHECK (role IN ('admin', 'member')),
  joined_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(conversation_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_conv_members_user ON public.conversation_members(user_id);
CREATE INDEX IF NOT EXISTS idx_conv_members_conv ON public.conversation_members(conversation_id);

-- 6. Messages
CREATE TABLE IF NOT EXISTS public.messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  conversation_id UUID NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  message_type TEXT DEFAULT 'text' CHECK (message_type IN ('text', 'image', 'video', 'document', 'audio', 'voice', 'gif')),
  media_url TEXT,
  media_meta JSONB DEFAULT '{}'::jsonb,
  reply_to UUID REFERENCES public.messages(id) ON DELETE SET NULL,
  status TEXT DEFAULT 'sent' CHECK (status IN ('sending', 'sent', 'delivered', 'seen', 'failed')),
  is_pinned BOOLEAN DEFAULT FALSE,
  is_starred BOOLEAN DEFAULT FALSE,
  edited_at TIMESTAMPTZ,
  deleted_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_messages_conv_created ON public.messages(conversation_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_messages_sender ON public.messages(sender_id);

-- 7. Message Reactions
CREATE TABLE IF NOT EXISTS public.message_reactions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  message_id UUID NOT NULL REFERENCES public.messages(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  reaction TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(message_id, user_id, reaction)
);

-- 8. Status Stories (24h expiry)
CREATE TABLE IF NOT EXISTS public.statuses (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  content TEXT,
  media_url TEXT,
  media_type TEXT DEFAULT 'text' CHECK (media_type IN ('text', 'image', 'video')),
  bg_gradient TEXT DEFAULT 'from-violet-600 to-indigo-700',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  expires_at TIMESTAMPTZ DEFAULT (NOW() + INTERVAL '24 hours')
);

CREATE INDEX IF NOT EXISTS idx_statuses_expires ON public.statuses(expires_at);

CREATE TABLE IF NOT EXISTS public.status_views (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  status_id UUID NOT NULL REFERENCES public.statuses(id) ON DELETE CASCADE,
  viewer_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  viewed_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(status_id, viewer_id)
);

-- 9. Calls & Signaling
CREATE TABLE IF NOT EXISTS public.calls (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  caller_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  receiver_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  type TEXT DEFAULT 'voice' CHECK (type IN ('voice', 'video')),
  status TEXT DEFAULT 'missed' CHECK (status IN ('missed', 'completed', 'rejected', 'busy', 'ongoing')),
  started_at TIMESTAMPTZ DEFAULT NOW(),
  ended_at TIMESTAMPTZ,
  duration INTEGER DEFAULT 0
);

-- 10. Notifications
CREATE TABLE IF NOT EXISTS public.notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  type TEXT NOT NULL CHECK (type IN ('message', 'contact_request', 'contact_accepted', 'group', 'call')),
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  data JSONB DEFAULT '{}'::jsonb,
  read_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_notifications_user_read ON public.notifications(user_id, read_at);

-- 11. Blocked Users & Reports
CREATE TABLE IF NOT EXISTS public.blocked_users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  blocker_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  blocked_user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(blocker_id, blocked_user_id)
);

CREATE TABLE IF NOT EXISTS public.reports (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  reporter_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  reported_user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  reason TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- =====================================================================

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contacts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contact_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.conversation_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.message_reactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.statuses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.status_views ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.calls ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.blocked_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reports ENABLE ROW LEVEL SECURITY;

-- Profiles: Anyone authenticated can read profiles; users can update own profile
CREATE POLICY "Public profiles are viewable by everyone" ON public.profiles
  FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Users can update own profile" ON public.profiles
  FOR UPDATE USING (auth.uid() = id);

-- Settings: Users can read and update own settings
CREATE POLICY "Users can manage own settings" ON public.user_settings
  FOR ALL USING (auth.uid() = user_id);

-- Contacts: Users can view their own contact lists
CREATE POLICY "Users can manage their contacts" ON public.contacts
  FOR ALL USING (auth.uid() = user_id);

-- Contact requests: Senders & Receivers can view and manage
CREATE POLICY "Users can view relevant requests" ON public.contact_requests
  FOR SELECT USING (auth.uid() = sender_id OR auth.uid() = receiver_id);

CREATE POLICY "Users can create requests" ON public.contact_requests
  FOR INSERT WITH CHECK (auth.uid() = sender_id);

CREATE POLICY "Users can update received requests" ON public.contact_requests
  FOR UPDATE USING (auth.uid() = receiver_id OR auth.uid() = sender_id);

-- Conversations & Members
CREATE POLICY "Members can view conversations" ON public.conversations
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.conversation_members
      WHERE conversation_members.conversation_id = conversations.id
      AND conversation_members.user_id = auth.uid()
    )
  );

CREATE POLICY "Authenticated users can create conversations" ON public.conversations
  FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Members can view membership" ON public.conversation_members
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.conversation_members m
      WHERE m.conversation_id = conversation_members.conversation_id
      AND m.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can join or be added to conversations" ON public.conversation_members
  FOR INSERT WITH CHECK (auth.role() = 'authenticated');

-- Messages: Only members can read or write
CREATE POLICY "Members can read conversation messages" ON public.messages
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.conversation_members
      WHERE conversation_members.conversation_id = messages.conversation_id
      AND conversation_members.user_id = auth.uid()
    )
  );

CREATE POLICY "Members can insert messages" ON public.messages
  FOR INSERT WITH CHECK (
    auth.uid() = sender_id AND
    EXISTS (
      SELECT 1 FROM public.conversation_members
      WHERE conversation_members.conversation_id = messages.conversation_id
      AND conversation_members.user_id = auth.uid()
    )
  );

CREATE POLICY "Senders can edit or delete own messages" ON public.messages
  FOR UPDATE USING (auth.uid() = sender_id);

-- Statuses: Visible to contacts/everyone if not expired
CREATE POLICY "Active statuses are viewable" ON public.statuses
  FOR SELECT USING (expires_at > NOW());

CREATE POLICY "Users can create own status" ON public.statuses
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own status" ON public.statuses
  FOR DELETE USING (auth.uid() = user_id);

-- Calls: Participants can view and manage
CREATE POLICY "Participants can view calls" ON public.calls
  FOR SELECT USING (auth.uid() = caller_id OR auth.uid() = receiver_id);

CREATE POLICY "Users can insert calls" ON public.calls
  FOR INSERT WITH CHECK (auth.uid() = caller_id);

-- Notifications: Only target user can access
CREATE POLICY "Users view own notifications" ON public.notifications
  FOR ALL USING (auth.uid() = user_id);

-- =====================================================================
-- AUTOMATIC NEW USER SETUP TRIGGER
-- =====================================================================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
  clean_username TEXT;
  clean_display_name TEXT;
BEGIN
  -- Generate unique username from email or metadata
  clean_username := COALESCE(
    NEW.raw_user_meta_data->>'user_name',
    NEW.raw_user_meta_data->>'preferred_username',
    SPLIT_PART(NEW.email, '@', 1)
  );
  
  -- Fallback if empty
  IF clean_username IS NULL OR clean_username = '' THEN
    clean_username := 'user_' || SUBSTRING(NEW.id::text, 1, 8);
  END IF;

  -- Ensure @ prefix or clean alphanumeric
  clean_username := '@' || REGEXP_REPLACE(LOWER(clean_username), '[^a-z0-9_]', '', 'g');

  clean_display_name := COALESCE(
    NEW.raw_user_meta_data->>'full_name',
    NEW.raw_user_meta_data->>'name',
    SPLIT_PART(NEW.email, '@', 1),
    'LIVO User'
  );

  INSERT INTO public.profiles (id, username, display_name, avatar_url, bio, phone)
  VALUES (
    NEW.id,
    clean_username,
    clean_display_name,
    COALESCE(NEW.raw_user_meta_data->>'avatar_url', ''),
    'Hello, I am on LIVO!',
    COALESCE(NEW.raw_user_meta_data->>'phone', NEW.phone, '')
  )
  ON CONFLICT (id) DO NOTHING;

  INSERT INTO public.user_settings (user_id)
  VALUES (NEW.id)
  ON CONFLICT (user_id) DO NOTHING;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Helper function: Secure phone lookup to authenticate via email backend
CREATE OR REPLACE FUNCTION public.get_auth_email_by_phone(lookup_phone TEXT)
RETURNS TEXT AS $$
DECLARE
  found_email TEXT;
  clean_phone TEXT;
BEGIN
  clean_phone := REGEXP_REPLACE(lookup_phone, '[^0-9+]', '', 'g');
  
  -- Look up email from profiles
  SELECT email INTO found_email
  FROM (
    SELECT p.id
    FROM public.profiles p
    WHERE p.phone = clean_phone OR p.phone = lookup_phone
    LIMIT 1
  ) match_prof
  JOIN auth.users u ON u.id = match_prof.id;

  -- Fallback check in auth.users
  IF found_email IS NULL THEN
    SELECT u.email INTO found_email
    FROM auth.users u
    WHERE (u.phone = clean_phone OR u.phone = lookup_phone OR u.raw_user_meta_data->>'phone' = clean_phone OR u.raw_user_meta_data->>'phone' = lookup_phone)
    LIMIT 1;
  END IF;

  RETURN found_email;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION public.get_auth_email_by_phone(TEXT) TO anon, authenticated;

-- =====================================================================
-- SUPABASE STORAGE BUCKETS SETUP
-- =====================================================================
INSERT INTO storage.buckets (id, name, public)
VALUES 
  ('avatars', 'avatars', true),
  ('chat-media', 'chat-media', true),
  ('documents', 'documents', true),
  ('voice-messages', 'voice-messages', true),
  ('status-media', 'status-media', true)
ON CONFLICT (id) DO NOTHING;
